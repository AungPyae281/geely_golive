<?php include '../header.php'; ?>
<style>
	.autocomplete-items {
		position: absolute;
		border: 1px solid #d4d4d4;
		border-bottom: none;
		border-top: none;
		z-index: 99;
		/*position the autocomplete items to be the same width as the container:*/
		top: 89%;
		left: 8px;
		right: 8px;
		max-height: 300px;
		overflow-y: auto;
	}
	.autocomplete-items div {
		padding: 10px;
		cursor: pointer;
		background-color: #fff;
		border-bottom: 1px solid #d4d4d4;
	}
	.autocomplete-items div:hover {
		/*when hovering an item:*/
		background-color: #e9e9e9;
	}
	.autocomplete-active {
		/*when navigating through the items using the arrow keys:*/
		background-color: DodgerBlue !important;
		color: #ffffff;
	} 
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Service - Report</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date:</label>
											<div class="col-md-1 icheck-success d-inline">
												<input id="chkDate" type="checkbox" style="margin: 8px 0px" checked>
												<label for="chkDate"></label>
											</div>
											<div class="col-md-7">  
												<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtRegistrationNo">
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Service Center:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtRegistrationNo" value="<?=$_SESSION['service_center']?>" disabled>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPlateNo">
											</div>
										</div>
									</div>		
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Customer Name:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtCustomerName">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Customer Phone:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtCustomerPhone">
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
										</div>
									</div>	
								</div>	
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">Service List <span id="total_records" style="font-weight:bold;"></span></h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-striped table-responsive table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 3%">#</th>
								<th>Date</th>
								<th>Registration No.</th> 
								<th>Plate No.</th>
								<th>Customer Name</th>
								<th>Customer Phone</th>
								<th>Total Services</th>
								<th>Complain</th>
								<th style="width: 6%">Action</th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>

			<center>
				<div class="modal fade modal-primary" id="myModalComplain"> 
					<div class="modal-dialog" style="max-width: 100% !important;">
						<div class="modal-content" style="width: 35%; top: 29px;">
							<div class="modal-header" style="padding: 12px;">
								<h4 class="modal-title" style="font-size: 18px !important;">Complain - Entry</h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body" style="padding-left: 0px; padding-right: 0px;">
								<div class="row">
									<div class="col-md-12">
										<input type="hidden" class="form-control" id="txtServiceID">
										<div class="form-group row">
											<label class="col-md-3 col-form-label" style="text-align: right;">Complain:</label>
											<div class="col-md-8">
												<textarea id="txtComplain" value="" class="form-control" rows="6"></textarea>
											</div>
											<div class="col-md-1"></div>
										</div> 
										<div class="form-group row">
											<div class="col-md-7"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="validateAndSave()">Submit</button>
											</div>
											<div class="col-md-1"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</center>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
  	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");	
		$('#datePicker').datepicker(); 
		autocompleteRegistrationNo(document.getElementById("txtRegistrationNo")); 
		autocompletePlateNo(document.getElementById("txtPlateNo"));
		autocompleteCustomer(document.getElementById("txtCustomerName")); 
	});	

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});

	$("#chkDate").change(function() {
		if ($('#chkDate').prop('checked')){
			$("#txtDatePicker").prop("disabled", false);
			$("#txtDatePicker").css("cursor", "pointer");
		}else{
			$("#txtDatePicker").prop("disabled", true);
			$("#txtDatePicker").val(customDate);
			$("#datePicker").datepicker("setDate", customDate);
		}
	});

	$("#txtCustomerName").on("input", function(){
		$("#txtCustomerPhone").val("");
	}); 

	function autocompleteRegistrationNo(inp) {
		var currentFocus;
		inp.addEventListener("input", function(e) {
			var a, i, val = this.value;
			var obj = this;
			closeAllLists();
			if (!val) { return false;}
			currentFocus = -1;
			$.ajax({
				url: APP_URL + "api/service/service/autocomplete_registration_no.php",
				type: "POST",
				data: JSON.stringify({ registration_no: this.value })
			}).done(function( data ) {
				bindData(a, i, obj, data, val);
			});
		});

		inp.addEventListener("keydown", function(e) {
			var x = document.getElementById(this.id + "autocomplete-list");
			if (x) x = x.getElementsByTagName("div");
			if (e.keyCode == 40) {
				currentFocus++;
				addActive(x);
			} else if (e.keyCode == 38) { 
				currentFocus--;
				addActive(x);
			} else if (e.keyCode == 13) {
				e.preventDefault();
				if (currentFocus > -1) {
					if (x) x[currentFocus].click();
				}
			}
		});

		function addActive(x) {
			if (!x) return false;
			removeActive(x);
			if (currentFocus >= x.length) currentFocus = 0;
			if (currentFocus < 0) currentFocus = (x.length - 1);
			x[currentFocus].classList.add("autocomplete-active");
		}

		function removeActive(x) {
			for (var i = 0; i < x.length; i++) {
				x[i].classList.remove("autocomplete-active");
			}
		}

		function closeAllLists(elmnt) {
			var x = document.getElementsByClassName("autocomplete-items");
			for (var i = 0; i < x.length; i++) {
				if (elmnt != x[i] && elmnt != inp) {
					x[i].parentNode.removeChild(x[i]);
				}
			}
		}
		
		function bindData(a, i, obj, arr, val){
			a = document.createElement("DIV");
			a.setAttribute("id", obj.id + "autocomplete-list");
			a.setAttribute("class", "autocomplete-items");
			obj.parentNode.appendChild(a);
			for (i = 0; i < arr.length; i++) {
				var strRegExp = new RegExp(val, "gi" ); //i makes it case insensitive	
				var registration_no = arr[i]['registration_no'];
				b = document.createElement("DIV");
				b.innerHTML = registration_no.replace(strRegExp, '<b>' + val + '</b>');
				b.innerHTML += "<input type='hidden' value='" + registration_no.replace(/\'/g, '&apos;') + "'>";
				b.addEventListener("click", function(e) {
					inp.value = this.getElementsByTagName("input")[0].value;
					closeAllLists();
				});
				a.appendChild(b);
			}
		}

		document.addEventListener("click", function (e) {
			closeAllLists(e.target);
		});
	}

	function autocompletePlateNo(inp) {
		var currentFocus;
		inp.addEventListener("input", function(e) {
			var a, i, val = this.value;
			var obj = this;
			closeAllLists();
			if (!val) { return false;}
			currentFocus = -1;
			$.ajax({
				url: APP_URL + "api/service/service/autocomplete_plate_no.php",
				type: "POST",
				data: JSON.stringify({ plate_no: this.value })
			}).done(function( data ) {
				bindData(a, i, obj, data, val);
			});
		});

		inp.addEventListener("keydown", function(e) {
			var x = document.getElementById(this.id + "autocomplete-list");
			if (x) x = x.getElementsByTagName("div");
			if (e.keyCode == 40) {
				currentFocus++;
				addActive(x);
			} else if (e.keyCode == 38) { 
				currentFocus--;
				addActive(x);
			} else if (e.keyCode == 13) {
				e.preventDefault();
				if (currentFocus > -1) {
					if (x) x[currentFocus].click();
				}
			}
		});

		function addActive(x) {
			if (!x) return false;
			removeActive(x);
			if (currentFocus >= x.length) currentFocus = 0;
			if (currentFocus < 0) currentFocus = (x.length - 1);
			x[currentFocus].classList.add("autocomplete-active");
		}

		function removeActive(x) {
			for (var i = 0; i < x.length; i++) {
				x[i].classList.remove("autocomplete-active");
			}
		}

		function closeAllLists(elmnt) {
			var x = document.getElementsByClassName("autocomplete-items");
			for (var i = 0; i < x.length; i++) {
				if (elmnt != x[i] && elmnt != inp) {
					x[i].parentNode.removeChild(x[i]);
				}
			}
		}
		
		function bindData(a, i, obj, arr, val){
			a = document.createElement("DIV");
			a.setAttribute("id", obj.id + "autocomplete-list");
			a.setAttribute("class", "autocomplete-items");
			obj.parentNode.appendChild(a);
			for (i = 0; i < arr.length; i++) {
				var strRegExp = new RegExp(val, "gi" ); //i makes it case insensitive	
				var plate_no = arr[i]['plate_no'];
				b = document.createElement("DIV");
				b.innerHTML = plate_no.replace(strRegExp, '<b>' + val + '</b>');
				b.innerHTML += "<input type='hidden' value='" + plate_no.replace(/\'/g, '&apos;') + "'>";
				b.addEventListener("click", function(e) {
					inp.value = this.getElementsByTagName("input")[0].value;
					closeAllLists();
				});
				a.appendChild(b);
			}
		}

		document.addEventListener("click", function (e) {
			closeAllLists(e.target);
		});
	}

	function autocompleteCustomer(inp) {
		var currentFocus;
		inp.addEventListener("input", function(e) {
			var a, i, val = this.value;
			var obj = this;
			closeAllLists();
			if (!val) { return false;}
			currentFocus = -1;
			$.ajax({
				url: APP_URL + "api/service/service/autocomplete_customer.php",
				type: "POST",
				data: JSON.stringify({ customer_name: this.value })
			}).done(function( data ) {
				bindData(a, i, obj, data, val);
			});
		});

		inp.addEventListener("keydown", function(e) {
			var x = document.getElementById(this.id + "autocomplete-list");
			if (x) x = x.getElementsByTagName("div");
			if (e.keyCode == 40) {
				currentFocus++;
				addActive(x);
			} else if (e.keyCode == 38) { 
				currentFocus--;
				addActive(x);
			} else if (e.keyCode == 13) {
				e.preventDefault();
				if (currentFocus > -1) {
					if (x) x[currentFocus].click();
				}
			}
		});

		function addActive(x) {
			if (!x) return false;
			removeActive(x);
			if (currentFocus >= x.length) currentFocus = 0;
			if (currentFocus < 0) currentFocus = (x.length - 1);
			x[currentFocus].classList.add("autocomplete-active");
		}

		function removeActive(x) {
			for (var i = 0; i < x.length; i++) {
				x[i].classList.remove("autocomplete-active");
			}
		}

		function closeAllLists(elmnt) {
			var x = document.getElementsByClassName("autocomplete-items");
			for (var i = 0; i < x.length; i++) {
				if (elmnt != x[i] && elmnt != inp) {
					x[i].parentNode.removeChild(x[i]);
				}
			}
		}
		
		function bindData(a, i, obj, arr, val){
			a = document.createElement("DIV");
			a.setAttribute("id", obj.id + "autocomplete-list");
			a.setAttribute("class", "autocomplete-items");
			obj.parentNode.appendChild(a);
			for (i = 0; i < arr.length; i++) {
				var strRegExp = new RegExp(val, "gi" ); //i makes it case insensitive	
				var name = arr[i]['customer_name'];
				var phone = arr[i]['customer_phone'];
				b = document.createElement("DIV");
				b.innerHTML = name.replace(strRegExp, '<b>' + val + '</b>');
				b.innerHTML += "<input type='hidden' value='" + name.replace(/\'/g, '&apos;') + "'>";
				b.innerHTML += "<input type='hidden' value='" + phone.replace(/\'/g, '&apos;') + "'>";
				b.addEventListener("click", function(e) {
					inp.value = this.getElementsByTagName("input")[0].value;
					$("#txtCustomerPhone").val(this.getElementsByTagName("input")[1].value);
					closeAllLists();
				});
				a.appendChild(b);
			}
		}

		document.addEventListener("click", function (e) {
			closeAllLists(e.target);
		});
	}

	function search(){
		$("#loading").css("display", "block");
		var date = ($("#chkDate").prop("checked"))?$("#txtDatePicker").val():"";
		var registration_no = $("#txtRegistrationNo").val();
		var service_center = $("#txtServiceCenter").val();
		var plate_no = $("#txtPlateNo").val();
		var customer_name = $("#txtCustomerName").val();
		var customer_phone = $("#txtCustomerPhone").val();

		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/service/service/search.php",
			type: "POST",
			data: JSON.stringify({ date: date, registration_no: registration_no, plate_no: plate_no, customer_name: customer_name, customer_phone: customer_phone })
		}).done(function(data) {
			$("#loading").css("display", "none"); 
			if(data.records.length>0){
				$("#total_records").text(" - " + data.records.length + " records found.");
			}else{
				$("#total_records").text(" - " + data.records.length + " record found.");
			}
			$.each(data.records, function(i, v) {   
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.date + "</td>")
					.append("<td>" + v.registration_no + "</td>") 
					.append("<td>" + v.plate_no + "</td>")
					.append("<td>" + v.customer_name + "</td>")
					.append("<td>" + v.customer_phone + "</td>")
					.append("<td style='text-align: right; padding-right: 25px;'>" + v.total_services + "</td>")
					.append("<td>" + v.complain + "</td>")
					.append("<td><button class='btn btn-primary btn-sm' onclick='goToComplain(\"" + v.id + "\", this)' style='min-width: 100px;'>Complain</button></td>")
				); 
			});
		});
	}

	function goToComplain(id, obj){
		$("#txtServiceID").val(id);
		$("#txtComplain").val($(obj).parent().parent().find("td").eq(7).text());
		OBJ = obj;
		$("#myModalComplain").modal('show');
	}

	function validateAndSave(){
		var id = $("#txtServiceID").val();
		var complain = $("#txtComplain").val();

		$.ajax({
			url: APP_URL + "api/service/service/update_complain.php",
			type: "POST",
			data: JSON.stringify({ id: id, complain: complain })
		}).done(function(data) {
			if(data.message=="updated"){
				$(OBJ).parent().parent().find("td").eq(7).text(complain);
				bootbox.alert("Successfully submitted.");
				$("#myModalComplain").modal('hide');
				OBJ = "";
			}else if(data.message=="session expire"){
				bootbox.alert("Session Expire! Please refresh the browser and login again.");
			}else{
				bootbox.alert("Error on server side.");
			}
		});
	}
</script>
