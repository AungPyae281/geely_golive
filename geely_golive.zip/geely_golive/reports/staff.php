<?php include '../header.php'; ?>
<style>
	.autocomplete-items {
		position: absolute;
		border: 1px solid #d4d4d4;
		border-bottom: none;
		border-top: none;
		z-index: 99;
		/*position the autocomplete items to be the same width as the container:*/
		top: 100%;
		left: 8px;
		right: 8px;
		max-height: 300px;
		overflow-y: auto;
	}
	.autocomplete-items div {
		padding: 10px;
		cursor: pointer;
		background-color: #fff;
		border-bottom: 1px solid #d4d4d4;
	}
	.autocomplete-items div:hover {
		/*when hovering an item:*/
		background-color: #e9e9e9;
	}
	.autocomplete-active {
		/*when navigating through the items using the arrow keys:*/
		background-color: DodgerBlue !important;
		color: #ffffff;
	} 
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Staff - Report</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Staff ID:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtStaffID">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtStaffName">
											</div>
										</div>
									</div>		
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Department:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboDepartment"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Position:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboPosition"></select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtNRCNo">
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search </button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
										</div>
									</div> 	
								</div>	
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">Staff List <span id="total_records" style="font-weight:bold;"> </span></h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-striped table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 3%">#</th>
								<th>Join Date</th>
								<th>Staff ID</th>
								<th>Name</th>
								<th>DOB</th>
								<th>NRC No.</th>
								<th>Department</th>
								<th>Position</th>
								<th>Phone</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	$(function(){
		$("body").addClass("sidebar-collapse");	
		autocomplete(document.getElementById("txtStaffID"));
		getAllDepartment();
	});	

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});

	$("#txtStaffID").on("input", function(){
		$("#txtStaffName").val("");
	});

	$("#cboDepartment").change(function(){
		getPositionbyDepartment();
	});

	function autocomplete(inp) {
		var currentFocus;
		inp.addEventListener("input", function(e) {
			var a, i, val = this.value;
			var obj = this;
			closeAllLists();
			if (!val) { return false;}
			currentFocus = -1;
			$.ajax({
				url: APP_URL + "api/hr/staff/autocomplete.php",
				type: "POST",
				data: JSON.stringify({ card_no: this.value })
			}).done(function( data ) {
				bindData(a, i, obj, data, val);
			});
		});

		inp.addEventListener("keydown", function(e) {
			var x = document.getElementById(this.id + "autocomplete-list");
			if (x) x = x.getElementsByTagName("div");
			if (e.keyCode == 40) {
				currentFocus++;
				addActive(x);
			} else if (e.keyCode == 38) { 
				currentFocus--;
				addActive(x);
			} else if (e.keyCode == 13) {
				e.preventDefault();
				if (currentFocus > -1) {
					if (x) x[currentFocus].click();
				}
			}
		});

		function addActive(x) {
			if (!x) return false;
			removeActive(x);
			if (currentFocus >= x.length) currentFocus = 0;
			if (currentFocus < 0) currentFocus = (x.length - 1);
			x[currentFocus].classList.add("autocomplete-active");
		}

		function removeActive(x) {
			for (var i = 0; i < x.length; i++) {
				x[i].classList.remove("autocomplete-active");
			}
		}

		function closeAllLists(elmnt) {
			var x = document.getElementsByClassName("autocomplete-items");
			for (var i = 0; i < x.length; i++) {
				if (elmnt != x[i] && elmnt != inp) {
					x[i].parentNode.removeChild(x[i]);
				}
			}
		}
		
		function bindData(a, i, obj, arr, val){
			a = document.createElement("DIV");
			a.setAttribute("id", obj.id + "autocomplete-list");
			a.setAttribute("class", "autocomplete-items");
			obj.parentNode.appendChild(a);
			for (i = 0; i < arr.length; i++) {
				var strRegExp = new RegExp(val, "gi" ); //i makes it case insensitive	
				var card_no = arr[i]['card_no'];
				var name = arr[i]['name'];
				b = document.createElement("DIV");
				b.innerHTML = card_no.replace(strRegExp, '<b>' + val + '</b>');
				b.innerHTML += "<input type='hidden' value='" + card_no.replace(/\'/g, '&apos;') + "'>";
				b.innerHTML += "<input type='hidden' value='" + name + "'>";
				b.addEventListener("click", function(e) {
					inp.value = this.getElementsByTagName("input")[0].value;
					$("#txtStaffName").val(this.getElementsByTagName("input")[1].value);
					closeAllLists();
				});
				a.appendChild(b);
			}
		}

		document.addEventListener("click", function (e) {
			closeAllLists(e.target);
		});
	}

	function getAllDepartment(){
		$("#cboDepartment").find("option").remove();
		$("#cboDepartment").append("<option value=''>All</option>");
		$.ajax({
			url: APP_URL + "api/hr/department/get_all_rows.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				$("#cboDepartment").append("<option value='" + v.department + "'>" + v.department + "</option>");
			});
			getPositionbyDepartment();
		});
	}

	function getPositionbyDepartment(pos){
		$("#cboPosition").find("option").remove();
		$("#cboPosition").append("<option value=''>All</option>");
		var department = $("#cboDepartment").val();

		if(department){
			$.ajax({
				type: "POST",
				url: APP_URL + "api/hr/position/get_all_rows_by_department.php",
				data: JSON.stringify({ department: department })
			}).done(function(data) {
				$.each(data.records, function(i, v) {
					$("#cboPosition").append("<option value='" + v.position + "'>" + v.position + "</option>");
				});
			});
		}
	}

	function search(){
		$("#loading").css("display","block");
		var card_no = $("#txtStaffID").val();	
		var name = $("#txtStaffName").val();
		var department = $("#cboDepartment").val();
		var position = ($("#cboPosition").val())?$("#cboPosition").val():"";
		var nrc_no = $("#txtNRCNo").val();

		$("#myTable").find("tbody").find("tr").remove(); 
		$.ajax({
			type: "POST",
			url: APP_URL + "api/hr/staff/search.php",
			data: JSON.stringify({ card_no: card_no, name: name, department: department, position: position, nrc_no: nrc_no })
		}).done(function(data) {	
			$("#loading").css("display","none");
			if(data.records.length>1){
				$("#total_records").text(" - " + data.records.length + " records found.");
			}else{
				$("#total_records").text(" - " + data.records.length + " record found.");
			}
			$.each(data.records, function(i, v) {
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.join_date + "</td>")
					.append("<td style='padding-right: 20px; color:#10649c;cursor: pointer; font-weight: bold;text-decoration: underline' onclick='goToDetail(\"" + v.id + "\");' title='Detail'>" + v.card_no + "</td>")
					.append("<td>" + v.name + "</td>")
					.append("<td>" + v.dob + "</td>")
					.append("<td>" + v.nrc_no + "</td>")
					.append("<td>" + v.department + "</td>")
					.append("<td>" + v.position + "</td>")
					.append("<td>" + v.phone + "</td>")
				);
			});
       });
	}

	function goToDetail(id){
		document.location = APP_URL + "hr/staff.php?id=" + id;
	}	
</script>
