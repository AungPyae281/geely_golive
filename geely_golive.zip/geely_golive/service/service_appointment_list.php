<?php include '../header.php'; ?> 
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                	<div class="card card-outline card-primary">
                		<div class="card-header">
							<h3 class="card-title">Service Appointment List</h3>
							<button type="button" class="btn btn-success btn-sm" data-id="1" onclick="goToAppointment();" style="font-size: 17px; float: right; padding-left: 15px; padding-right: 15px;"><i class="fas fa-user-plus"></i> New Appointment</button>
						</div>
						<div class="card-body">
							<table id="myTable" class="display nowrap">
								<thead>
									<tr>
										<th>Plate No.</th>
										<th>Date</th>
										<th>Time</th>
										<th>Type</th>
										<th>Contact Person</th>
										<th>Contact Phone</th>
										<th>Check-in</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
                	</div>
                </div>

            </div>
        </div>
    </section>
</div>
<?php include '../footer.php'; ?>
<script>
	$(function() {
		$("body").addClass("sidebar-collapse");
		fillGrid();
	});	

	function fillGrid(){
		table = $('#myTable').DataTable({
			"scrollX": true,
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": false,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"order": [[ 0, "desc" ]],
			'columnDefs': [	
				{
					'targets': 6,
					'searchable': false,
					'orderable': false, 
					'render': function (data){
						return '<td><button type="button" class="btn btn-success btn-sm" onclick="goToInspection(' + data + ', this);" style="font-size: 15px; min-width: 44px;" title="Inspection"><i class="fas fa-tasks"></i></button></td>';
					}
				}
			],
			"ajax": APP_URL + "api/service/service_appointment/get_all_service_appointment_list.php"
		});		
	}

	function goToInspection(id, obj){
		document.location = APP_URL + "service/inspection.php?act=entry&id=" + id;
	}

	function goToAppointment(){
		document.location = APP_URL + "service/service_appointment.php";
	}
</script>