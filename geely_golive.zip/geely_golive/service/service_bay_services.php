<?php include '../header.php'; ?>
<style>
	select{
		padding-top: 1px !important;
	}
	.align{
		text-align: right;
	}
	.displayNone{
		display: none;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Service Bay Services - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Input</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 10000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-5">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Service Center Bay: </label>
											<div class="col-md-8">
												<select id="cboServiceCenterBay" class="form-control"></select>
											</div>
										</div>
									</div>
									<div class="col-md-5">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Service Item: </label>
											<div class="col-md-8"> 
												<div class="input-group input-group">
													<input id="txtServiceItem" data-id="" data-code="" value="" class="form-control" disabled>
													<span class="input-group-btn">
														<button type="button" class="btn btn-primary" onclick="getAllServiceItem()" id="btnServiceItem" style="padding-bottom: 3px;">. . .</button>
													</span>         
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-2">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;"></label>
											<div class="col-md-8">
												<button type="button" class="btn btn-primary btn-block" onclick="add()">Add</button>
											</div>
										</div>
									</div>
									<div class="card-body p-0" style="height:250px; overflow-y: auto;background-color: #e6e7e8 !important;">
										<table class="table table-striped table-bordered" id="myTable2">
											<thead>                  
												<tr>
													<th style="width: 3%">#</th>
													<th>Service Center Bay</th> 
													<th>Service Item Code</th>
													<th>Service Item Name</th>
													<th style="width: 3%">Delete</th>
												</tr>
											</thead>
											<tbody></tbody>
										</table>
									</div>
								</div>
								<div class="row" style="padding-top: 5px;">
									<div class="col-md-9">
									</div>
									<div class="col-md-3">
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-8 btnAddPack">
												<button type="button" class="btn btn-success btn-block" onclick="validateAndSave(this)">Create</button>
											</div>
											<div class="col-md-8 btnEditPack" style="display: none;">
												<button type="button" class="btn btn-primary btn-block" onclick="validateAndSave(this)">Update</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>

						<center>
							<div class="modal fade" id="myModalServiceItem">
								<div class="modal-dialog" style="max-width: 100% !important;">
									<div class="modal-content" style="width: 65%; top: 30px;">
										<div class="modal-header" style="padding: 12px;">
											<h4 class="modal-title">Service Item List <span id="total_records_si" style="font-weight:bold;"> </span></h4>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
											<table id="myTable1" class="table table-head-fixed" style="cursor: pointer;">
												<thead>
													<tr> 
														<th>Code</th>
														<th>Name</th>
														<th>Waiting Time</th>
														<th>Price</th>
														<th style="display: none;">ID</th>
													</tr>
												</thead>
												<tbody></tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</center>

					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script> 
	$(function() {
		$("body").addClass("sidebar-collapse");
		getAllServiceCenterBay();
	});

	$("#cboServiceCenterBay").change(function(){
		getServiceBayServicesDetail();
	});

	function getAllServiceCenterBay(){
        $("#cboServiceCenterBay").find("option").remove();
        $("#cboServiceCenterBay").append("<option value = '' data-id = '' data-name = ''></option>");
        $.ajax({
            url: APP_URL + "api/service/service_center_bay/get_all_rows.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboServiceCenterBay").append("<option value = '" + v.bay_no + "' data-id = '" + v.id + "' data-name = '" + v.name + "'>" + v.bay_no + " (" + v.name + ")" + "</option>");
            });
        });
    }

	function getAllServiceItem(){
		$("#myModalServiceItem").modal('show');
		table = $('#myTable1').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"ajax": APP_URL + "api/service/service_item/get_all_service_item.php",
			"columnDefs": [
				{
					'targets': [3],
					"className": 'align'
				},
				{
					'targets': [4],
					"className": 'displayNone'
				}
			]
		});	
	}

	$('#myTable1').on('click', 'tbody tr', function(e){
		$("#myTable1 tbody tr").css("color","");
		$("#myTable1 tbody tr").css("background-color","");
		$(this).css("color", "rgb(34, 126, 140)"); 
		$(this).css("background-color", "#e3ecf5"); 

		$("#txtServiceItem").val($(this).find("td").eq(1).text());
		$("#txtServiceItem").attr("data-id", $(this).find("td").eq(4).text());
		$("#txtServiceItem").attr("data-code", $(this).find("td").eq(0).text());
		$("#myModalServiceItem").modal('hide');
	});

	function getServiceBayServicesDetail(){
		var service_center_bay_id = $("#cboServiceCenterBay option:selected").attr('data-id');
		$("#myTable2").find("tbody").find("tr").remove();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/service/service_bay_services/get_service_bay_services_detail.php",
			data: JSON.stringify({ service_center_bay_id: service_center_bay_id })
		}).done(function(data) {
			if(data.records.length>0){
				$.each(data.records, function(i, v) {
					$("#myTable2").find("tbody")
					.append($('<tr data-sid="' + v.service_item_id + '">')
						.append("<td>" + ($("#myTable2 tbody tr").length + 1) + "</td>")
						.append("<td>" + v.bay_no + " (" + v.name + ")</td>")
						.append("<td>" + v.code + "</td>")
						.append("<td>" + v.service_item + "</td>")
						.append("<td style='width: 70px'><button type='button' class='btn btn-danger btn-sm' style='padding: 0px 19px;font-size: 18px;' onclick='$(this).parent().parent().remove();'>×</button></td>")
					);
					$(".btnAddPack").css("display", "none");
					$(".btnEditPack").css("display", "block");
				});
			}else{
				$(".btnAddPack").css("display", "block");
				$(".btnEditPack").css("display", "none");
			}
       });
	}

	function add(){
		var service_item_id = $("#txtServiceItem").attr("data-id");
		var code = $("#txtServiceItem").attr("data-code");
		var service_item = $("#txtServiceItem").val();
		var service_center_bay = $("#cboServiceCenterBay option:selected").text();
		var service_center_bay_id = $("#cboServiceCenterBay option:selected").attr('data-id');

		if(service_center_bay==""){
			bootbox.alert("Please choose service center bay.");
		}else if(service_item==""){
			bootbox.alert("Please choose service item.");
		}else{
			if(!checkServiceItem(code)){
				$("#myTable2").find("tbody")
				.append($('<tr data-sid="' + service_item_id + '">')
					.append("<td style='width: 10px'>" + ($("#myTable2 tbody tr").length + 1) + "</td>")
					.append("<td>" + service_center_bay + "</td>")
					.append("<td>" + code + "</td>")
					.append("<td>" + service_item + "</td>")
					.append("<td style='width: 70px'><button type='button' class='btn btn-danger btn-sm' style='padding: 0px 19px;font-size: 18px;' onclick='$(this).parent().parent().remove();'>×</button></td>")
				);
				$("#txtServiceItem").val("");
				$("#txtServiceItem").attr("data-id", "");
				$("#txtServiceItem").attr("data-code", "");
			}else{
				bootbox.alert("Service item already exist!");
			}
			
		}
	}

	function checkServiceItem(code){
		var tf = false;
		$("#myTable2 tbody tr").each(function(){
			if($(this).find("td").eq(2).text()==code){
				tf = true;
				return false;
			}
		});
		return tf;
	} 

	function validateAndSave(obj){ 
		var sbs_lists = [];
		$("#myTable2 tbody tr").each(function (){
			var sbs_list = { 
				"service_item_id" : $(this).attr("data-sid")
			};
			sbs_lists.push(sbs_list);
		});

		var sbslist = {
			"service_center_bay_id" : $("#cboServiceCenterBay option:selected").attr('data-id'),
			"action" : $(obj).text(),
			"sbs_lists": sbs_lists
		}

		if(sbs_lists.length==0){
			bootbox.alert("Please fill at least one service item."); 
		}else{
			$("#loading").css("display", "block");
			$.ajax({
				url: APP_URL + "api/service/service_bay_services/create_update.php",
				type: "POST",
				data: JSON.stringify(sbslist)
			}).done(function(data) {
				$("#loading").css("display", "none");
				if(data.message=="created"){
					$("#frmEntry")[0].reset();
					$("#myTable2 tbody tr").remove();
					bootbox.alert("Successfully created.");
				}else if(data.message=="updated"){
					$("#frmEntry")[0].reset();
					$("#myTable2 tbody tr").remove();
					bootbox.alert("Successfully updated.");
					$(".btnAddPack").css("display", "");
					$(".btnEditPack").css("display", "none");
				}else if(data.message=="session expire"){
					bootbox.alert("Session Expire! Please refresh the browser and login again.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	} 
</script>	
