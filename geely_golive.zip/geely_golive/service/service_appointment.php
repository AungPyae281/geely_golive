<?php include '../header.php'; ?> 
<style> 
	.displayNone{
		display: none;
	}
	.badge{
		padding: 5px 12px;
		font-size: 11px;
		margin-right: 3px;
	}
	.col-form-label{
		padding-top: 1px !important;
	}
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Service Appointment - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Input</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.: </label>
											<div class="col-md-8">
												<div class="input-group input-group">
													<input id="txtPlateNo" value="" class="form-control" readonly>
													<span class="input-group-btn">
														<button type="button" class="btn btn-primary" onclick="getAllServiceCar()" id="btnPlateNo" style="padding-bottom: 3px;">. . .</button>
													</span>
													<input type="hidden" id="txtServiceCarID">   
													<input type="hidden" id="txtServiceCustomerID">      
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-12" style="display:none;">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Valid Warranty: </label>
											<div class="col-md-8" id="ValidWarranty"></div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Service Center: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtServiceCenter" disabled value="<?=$_SESSION['service_center']?>">
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Appointment Type: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboAppointmentType">
													<option value="follow up (weekly)" data-id="">Follow up (weekly)</option>
													<option value="customer request" data-id="">Customer request</option>
													<option value="walk-in" data-id="">Walk-in</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Appointment Date: </label>
											<div class="col-md-8">
												<div class="input-group input-append date" id="datePicker" data-date="2023-02-10" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Appointment Time: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboHours" style="text-align:right;">
													<option value="00:00">00:00</option>
													<option value="01:00">01:00</option>
													<option value="02:00">02:00</option>
													<option value="03:00">03:00</option>
													<option value="04:00">04:00</option>
													<option value="05:00">05:00</option>
													<option value="06:00">06:00</option>
													<option value="07:00">07:00</option>
													<option value="08:00">08:00</option>
													<option value="09:00" selected>09:00</option>
													<option value="10:00">10:00</option>
													<option value="11:00">11:00</option>
													<option value="12:00">12:00</option>
													<option value="13:00">13:00</option>
													<option value="14:00">14:00</option>
													<option value="15:00">15:00</option>
													<option value="16:00">16:00</option>
													<option value="17:00">17:00</option>
													<option value="18:00">18:00</option>
													<option value="19:00">19:00</option>
													<option value="20:00">20:00</option>
													<option value="21:00">21:00</option>
													<option value="22:00">22:00</option>
													<option value="23:00">23:00</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Contact Person: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtContactPerson">
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Contact Phone: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtContactPhone">
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Total Waiting Time: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" style="text-align:right;" id="txtTotalWaitingTime" value="00:00" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row">
											<div class="col-md-8"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="validateAndSave()">Create</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>

						<center>
							<div class="modal fade" id="myModalServiceCarList">
								<div class="modal-dialog" style="max-width: 100% !important;">
									<div class="modal-content" style="width: 70%; top: 29px;">
										<div class="modal-header" style="padding: 12px;">
											<h4 class="modal-title">Service Car List</h4>
											<button type="button" class="btn btn-success btn-sm" onclick="goToNewServiceCar();" style="font-size: 14px; padding-left: 15px; padding-right: 15px; margin-left: 10px;"><i class="fas fa-user-plus"></i> Add New</button>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
											<table id="myTable1" class="table table-head-fixed" style="cursor:pointer;">
												<thead>
													<tr>
														<th>No.</th>
														<th>Plate No.</th>
														<th>Name</th>
														<th>Phone No.</th>
														<th>Brand</th>
														<th>Model</th>
														<th>Model Year</th>
														<th>Exterior Color</th>
														<th>Warranty</th>
														<th style="display:none;">Service Car ID</th>
														<th style="display:none;">Service Customer ID</th>
													</tr>
												</thead>
												<tbody></tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</center>
					</div>
				</div>
				<div class="col-md-8">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Services List</h3>
						</div> 
						<form role="form" id="frmEntry">
							<div class="card-body" style="padding: 0px;">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group" style="overflow-y: auto; overflow-x: auto; height: auto; margin-bottom: 0px !important;">
											<table class="table table-responsive-sm table-bordered" id="myTable" style="margin-bottom: 0px;">
												<thead>
													<tr>
														<th>#</th>
														<th>Services</th>
														<th data-date="" style='text-align:center;' id="thDate1"></th>
														<th data-date="" style='text-align:center;' id="thDate2"></th>
														<th data-date="" style='text-align:center;' id="thDate3"></th>
														<th data-date="" style='text-align:center;' id="thDate4"></th>
														<th data-date="" style='text-align:center;' id="thDate5"></th>
													</tr>
												</thead>
												<tbody></tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>  
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse");
		$('#datePicker').datepicker();  
		getServices(); 
	});

	$('#cboServiceCenter').change(function(){
		getServices();
	}); 

	$('#txtDatePicker').change(function(){
		getServices();
	}); 

	$('#cboHours').change(function(){
		getServices();
	});  

	function getServices(){
		var service_center = $("#txtServiceCenter").val();
		var time = $("#cboHours").val();
		var start_date = $("#txtDatePicker").val();
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			type: "POST",
			url: APP_URL + "api/service/service_appointment/get_available_services.php",
			data: JSON.stringify({ start_date: start_date, time: time, service_center: service_center })
		}).done(function(data) {
			for (var x = 1; x <= 5; x++) {
				$("#thDate" + x).text(data[x] + " " + time);
			}

			$.each(data.records, function(i, v) {	
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td style='text-align:center;'><div class='icheck-success d-inline'><input type='checkbox' id='chk" + v.id + "' data-id=" + v.id + " data-time=" + v.waiting_time + " onclick='calTotalWaitingTime(this);'><label for='chk" + v.id + "'></label></div></td>")
					.append("<td>" + v.name + "</td>")
					.append("<td style='text-align:center;'>" + v.col1 + "/" + v.aval_qty + "</td>")
					.append("<td style='text-align:center;'>" + v.col2 + "/" + v.aval_qty + "</td>")
					.append("<td style='text-align:center;'>" + v.col3 + "/" + v.aval_qty + "</td>")
					.append("<td style='text-align:center;'>" + v.col4 + "/" + v.aval_qty + "</td>")
					.append("<td style='text-align:center;'>" + v.col5 + "/" + v.aval_qty + "</td>")
					);
			});
			$("#txtTotalWaitingTime").val("00:00");
		}) ;
	}

	function getAllServiceCar(){
		table = $('#myTable1').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			'columnDefs': [	
			{
				'targets': [9, 10],
				"className": 'displayNone'
			}
			],
			"ajax": APP_URL + "api/service/service_car/get_all_service_car.php"
		});	 
		$("#myModalServiceCarList").modal('show');
	}

	$('#myTable1').on('click', 'tbody tr', function(e){
		$("#myTable1 tbody tr").css("color","");
		$("#myTable1 tbody tr").css("background-color","");
		$(this).css("color", "rgb(34, 126, 140)");
		$(this).css("background-color", "#e3ecf5");

		$("#txtPlateNo").val($(this).find("td").eq(1).text());
		$("#txtContactPerson").val($(this).find("td").eq(2).text());
		$("#txtContactPhone").val($(this).find("td").eq(3).text());
		$("#txtServiceCarID").val($(this).find("td").eq(9).text());
		$("#txtServiceCustomerID").val($(this).find("td").eq(10).text());

		if($(this).find("td").eq(8).text()==""){
			$("#ValidWarranty").parent().parent().css("display", "none");
		}else{
			$("#ValidWarranty").empty();
			$("#ValidWarranty").parent().parent().css("display", "");

			$.each($(this).find("td").eq(8).text().split(","), function(i, v){
				$("#ValidWarranty").append('<span class="badge bg-primary">' + v + '</span>');
			});
		}
		$("#myModalServiceCarList").modal('hide');
	});

	function validateAndSave(){
		var item_lists = [];
		$("#myTable tbody tr td input[type='checkbox']:checked").each(function (){
			var detail = {
				"service_item_id" : $(this).attr("data-id"),
				"waiting_time" : $(this).attr("data-time")
			}
			item_lists.push(detail);
		});

		var service_appointment = {
			"service_car_id" : $("#txtServiceCarID").val(),
			"service_customer_id" : $("#txtServiceCustomerID").val(),
			"plate_no" : $("#txtPlateNo").val(),
			"appointment_type" : $("#cboAppointmentType").val(),
			"appointment_date" : $("#txtDatePicker").val(),
			"appointment_time" : $("#cboHours").val(),
			"contact_person" : $("#txtContactPerson").val(),
			"contact_phone" : $("#txtContactPhone").val(), 
			"service_center" : $("#txtServiceCenter").val(),
			"total_waiting_time" : $("#txtTotalWaitingTime").val(),
			"details" : item_lists
		};

		if($("#txtPlateNo").val()==""){
			bootbox.alert("Please choose plate no.");
		}else if($("#txtTotalWaitingTime").val()=="00:00"){
			bootbox.alert("Please choose at least one service item.");
		}else if($("#txtServiceCenter").val()==""){
			bootbox.alert("Please choose the service center.");
		}else{
			$("#loading").css("display","block");
			$.ajax({
				url: APP_URL + "api/service/service_appointment/create.php",
				type: "POST",
				data: JSON.stringify(service_appointment)
			}).done(function(data) {
				$("#loading").css("display","none");
				if(data.message=="created"){
					bootbox.alert("Appointment created.");
					$("#txtPlateNo").val("");
					$("#txtDatePicker").val(customDate);
					$('#datePicker').datepicker("setDate", customDate);
					$("#txtContactPerson").val("");
					$("#txtContactPhone").val("");
					$("#txtServiceCarID").val("");
					$("#txtServiceCustomerID").val("");
					$("#txtTotalWaitingTime").val("00:00");
					$("#ValidWarranty").parent().parent().css("display", "none");
					getServices();
				}else if(data.message=="duplicate"){
					bootbox.alert("Plate No. (" + data.plate_no + ") has already made appointment for " + $("#txtDatePicker").val() + ".");
				}else if(data.message=="session expire"){
					bootbox.alert("Session Expire! Please refresh the browser and login again.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function calTotalWaitingTime(obj){
		if($(obj).is(":checked")){
			startTime = $("#txtTotalWaitingTime").val();
			var waitingtime = $(obj).attr("data-time");
			totalWaitingTime = timeFromMins(timeToMins(startTime) + timeToMins(waitingtime));
		}else{
			startTime = $("#txtTotalWaitingTime").val();
			var waitingtime = $(obj).attr("data-time");
			totalWaitingTime = timeFromMins(timeToMins(startTime) - timeToMins(waitingtime));
		}
		$("#txtTotalWaitingTime").val(totalWaitingTime);
	}

	function goToNewServiceCar(){
		window.open(APP_URL + "service/service_car.php");
	}

	function timeFromMins(mins) {
		function z(n){return (n<10? '0':'') + n;}
		var h = (mins/60 |0) % 24;
		var m = mins % 60;
		return z(h) + ':' + z(m);
	}

	function timeToMins(time) {
		var b = time.split(':');
		return b[0]*60 + +b[1];
	}
</script>	
