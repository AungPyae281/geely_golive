<?php include '../header.php'; ?>
<?php
	$id = "";
	if(isset($_GET['id'])){
		if(!empty($_GET['id'])){
			$id = $_GET['id'];
		}
	}
?>
<style>
	.form-group{
		font-size: 13px !important;
	}

	.col-form-label {
		padding-top: calc(0.20rem + 1px);
		padding-bottom: calc(0.375rem + 1px);
		margin-bottom: 0;
		font-size: 13px;
		line-height: 1.2;
	}

	.form-control {
		display: block;
		width: 100%;
		height: calc(1.11rem + 11px);
		padding: 0.375rem 0.75rem;
		font-size: 0.9rem;
		font-weight: 400;
		line-height: 1.2;
		color: #495057;
		background-color: #ffffff;
		background-clip: padding-box;
		border: 1px solid #ced4da;
		border-radius: 0.25rem;
		box-shadow: inset 0 0 0 rgba(0, 0, 0, 0);
		transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
	}

	.card-header {
		background-color: transparent;
		border-bottom: 1px solid rgba(0, 0, 0, 0.125);
		position: relative;
		padding: 0.35rem 1.10rem;
		border-top-left-radius: 0.25rem;
		border-top-right-radius: 0.25rem;
	}

	.btn{
		font-size: 13px;
		line-height: 1.4;
	}

	.table th, .table td {
		padding: 0.40rem;
	} 

	#myTableFinalInspection tr{
		display:none;
	}

	#myTableFinalInspection th{
		border-right:none;
	}

	#myTableFinalInspection td{
		width: 5%;
		border-left:none;
	}

	#myTableFinalInspection .icheck-success{
		float: right;
		margin-top: 0px !important;
		margin-bottom: 0px !important;
	}

	.breadcrumb-item {
		color: gray;
	}

	.breadcrumb-item.done{
		color: #000;
	}

	.breadcrumb-item.active {
		color: #000 !important;
		font-weight: bold;
	}

	.breadcrumb-item + .breadcrumb-item:before{
		content: ">" !important;
		font-weight: normal !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Final Inspection</h1>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item">Arrival Inspection</li>
						<li class="breadcrumb-item">Service</li>
						<li class="breadcrumb-item">Job Card</li>
						<li class="breadcrumb-item active">Final Inspection</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="card-body">	
							<div class="row">
								<div class="col-md-6">
									<div class="form-group row"> 
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Center: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceCenter" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceRegistrationNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Owner Name: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtOwnerName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Owner Phone: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtOwnerPhone" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Contact Person: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceContactPerson" data-id="" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Contact Phone: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceContactPhone" value="" disabled>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtPlateNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Model Name: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtModelName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Vin No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtVinNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Engine No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtEngineNo" value="" disabled>
										</div>
									</div> 
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Kilometer: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtKilometer" value="" disabled style="text-align:right;">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Car Receive Date/Time: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtCarReceiveDateTime" value="" disabled>
										</div>
									</div>
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label"></label>
										<div class="col-md-8">
											<table class="table table-bordered" id="myTableFinalInspection">
												<tbody>
													<tr id="tdServiceBooklet">
														<th>Service Booklet</th>
														<td><div class="icheck-success d-inline"><input id="chkServiceBooklet" type="checkbox"><label for="chkServiceBooklet"></label></div></td>
													</tr>
													<tr id="tdJackandHandle">
														<th>Jack and Handle</th>
														<td><div class="icheck-success d-inline"><input id="chkJackandHandle" type="checkbox"><label for="chkJackandHandle"></label></div></td>
													</tr>
													<tr id="tdPakingSign">
														<th>Paking Sign</th>
														<td><div class="icheck-success d-inline"><input id="chkPakingSign" type="checkbox"><label for="chkPakingSign"></label></div></td>
													</tr>
													<tr id="tdSpareWheel">
														<th>Spare Wheel</th>
														<td><div class="icheck-success d-inline"><input id="chkSpareWheel" type="checkbox"><label for="chkSpareWheel"></label></div></td>
													</tr>
													<tr id="tdMobileCharger">
														<th>Mobile Charger</th>
														<td><div class="icheck-success d-inline"><input id="chkMobileCharger" type="checkbox"><label for="chkMobileCharger"></label></div></td>
													</tr>
													<tr id="tdCarKey">
														<th>Car Key</th>
														<td><div class="icheck-success d-inline"><input id="chkCarKey" type="checkbox"><label for="chkCarKey"></label></div></td>
													</tr>
													<tr id="tdWheelTax">
														<th>Wheel Tax</th>
														<td><div class="icheck-success d-inline"><input id="chkWheelTax" type="checkbox"><label for="chkWheelTax"></label></div></td>
													</tr>
													<tr id="tdFuelLevel">
														<th><span>Fuel Level: </span><span id="txtFuelLevel"></span></th>
														<td><div class="icheck-success d-inline"><input id="chkFuelLevel" type="checkbox"><label for="chkFuelLevel"></label></div></td>
													</tr>
													<tr id="tdOtherItems">
														<th><span>Other Items: </span><span id="txtOtherItems"></span></th>
														<td><div class="icheck-success d-inline"><input id="chkOtherItems" type="checkbox"><label for="chkOtherItems"></label></div></td>
													</tr>
													<tr id="tdRemark">
														<th><span>Remark: </span><span id="txtRemark"></span></th>
														<td><div class="icheck-success d-inline"><input id="chkRemark" type="checkbox"><label for="chkRemark"></label></div></td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">All Customer Complaint Attended and Verified:</label>
										<div class="col-md-8">
											<div class="custom-control custom-radio">
												<div class="row">
													<div class="col-md-3">
														<input class="custom-control-input" type="radio" id="optCustomerComplaintYes" value="1" name="optCustomerComplaint" checked>
														<label for="optCustomerComplaintYes" class="custom-control-label">Yes</label>
													</div>
													<div class="col-md-3">
														<input class="custom-control-input" type="radio" id="optCustomerComplaintNo" value="0" name="optCustomerComplaint">
														<label for="optCustomerComplaintNo" class="custom-control-label">No</label>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">All Customer Items Restored to Position:</label>
										<div class="col-md-8">
											<div class="custom-control custom-radio">
												<div class="row">
													<div class="col-md-3">
														<input class="custom-control-input" type="radio" id="optRestoredPositionYes" value="1" name="optRestoredPosition" checked>
														<label for="optRestoredPositionYes" class="custom-control-label">Yes</label>
													</div>
													<div class="col-md-3">
														<input class="custom-control-input" type="radio" id="optRestoredPositionNo" value="0" name="optRestoredPosition">
														<label for="optRestoredPositionNo" class="custom-control-label">No</label>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Road Test Done Along With Customer:</label>
										<div class="col-md-8">
											<div class="custom-control custom-radio">
												<div class="row">
													<div class="col-md-3">
														<input class="custom-control-input" type="radio" id="optRoadTestDoneYes" value="1" name="optRoadTestDone" checked>
														<label for="optRoadTestDoneYes" class="custom-control-label">Yes</label>
													</div>
													<div class="col-md-3">
														<input class="custom-control-input" type="radio" id="optRoadTestDoneNo" value="0" name="optRoadTestDone">
														<label for="optRoadTestDoneNo" class="custom-control-label">No</label>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Battery Health:</label>
										<div class="col-md-8">
											<div class="custom-control custom-radio">
												<div class="row">
													<div class="col-md-3">
														<input class="custom-control-input" type="radio" id="optBatteryHealthGood" value="Good" name="optBatteryHealth" checked>
														<label for="optBatteryHealthGood" class="custom-control-label">Good</label>
													</div>
													<div class="col-md-3">
														<input class="custom-control-input" type="radio" id="optBatteryHealthAverage" value="Average" name="optBatteryHealth">
														<label for="optBatteryHealthAverage" class="custom-control-label">Average</label>
													</div>
													<div class="col-md-3">
														<input class="custom-control-input" type="radio" id="optBatteryHealthPoor" value="Poor" name="optBatteryHealth">
														<label for="optBatteryHealthPoor" class="custom-control-label">Poor</label>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-9 col-form-label"></label>
										<div class="col-md-3">
											<button type="button" class="btn btn-block btn-success" onclick="validateAndSave()">Submit</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div> 
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script> 
    var id = '<?= $id ?>';

	$(function() {
		$("body").addClass("sidebar-collapse"); 
		getOneService();
	});
 
	function getOneService(){
		$.ajax({
			url: APP_URL + "api/service/service/get_one_service.php",
			type: "POST",
			data: JSON.stringify({ id: id }),
		}).done(function(data){
			var tf = false;
			$(".breadcrumb-item").removeClass("done");
			$(".breadcrumb-item").removeClass("active");
			$(".breadcrumb-item").each(function(){
				if(tf){
					$(this).addClass("active");
					return false;
				}else{
					$(this).addClass("done");
				}
				if($(this).text()==data.status){
					tf = true;
				}
			});

			$("#txtServiceCenter").val(data.service_center);
			$("#txtServiceRegistrationNo").val(data.registration_no);
			$("#txtOwnerName").val(data.owner_name);
			$("#txtOwnerPhone").val(data.owner_phone);
			$("#txtServiceContactPerson").val(data.contact_person);
			$("#txtServiceContactPerson").attr("data-id", data.service_customer_id);
			$("#txtServiceContactPhone").val(data.contact_phone);
			$("#txtPlateNo").val(data.plate_no);
			$("#txtModelName").val(data.model);
			$("#txtVinNo").val(data.vin_no);
			$("#txtEngineNo").val(data.engine_no);
			$("#txtKilometer").val(data.kilometer);
			$("#txtCarReceiveDateTime").val(data.car_receive_date + " " + data.car_receive_time);

			if(data.insp_service_booklet==1){
				$("#tdServiceBooklet").css("display", "table-row");
			}

			if(data.insp_jack_and_handle==1){
				$("#tdJackandHandle").css("display", "table-row");
			}

			if(data.insp_paking_sign==1){
				$("#tdPakingSign").css("display", "table-row");
			}

			if(data.insp_spare_wheel==1){
				$("#tdSpareWheel").css("display", "table-row");
			}

			if(data.insp_mobile_charger==1){
				$("#tdMobileCharger").css("display", "table-row");
			}

			if(data.insp_car_key==1){
				$("#tdCarKey").css("display", "table-row");
			}

			if(data.insp_wheel_tax==1){
				$("#tdWheelTax").css("display", "table-row");
			}

			$("#txtFuelLevel").text(data.insp_fuel_level);
			$("#tdFuelLevel").css("display", "table-row");

			if(data.insp_other_items!=""){
				$("#txtOtherItems").text(data.insp_other_items);
				$("#tdOtherItems").css("display", "table-row");
			}

			if(data.insp_remark!=""){
				$("#txtRemark").text(data.insp_remark);
				$("#tdRemark").css("display", "table-row");
			}
		});		
	}

	function validateAndSave(){ 
		var service_booklet = (($("#chkServiceBooklet").prop("checked"))?1:0);
		var jack_and_handle = (($("#chkJackandHandle").prop("checked"))?1:0);
		var paking_sign = (($("#chkPakingSign").prop("checked"))?1:0);
		var spare_wheel = (($("#chkSpareWheel").prop("checked"))?1:0);
		var mobile_charger = (($("#chkMobileCharger").prop("checked"))?1:0);
		var car_key = (($("#chkCarKey").prop("checked"))?1:0);
		var wheel_tax = (($("#chkWheelTax").prop("checked"))?1:0);
		var fuel_level = (($("#chkFuelLevel").prop("checked"))?1:0);
		var other_items = (($("#chkOtherItems").prop("checked"))?1:0);
		var remark = (($("#chkRemark").prop("checked"))?1:0);
		var customer_complaint = parseInt($("input[name='optCustomerComplaint']:checked").val());
		var restored_position = parseInt($("input[name='optRestoredPosition']:checked").val());
		var road_test_done = parseInt($("input[name='optRoadTestDone']:checked").val());
		var battery_health = $("input[name='optBatteryHealth']:checked").val();

		$.ajax({
			url: APP_URL + "api/service/service/create_final_inspection.php",
			type: "POST",
			data: JSON.stringify({ id: id, service_booklet: service_booklet, jack_and_handle: jack_and_handle, paking_sign: paking_sign, spare_wheel: spare_wheel, mobile_charger: mobile_charger, car_key: car_key, wheel_tax: wheel_tax, fuel_level: fuel_level, other_items: other_items, remark: remark, customer_complaint: customer_complaint, restored_position: restored_position, road_test_done: road_test_done, battery_health: battery_health })
		}).done(function(data) {
			if(data.message=="created"){ 
				document.location = APP_URL + "service/servicing_list.php"; 
			}else if(data.message=="session expire"){
				bootbox.alert("Session Expire! Please refresh the browser and login again.");
			}else{
				bootbox.alert("Error on server side.");
			}
		});
	} 
</script>	
