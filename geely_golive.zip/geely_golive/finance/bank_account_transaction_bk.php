<?php include '../header.php'; ?> 
<style>
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Bank Account Transaction - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-5">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-3 col-form-label" style="text-align: right;">Date: </label>
											<div class="col-md-8">  
												<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
												</div>
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<label class="col-md-3 col-form-label" style="text-align: right;">Account: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboBankAccount"></select>
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<label class="col-md-3 col-form-label" style="text-align: right;">Balance: </label>
											<div class="col-md-5">
												<input type="text" class="form-control" id="txtBalance" disabled style="text-align:right;" value="0">
											</div>
											<div class="col-md-3">
												<input type="text" class="form-control" id="txtCurrency" Disabled>
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<label class="col-md-3 col-form-label" style="text-align: right;">Reason:</label>
											<div class="col-md-8">
												<textarea class="form-control" id="txtReason" rows="2"></textarea>
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<label class="col-md-3 col-form-label" style="text-align: right;"></label>
											<div class="col-md-8" style="padding-top: 6px;">
												<label class="control-label col-md-3">
													<input id="optDebit" name="optType" value="Debit" type="radio" checked>
													Debit
												</label>
												<label class="control-label col-md-3">
													<input id="optCredit" name="optType" value="Credit" type="radio">
													Credit
												</label>
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<label class="col-md-3 col-form-label" style="text-align: right;">Amount: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtAmount" value="0" style="text-align:right;">
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<div class="col-md-7"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="validateAndSave()">Add</button>
											</div>
											<div class="col-md-1"></div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-7">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"> </span></h3>
						</div>
						<div class="card-body p-0" style="max-height: 450px; overflow: auto;">
							<table class="table table-striped table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th>
										<th>Date</th>
										<th>Bank Account</th>
										<th>Reason</th>
										<th>Debit</th>
										<th>Credit</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM") + 1);
	var dd = d.getDate();
  	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse");
		$('#datePicker').datepicker();
		getAllBankAccount();
	});

	$("#txtAmount").on("input", function(){
		isNumberDecimal(this);
	});

	$('#cboBankAccount').on('change',function(){
		if($("#cboBankAccount").val()!=""){
			$("#txtBalance").val(parseFloat($("#cboBankAccount option:selected").attr("data-balance")).toLocaleString());
			$("#txtCurrency").val($('#cboBankAccount option:selected').attr('data-currency'));
		}else{
			$("#txtBalance").val(0);
			$("#txtCurrency").val("");
		}
		getAllRows();
	});

	$("#txtDatePicker").change(function(){
		getAllRows();
	});

	function getAllBankAccount(){
		$("#txtCurrency").val("");
		$("#cboBankAccount").find("option").remove();
		$("#cboBankAccount").append("<option value='' data-id='' data-currency='' data-balance='0'></option>");

		$.ajax({
			url: APP_URL + "api/finance/bank_account/get_all_bank_account.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				$("#cboBankAccount").append("<option value = '" + v.account_no + "' data-id = '" + v.id + "' data-currency = '" + v.currency + "' data-balance = '" + v.balance + "'>" + v.account_no + " (" + v.account_name + ")</option>");
			});
			getAllRows();
		});
	}

	function validateAndSave(){
		var date = $("#txtDatePicker").val();
		var bank_account = $("#cboBankAccount").val();
		var reason = $("#txtReason").val();
		var amount = parseFloat($("#txtAmount").val().replace(/,/g, ''));
		var debit = ($("#optDebit").prop("checked"))?amount:0;
		var credit = ($("#optCredit").prop("checked"))?amount:0;

		if(bank_account==""){
			bootbox.alert("Please choose bank account.");
		}else if(reason==""){
			bootbox.alert("Please fill reason.");
		}else if(amount==0){
			bootbox.alert("Please fill amount");
		}else{
			$("#loading").css("display", "block");
			$.ajax({
				url: APP_URL + "api/finance/bank_account_transaction/create.php",
				type: "POST",
				data: JSON.stringify({ date: date, bank_account: bank_account, reason: reason, debit: debit, credit: credit }),
			}).done(function(data){
				$("#loading").css("display", "none");
				if(data.message=="created"){
					getAllBankAccount();
					$("#txtAmount").val(0);
					bootbox.alert("Successfully Added.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function getAllRows(){ 
        var date = $("#txtDatePicker").val();
        var bank_account = $("#cboBankAccount").val();
        $("#myTable").find("tbody").find("tr").remove();
        $.ajax({
            type: "POST",
            url: APP_URL + "api/finance/bank_account_transaction/get_all_rows.php",
            data: JSON.stringify({ date: date, bank_account: bank_account })
        }).done(function(data) { 
            if(data.records.length>1){
            	$("#total_records").text(" - " + data.records.length + " records found.");
            }else{
            	$("#total_records").text(" - " + data.records.length + " record found.");
            }

            $.each(data.records, function(i, v) {
                $("#myTable").find("tbody")
                .append($('<tr>')
                    .append("<td>" + (i + 1) + "</td>")
                    .append("<td>" + v.date + "</td>")
                    .append("<td>" + v.bank_account + "</td>")
                    .append("<td>" + v.reason + "</td>")
                    .append("<td style='text-align: right; padding-right: 20px;'>" + v.debit.toLocaleString() + "</td>")
                    .append("<td style='text-align: right; padding-right: 20px;'>" + v.credit.toLocaleString() + "</td>")
                )
            });
        });
    } 

    function isNumberDecimal(obj) {
        var val = obj.value;
        var re = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)$/g;
        var re1 = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)/g;
        if(!re.test(val)) {
        	val = re1.exec(val);
            if (val) {
                obj.value = val[0];
            } else {
                obj.value = 0;
            }
        }
    }
</script>	
