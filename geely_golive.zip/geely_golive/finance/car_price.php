<?php include '../header.php'; ?>
<style>
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper">
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Car Price - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
				<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div> 
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Brand: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboBrand"></select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Model: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboModel"></select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Model Year: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboModelYear"></select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Grade: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboGrade"></select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Interior Color: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboInteriorColor"></select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Exterior Color: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboExteriorColor"></select>
											</div>
										</div>
									</div>
								</div>	
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-9">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">
								Car List <span id="total_records" style="font-weight:bold;"></span>
							</h3>
						</div>
						<div class="card-body p-0" style="max-height: auto; overflow: auto;">
							<table class="table table-bordered" id="myTable">
								<thead>
									<tr>
										<th style='width: 3%; text-align: center; vertical-align: middle;'>#</th>
										<th style='text-align: center; vertical-align: middle;'>Car Info</th>
										<th style='text-align: center; vertical-align: middle;'>Interior Color</th> 
										<th style='text-align: center; vertical-align: middle;'>Exterior Color</th>
										<th style='text-align: center; vertical-align: middle;'>Vehicle Price</th>
										<th style='text-align: center; vertical-align: middle;'>RTAD Tax</th>
										<th style='text-align: center; vertical-align: middle;'>Commerical Tax</th>
										<th style='text-align: center; vertical-align: middle;'>RRP</th>
										<th style='width: 2%; text-align: center; vertical-align: middle;'><div class='col-lg-12 icheck-success d-inline'><input type='checkbox' id='chkSelectAll'><label for='chkSelectAll'>All</label></div></th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Date (From): </label>
										<div class="col-md-8">  
											<div class="input-group input-append date" id="datePicker1" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
												<div class="input-group-prepend">
													<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
														<i class="far fa-calendar-alt"></i>
													</span>
												</div>
												<input type="text" class="form-control float-right" id="txtDatePicker1" value="1982-06-15" readonly>
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Date (To): </label>
										<div class="col-md-8">  
											<div class="input-group input-append date" id="datePicker2" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
												<div class="input-group-prepend">
													<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
														<i class="far fa-calendar-alt"></i>
													</span>
												</div>
												<input type="text" class="form-control float-right" id="txtDatePicker2" value="1982-06-15" readonly>
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Vehicle Price: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtVehiclePrice" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);" value="0" style="text-align:right" maxlength="13">
										</div>
									</div>
									<div class="form-group row">
										<div class="col-md-4"></div>
										<div class="col-md-8">
											<button type="button" class="btn btn-success btn-block makeInvoice" onclick="validateAndSave()">Change Price</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker1').attr("data-date",customDate);
	$("#txtDatePicker1").val(customDate);
	$('#datePicker2').attr("data-date",customDate);
	$("#txtDatePicker2").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");	
		$('#datePicker1').datepicker();
		$('#datePicker2').datepicker();

		fillBrand();
		getAllCarList();
		fillExteriorColor();
		fillInteriorColor();
	});

	$("#chkSelectAll").click(function() { 
	    if ($(this).is(':checked')) {
	        $('input:checkbox').prop('checked', true);	
	    } else {
	        $('input:checkbox').prop('checked', false);	
	    }
	});

	$("#cboBrand").change(function(){
		fillModel();
		getAllCarList();
    });

	$("#cboModel").change(function(){
		getModelYear();
		getAllCarList();
	});

	$("#cboModelYear").change(function(){
		fillGrade();
		getAllCarList();
	}); 

	$("#cboGrade").change(function(){
		getAllCarList();
	}); 

	$("#cboExteriorColor").change(function(){
		getAllCarList();
	}); 

	$("#cboInteriorColor").change(function(){
		getAllCarList();
	}); 

	function fillBrand(){
        $("#cboBrand").find("option").remove();
        $("#cboBrand").append("<option value='' data-id=''></option>");

        $.ajax({
            url: APP_URL + "api/supply_chain/brand/get_all_rows.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboBrand").append("<option value='" + v.brand + "' data-id='" + v.id + "'>" + v.brand + "</option>");
            });
            fillModel();
        });
    }

    function fillModel(){
        var brand = $("#cboBrand").val();
        $("#cboModel").find("option").remove();
        $("#cboModelYear").find("option").remove();
        $("#cboGrade").find("option").remove();

        if(brand){
            $.ajax({
                url: APP_URL + "api/supply_chain/model/get_model_by_brand.php",
                type: "POST",
                data: JSON.stringify({ brand: brand })
            }).done(function(data) {
        		if(data.records.length>0) $("#cboModel").append("<option value='' data-id=''></option>");
                $.each(data.records, function(i, v) {
                    $("#cboModel").append("<option value='" + v.model + "' data-id='" + v.id + "'>" + v.model + "</option>");
                });
                getModelYear();
            });
        }
    }

    function getModelYear(){
        var model = $("#cboModel").val();
        $("#cboModelYear").find("option").remove();
        $("#cboGrade").find("option").remove();

        if(model){
            $.ajax({
                url: APP_URL + "api/supply_chain/model/get_model_year_by_model.php",
                type: "POST",
                data: JSON.stringify({ model: model })
            }).done(function(data) {
        		if(data.records.length>0) $("#cboModelYear").append("<option value='' data-id=''></option>");
                $.each(data.records, function(i, v) {
                    $("#cboModelYear").append("<option value='" + v.model_year + "' data-id='" + v.id + "'>" + v.model_year + "</option>");
                });
                fillGrade();
            });
        }
    }

    function fillGrade(){
        var model_id = $("#cboModelYear option:selected").attr("data-id");
        $("#cboGrade").find("option").remove();

        if(model_id){
            $.ajax({
                url: APP_URL + "api/supply_chain/grade/get_all_grade.php",
                type: "POST",
                data: JSON.stringify({ model_id: model_id })
            }).done(function(data) {
        		if(data.records.length>0) $("#cboGrade").append("<option value='' data-id=''></option>");
                $.each(data.records, function(i, v) {
                    $("#cboGrade").append("<option value='" + v.grade + "' data-id='" + v.id + "'>" + v.grade + "</option>");
                });
            });
        }
    }

    function fillExteriorColor(){
    	$("#cboExteriorColor").find("option").remove();
    	$("#cboExteriorColor").append("<option value=''></option>");

        $.ajax({
            url: APP_URL + "api/supply_chain/exterior/get_all_rows.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboExteriorColor").append("<option value='" + v.color + "'>" + v.color + "</option>");
            });
        });
    }

    function fillInteriorColor(){
    	$("#cboInteriorColor").find("option").remove();
    	$("#cboInteriorColor").append("<option value=''></option>");

        $.ajax({
            url: APP_URL + "api/supply_chain/interior/get_all_rows.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboInteriorColor").append("<option value='" + v.color + "'>" + v.color + "</option>");
            });
        });
    }

	function getAllCarList(){ 
		var brand = $("#cboBrand").val();
		var model = $("#cboModel").val();
		var model_year = $("#cboModelYear").val();
		var grade = $("#cboGrade").val();
		var exterior_color = $("#cboExteriorColor").val();
		var interior_color = $("#cboInteriorColor").val();
		$("#myTable").find("tbody").find("tr").remove();

		$.ajax({
			type: "POST",
			url: APP_URL + "api/supply_chain/car_list/get_car_list_for_price_change.php",
			data: JSON.stringify({ brand: brand, model: (model)?model:"", model_year: (model_year)?model_year:"", grade: (grade)?grade:"", exterior_color: exterior_color, interior_color: interior_color })
		}).done(function(data) { 
			if(data.records.length>1){
				$("#total_records").text(" - " + data.records.length + " records found.");
			}else{
				$("#total_records").text(" - " + data.records.length + " record found.");
			}

			$.each(data.records, function(i, v) { 
				var ct = v.vehicle_price * 0.05;
				var rrp_price = (parseInt(v.vehicle_price) + parseInt(v.rtad_tax) + parseInt(ct));

				$("#myTable").find("tbody")
				.append($('<tr data-id="' + v.id + '">')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + (v.brand + ", " + v.model + ", " + v.model_year + ", " + v.grade + ", " + v.engine_power) + "</td>")
					.append("<td>" + v.interior_color + "</td>") 
					.append("<td>" + v.exterior_color + "</td>") 
					.append("<td style='text-align: right;'>" + v.vehicle_price.toLocaleString() + "</td>")
					.append("<td style='text-align: right;'>" + v.rtad_tax.toLocaleString() + "</td>")
					.append("<td style='text-align: right;'>" + ct.toLocaleString() + "</td>")
					.append("<td style='text-align: right;'>" + rrp_price.toLocaleString() + "</td>")
					.append("<td style='text-align:center;'><div class='icheck-success d-inline'><input type='checkbox' id='" + v.id + "'><label for='" + v.id + "'></label></div></td>")
				);				
			});
		});
	}

	function validateAndSave(){  
		var date_from = $("#txtDatePicker1").val();
		var date_to = $("#txtDatePicker2").val();
		var vehicle_price = parseInt($("#txtVehiclePrice").val().replace(/,/g, ''));

		var car_list = [];
		$("#myTable tbody tr td input[type='checkbox']").each(function (){
			var ischecked = $(this).is(":checked");
			if(ischecked){
				var car = {
					"id" : $(this).parent().parent().parent().attr("data-id"), 
					"old_vehicle_price" : parseInt($(this).parent().parent().parent().find("td").eq(4).text().replace(/,/g, ''))
				}
				car_list.push(car);
			}
		}); 
 
		if(car_list.length==0){
			bootbox.alert("Please choose at least one car.");
		}else if(vehicle_price==0){
			bootbox.alert("Please fill vehicle price.");
		}else{
			bootbox.confirm({
	        	message: "<h4>Are you sure that you want to change car price?</h4>",
	        	buttons: {
	        		confirm: {
	        			label: '<span class="glyphicon glyphicon-ok"></span> Yes',
	        			className: 'btn-primary'
	        		},
	        		cancel: {
	        			label: '<span class="glyphicon glyphicon-remove"></span> No',
	        			className: 'btn-danger'
	        		}
	        	},
	        	callback: function (result) {
	        		if(result){
	        			$("#loading").css("display", "block");
						$.ajax({
							url: APP_URL + "api/finance/car_price_change/create.php",
							type: "POST",
							data: JSON.stringify({ date_from: date_from, date_to: date_to, vehicle_price: vehicle_price, car_list: car_list })
						}).done(function(data) {
							$("#loading").css("display", "none");
							if(data.message=="created"){
								$("#txtDatePicker1").val(customDate);
								$("#datePicker1").datepicker("setDate", customDate);
								$("#txtDatePicker2").val(customDate);
								$("#datePicker2").datepicker("setDate", customDate);
								$("#txtVehiclePrice").val(0);
								getAllCarList();
								bootbox.alert("Successfully change car price.");
							}else if(data.message=="session expire"){
								bootbox.alert("Session Expire! Please refresh the browser and login again.");
							}else{
								bootbox.alert("Error on server side.");
							}
						});
        			}
	        	}
	        });
		}
	} 

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
		$(obj).val(parseInt(amount).toLocaleString());
    }
</script>