<?php include '../header.php'; ?>
<?php
    $oc_no = "";
    if(isset($_GET['ivn'])){
        if(!empty($_GET['ivn'])){
            $oc_no = $_GET['ivn'];
        }
    }
?>
<style>
	.form-group {
		margin-bottom: 6px !important;
	}
	.form-control:disabled {
		background-color: #f8f8f9;
	}
	.col-form-label {
		padding-top: 3px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Invoice Detail</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<button type="button" class="btn btn-primary" style="height: 33px; line-height: 0px; font-weight: bold; font-size: 16px; min-width: 65px; background-color: #fff; color: #000; border-color: #007bff;" id="btnGoBack" onclick="goToInvoices();"><i class="fas fa-arrow-left" style="margin-right: 6px;"></i> Go Back</button>
							<button type="button" class="btn btn-success" style="float: right; font-weight: bold;" onclick="goToDCPayment();" id="btnDCPayment">Add Payment</button>
						</div> 
						<div class="card-body">
							<div class="row">
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Invoice No.:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtInvoiceNo" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtSalesCenter" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Sales Date:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtSalesDate" disabled>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Payment Type:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtPaymentType" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Due Date/Time:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtDueDateTime" disabled>
										</div>
									</div> 
								</div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Customer Name:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtCustomerName" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Customer Phone:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtCustomerPhone" disabled>
										</div>
									</div>
								</div>
							</div>	
							<div class="card-body p-0" style="max-height: 270px; overflow-y: auto; background-color: #e6e7e847 !important; margin-top: 20px;">
								<table class="table table-bordered" id="myTable">
									<thead>                  
										<tr>
											<th style="width: 5%;">No.</th>
											<th style="width: 10%;">Date</th>
											<th>Paid By</th>
											<th>Received By</th>
											<th>Description</th>
											<th style="text-align: right; width: 15%;">Payment</th>
										</tr>
									</thead>
									<tbody></tbody>
								</table>
							</div>
							<div class="row">
								<div class="col-md-8"></div>
								<div class="col-md-4" style="margin-top: 10px;">
									<div class="form-group row">
										<label class="col-md-6 col-form-label" style="text-align: right; font-size: 16px;">Total Payment:</label>
										<div class="col-md-6">  
											<input type="text" class="form-control" id="txtTotalPayment" style="text-align: right; padding-right: 24px; font-weight: bold; font-size: 16px;" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-6 col-form-label" style="text-align: right; font-size: 16px;">Total Amount:</label>
										<div class="col-md-6">  
											<input type="text" class="form-control" id="txtTotalAmount" value="0" style="text-align: right; padding-right: 24px; font-weight: bold; font-size: 16px;" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-6 col-form-label" style="text-align: right; font-size: 16px;">Balance:</label>
										<div class="col-md-6">  
											<input type="text" class="form-control" id="txtBalance" value="0" style="text-align: right; padding-right: 24px; font-weight: bold; font-size: 16px;" disabled>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
    var oc_no = "<?= $oc_no ?>";
    var PROCESSING = "";

	$(function(){
		$("body").addClass("sidebar-collapse");	
		getSalesInvoiceDetail();
	});	

	function getSalesInvoiceDetail(){
		$.ajax({
			url: APP_URL + "api/finance/invoices/get_sales_invoice_detail.php",
			type: "POST",
			data: JSON.stringify({ oc_no: oc_no })
		}).done(function(data) {
			PROCESSING = data.processing;
			if(data.processing=="Deposit Collect"){
				$("#btnDCPayment").text("Add Deposit");
			}else{
				$("#btnDCPayment").text("Add Payment");
			}
			if(parseInt(data.total_amount.replace(/,/g, ''))==parseInt(data.total_payment.replace(/,/g, ''))){
				$("#btnDCPayment").css("display", "none");
			}
			$("#txtInvoiceNo").val(data.oc_no);
			$("#txtSalesCenter").val(data.sales_center);
			$("#txtSalesDate").val(data.sales_date);
			$("#txtPaymentType").val(data.payment_type);
			$("#txtDueDateTime").val(data.due_date_time); 
			$("#txtCustomerName").val(data.customer_name);
			$("#txtCustomerPhone").val(data.customer_phone);

			$.each(data.payment_detail, function(i, v) {
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.date + "</td>")
					.append("<td>" + v.paid_by + "</td>")
					.append("<td>" + v.receive_by + "</td>")
					.append("<td>" + v.description + "</td>")
					.append("<td style='text-align:right; padding-right: 24px !important;'>" + v.amount + "</td>")
				);
			});

			$("#txtTotalPayment").val(data.total_payment); 
			$("#txtTotalAmount").val(data.total_amount);
			var balance = parseInt(data.total_amount.replace(/,/g, '')) - parseInt(data.total_payment.replace(/,/g, ''));
			$("#txtBalance").val(balance.toLocaleString());
		});
	}

	function goToInvoices(){
		document.location = APP_URL + "finance/invoices.php";
	}

	function goToDCPayment(){
		if(PROCESSING=="Deposit Collect"){
			window.open(APP_URL + "sales/deposit_collect.php?act=edit&oc_no=" + oc_no);
		}else{
			window.open(APP_URL + "sales/payment.php?act=edit&oc_no=" + oc_no);
		}
	}
</script>
