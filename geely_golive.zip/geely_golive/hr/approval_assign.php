<?php include '../header.php'; ?> 
<style>
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Approval - Assign</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Position (From): </label>
											<div class="col-md-8">
												<select class="form-control" id="cboPositionFrom"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Staff (From): </label>
											<div class="col-md-8">
												<select class="form-control" id="cboStaffFrom"></select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Position (To): </label>
											<div class="col-md-8">
												<select class="form-control" id="cboPositionTo"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Staff (To): </label>
											<div class="col-md-8">
												<select class="form-control" id="cboStaffTo"></select>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Process: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboProcess">
													<option value="Confirm Order">Confirm Order</option> 
												</select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;"></label>
											<div class="col-md-4">
												<select class="form-control" id="cboOrderNo" style="color: grey;">
													<option value="" style="color: grey;">Order No.</option>
													<option value="1" style="color: #000;">1</option>
													<option value="2" style="color: #000;">2</option>
													<option value="3" style="color: #000;">3</option>
													<option value="4" style="color: #000;">4</option>
													<option value="5" style="color: #000;">5</option>
													<option value="6" style="color: #000;">6</option>
													<option value="7" style="color: #000;">7</option>
												</select>
											</div>
											<div class="col-md-4">
												<select class="form-control" id="cboCondition" style="color: grey;">
													<option value="" style="color: grey;">Condition</option>
													<option value="AND" style="color: #000;">AND</option>
													<option value="OR" style="color: #000;">OR</option>
												</select>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-8 EditAccessPanelNo" style="display:none;"></div>
											<label class="col-md-4 col-form-label EditAccessPanelYes" style="text-align: right; padding-top: 0px;">Edit Access:</label>
											<div class="col-md-4 EditAccessPanelYes">
												<div class="icheck-success d-inline">
													<input type="checkbox" id="chkEditAccess">
													<label for="chkEditAccess"></label>
												</div>
											</div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="add();">Add</button>
											</div>
										</div>
									</div>
								</div>

								<div class="card-body p-0" style="height:300px; overflow-y: auto; background-color: #e6e7e8b0 !important;">
									<table class="table table-bordered" id="myTable">
										<thead>                  
											<tr>
												<th>No.</th>
												<th>Staff (From)</th>
												<th>Staff (To)</th>
												<th>Process</th>
												<th>Order No.</th>
												<th>Condition</th>
												<th>Edit Access</th>
												<th style="width: 5%">Delete</th>
											</tr>
										</thead>
										<tbody></tbody>
									</table>
								</div>

								<div class="row" style="margin-top: 15px;">
									<div class="col-md-9"></div>
									<div class="col-md-3">
										<div class="form-group row">
											<div class="col-md-12" style="text-align: right;">
												<button type="button" class="btn btn-success" onclick="validateAndSave();" style="min-width: 150px;">Save</button>
											</div>
										</div>
									</div>
								</div>

							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	$(function() {
		$("body").addClass("sidebar-collapse"); 
		getAllPositionFrom();
	});

	$("#cboProcess").change(function(){
		if($(this).val()=="Confirm Order"){
			$(".EditAccessPanelYes").css("display", "");
			$(".EditAccessPanelNo").css("display", "none");
		}else{
			$(".EditAccessPanelNo").css("display", "");
			$(".EditAccessPanelYes").css("display", "none");
			$("#chkEditAccess").attr("checked", false);
		}
	});

	$("#cboOrderNo").change(function(){
		if($(this).val()==""){
			$(this).css("color", "grey");
		}else{
			$(this).css("color", "");
		}
	});

	$("#cboCondition").change(function(){
		if($(this).val()==""){
			$(this).css("color", "grey");
		}else{
			$(this).css("color", "");
		}
	});

	$("#cboPositionFrom").change(function(){
		getAllPositionTo();
		getAllStaffFrom();
	});

	$("#cboPositionTo").change(function(){
		getAllStaffTo();
	});

	$("#cboStaffFrom").change(function(){
		getApprovalAssignByStaff();
	});

	function getAllPositionFrom(){
		$("#cboPositionFrom").find("option").remove();
		$("#cboPositionFrom").append("<option value=''></option>");
		$.ajax({
			url: APP_URL + "api/hr/position/get_all_position.php",
			type: "POST",
			data: JSON.stringify({ position: '' })
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				$("#cboPositionFrom").append("<option value='" + v.position + "'>" + v.position + "</option>");
			});
			getAllPositionTo();
			getAllStaffFrom();
		});
	}

	function getAllPositionTo(){
		var position_from = $("#cboPositionFrom").val();
		$("#cboPositionTo").find("option").remove();

		if(position_from){
			$.ajax({
				url: APP_URL + "api/hr/position/get_all_position.php",
				type: "POST",
				data: JSON.stringify({ position: position_from })
			}).done(function(data) {
				if(data.records.length > 0) $("#cboPositionTo").append("<option value=''></option>");
				$.each(data.records, function(i, v) {
					$("#cboPositionTo").append("<option value='" + v.position + "'>" + v.position + "</option>");
				});
			});
		}
	}

	function getAllStaffFrom(){
		var position_from = $("#cboPositionFrom").val();
		$("#cboStaffFrom").find("option").remove();

		if(position_from){
			$.ajax({
				url: APP_URL + "api/hr/staff/get_staff_by_position.php",
				type: "POST",
				data: JSON.stringify({ position: position_from })
			}).done(function(data) {
				if(data.records.length > 0) $("#cboStaffFrom").append("<option value='' data-id=''></option>");
				$.each(data.records, function(i, v) {
					$("#cboStaffFrom").append("<option value='" + v.name + "' data-id='" + v.id + "'>" + v.name + "</option>");
				});
				getAllStaffTo();
			});
		}
	}

	function getAllStaffTo(){
		var position_to = $("#cboPositionTo").val();
		$("#cboStaffTo").find("option").remove();

		if(position_to){
			$.ajax({
				url: APP_URL + "api/hr/staff/get_staff_by_position.php",
				type: "POST",
				data: JSON.stringify({ position: position_to })
			}).done(function(data) {
				if(data.records.length > 0) $("#cboStaffTo").append("<option value='' data-id=''></option>");
				$.each(data.records, function(i, v) {
					$("#cboStaffTo").append("<option value='" + v.name + "' data-id='" + v.id + "'>" + v.name + "</option>");
				});
			});
		}
	}

	function add(){
		var staff_id = $("#cboStaffFrom option:selected").attr("data-id");
		var staff_name = $("#cboStaffFrom").val();
		var approval_staff_id = $("#cboStaffTo option:selected").attr("data-id");
		var approval_staff_name = $("#cboStaffTo").val();
		var process_name = $("#cboProcess").val();
		var order_no = $("#cboOrderNo").val();
		var condition = $("#cboCondition").val();
		var permission_edit = ($("#chkEditAccess").prop("checked"))?1:0;

		if(!staff_id){
			bootbox.alert("Please choose staff (from).");
		}else if(!approval_staff_id){
			bootbox.alert("Please choose staff (to).");
		}else if(!order_no){
			bootbox.alert("Please choose order no.");
		}else if(!condition){
			bootbox.alert("Please choose condition.");
		}else{
			var msg = checkApprovalAssign(staff_id, approval_staff_id, process_name, order_no, condition);
			if(msg==""){
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + ($("#myTable tbody tr").length + 1) + "</td>")
					.append("<td data-id='" + staff_id + "'>" + staff_name + "</td>")
					.append("<td data-id='" + approval_staff_id + "'>" + approval_staff_name + "</td>")
					.append("<td>" + process_name + "</td>")
					.append("<td>" + order_no + "</td>")
					.append("<td>" + condition + "</td>")
					.append("<td data-edit='" + permission_edit + "'>" + ((permission_edit==1)?'Yes':'No') + "</td>")
					.append("<td style='width: 70px;'><button type='button' class='btn btn-danger btn-sm' style='padding: 2px 16px;font-size: 14px;' onclick='$(this).parent().parent().remove(); rearrangeSorting();'><i class='far fa-trash-alt'></i></button></td>")
				);
			}else{
				bootbox.alert(msg);
			}
		}
	}

	function checkApprovalAssign(sid, apv_sid, process_name, order_no, condition){
		var msg = "";
		$("#myTable tbody tr").each(function(){
			if($(this).find("td").eq(1).attr("data-id")==sid && $(this).find("td").eq(2).attr("data-id")==apv_sid && $(this).find("td").eq(3).text()==process_name && $(this).find("td").eq(4).text()==order_no){
				msg = "Not allow staff duplicate assign under the same order no.";
				return false;
			}else if($(this).find("td").eq(3).text()==process_name && $(this).find("td").eq(4).text()==order_no && $(this).find("td").eq(5).text()!=condition){
				msg = "Condition must be the same under the same order no.";
				return false;
			}
		});
		return msg;
	}

	function getApprovalAssignByStaff(){
		var staff_id = $("#cboStaffFrom option:selected").attr("data-id");
		$("#myTable").find("tbody").find("tr").remove();

		if(staff_id){
			$.ajax({
				url: APP_URL + "api/hr/approval_assign/get_approval_assign_by_staff.php",
				type: "POST",
				data: JSON.stringify({ staff_id: staff_id })
			}).done(function(data) {
				$.each(data.records, function(i, v) {
	            	$("#myTable").find("tbody")
					.append($('<tr>')
						.append("<td>" + (i + 1) + "</td>")
						.append("<td data-id='" + v.staff_id + "'>" + v.staff_name + "</td>")
						.append("<td data-id='" + v.approval_staff_id + "'>" + v.approval_staff_name + "</td>")
						.append("<td>" + v.process + "</td>")
						.append("<td>" + v.order_no + "</td>")
						.append("<td>" + v.condition + "</td>")
						.append("<td data-edit='" + v.permission_edit + "'>" + ((v.permission_edit==1)?'Yes':'No') + "</td>")
						.append("<td style='width: 70px;'><button type='button' class='btn btn-danger btn-sm' style='padding: 2px 16px;font-size: 14px;' onclick='$(this).parent().parent().remove(); rearrangeSorting();'><i class='far fa-trash-alt'></i></button></td>")
					);
	            });
			});
		}
	}

	function validateAndSave(){
		var approval_assign_detail = [];
		$("#myTable tbody tr").each(function(){
			var detail = {
				"process": $(this).find("td").eq(3).text(),
				"staff_id": $(this).find("td").eq(1).attr("data-id"),
				"approval_staff_id": $(this).find("td").eq(2).attr("data-id"),
				"permission_edit": $(this).find("td").eq(6).attr("data-edit"),
				"order_no": $(this).find("td").eq(4).text(),
				"condition": $(this).find("td").eq(5).text()
			}
			approval_assign_detail.push(detail);
		});

		if(approval_assign_detail.length==0){
			bootbox.alert("Please fill the data.");
		}else{
			$("#loading").css("display", "block");
			$.ajax({
				url: APP_URL + "api/hr/approval_assign/create.php",
				type: "POST",
				data: JSON.stringify({ approval_assign_detail: approval_assign_detail })
			}).done(function(data) {
				$("#loading").css("display", "none");
				if(data.message=="created"){ 
					bootbox.alert("Successfully saved.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function rearrangeSorting(){
    	$("#myTable tbody tr").each(function(){
    		$(this).find("td").eq(0).text($(this).index() + 1);
    	});
    } 
</script>	
