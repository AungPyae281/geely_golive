<?php include '../header.php'; ?> 
<style>
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Position - Entry</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-5">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Department: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboDepartment"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Position: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPosition">
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-8"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="create()">Add</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-7">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"> </span></h3>
						</div>
						<div class="card-body p-0" style="max-height: 450px; overflow: auto;">
							<table class="table table-striped table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th>
										<th>Department</th>
										<th>Position</th>
										<th style="width: 3%">Delete</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	$(function() {
		getAllDepartment();
		getAllRows(); 
	});

	$("#cboDepartment").change(function(){
		getAllRows();
	});

	function getAllDepartment(){
		$("#cboDepartment").find("option").remove();
		$("#cboDepartment").append("<option value = '' data-id = ''></option>");
		$.ajax({
			url: APP_URL + "api/hr/department/get_all_rows.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				$("#cboDepartment").append("<option value= '" + v.department + "' data-id = '"+ v.id + "'>" + v.department + "</option>");
			});
		});
	}

	function create(){	
		$("#loading").css("display","block");
		var department = $("#cboDepartment").val();
		var position = $("#txtPosition").val();

		if(department==""){
			bootbox.alert("Please choose department.");
			$("#loading").css("display","none"); 
		}else if(position==""){
			bootbox.alert("Please fill position.");
			$("#loading").css("display","none"); 
		}else{
			$.ajax({
				url: APP_URL + "api/hr/position/create.php",
				type: "POST",
				data: JSON.stringify({ department: department, position: position }),
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="created"){
					$("#frmEntry")[0].reset();
					bootbox.alert("Successfully Added.");
					getAllRows();
				}else if(data.message=="duplicate"){
					bootbox.alert("Not allow duplicate position.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function getAllRows(){ 
        var department = $("#cboDepartment").val();
        $("#myTable").find("tbody").find("tr").remove();
        $.ajax({
            type: "POST",
            url: APP_URL + "api/hr/position/get_all_rows_by_department.php",
            data: JSON.stringify({ department: department })
        }).done(function(data) {
            $("#loading").css("display","none"); 
            if(data.records.length>1){
            	$("#total_records").text(" - " + data.records.length + " records found.");
            }else{
            	$("#total_records").text(" - " + data.records.length + " record found.");
            }
            $.each(data.records, function(i, v) {
                $("#myTable").find("tbody")
                .append($('<tr>')
                    .append("<td>" + (i + 1) + "</td>")
                    .append("<td>" + v.department + "</td>")
                    .append("<td>" + v.position + "</td>")
                    .append("<td style='text-align: center;'>" + ((v.is_delete)?"<span class='btn btn-danger btn-sm fas fas fa-trash-alt' style='cursor: pointer;padding: 5px 9px 5px 10px;font-size: 15px;' onclick='del(\"" + v.id + "\", this)' title='Delete'></span>":"") + "</td>")
                )
            });
        });
    } 

	function del(id, obj){ 
	    bootbox.confirm({
	    	message: "<h4>Are you sure that you want to delete?</h4>",
	    	buttons: {
	    		confirm: {
	    			label: '<span class="glyphicon glyphicon-ok"></span> Yes',
	    			className: 'btn-primary'
	    		},
	    		cancel: {
	    			label: '<span class="glyphicon glyphicon-remove"></span> No',
	    			className: 'btn-danger'
	    		}
	    	},
	    	callback: function (result) {
	    		if(result){
	    			$.ajax({
	    				type: "POST",
	    				url: APP_URL + "api/hr/position/delete.php",
	    				data: JSON.stringify({ id: id }),
	    				success: function(data){
	    					if(data.message=="deleted"){
	    						$(obj).parent().parent().remove();
	    						if($("#myTable tbody tr").length>1){
					            	$("#total_records").text(" - " + $("#myTable tbody tr").length + " records found.");
					            }else{
					            	$("#total_records").text(" - " + $("#myTable tbody tr").length + " record found.");
					            }
	    						rearrangeSorting();
	    					}else{
	    						bootbox.alert("Error on server side.");
	    					}
	    				}
	    			});
	    		}
	    	}
	    });
    }

    function rearrangeSorting(){
    	$("#myTable tbody tr").each(function(){
    		$(this).find("td").eq(0).text($(this).index() + 1);
    	});
    }
</script>	
