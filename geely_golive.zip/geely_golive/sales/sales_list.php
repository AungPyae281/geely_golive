<?php include '../header.php'; ?>   
<style> 
	#myTable td:nth-child(3) {
		text-decoration: underline;
		color: blue;
		cursor: pointer;
    }
    .align{
    	text-align: right;
    }
    .displayNone{
    	display: none;
    }
</style>
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                	<div class="card card-outline card-primary">
                		<div class="card-header">
							<h3 class="card-title">Sales Processing List</h3>
						</div>
						<div class="card-body">
							<table id="myTable" class="display nowrap">
								<thead>
									<tr>
										<th>Status</th>
										<th>Date</th>
										<th>O.C No.</th>
										<th>Customer Name</th> 
										<th>Vin No.</th> 
                                        <th>Price</th> 
                                        <th>Payment Type</th> 
										<th>Paid(%)</th> 
                                        <th>Due Date/Time</th> 
										<th>Appt. Date/Time</th>
										<th>Action</th>
										<th style="display:none;">Processing</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
                	</div>
                </div>	
 
            </div>
        </div>
    </section>
</div>
<?php include '../footer.php'; ?> 
<script>	 
	$(function() {
		$("body").addClass("sidebar-collapse"); 
		fillGrid();
	});	 

	function fillGrid(){
		table = $('#myTable').DataTable({
			"scrollX": true,
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"order": [[ 2, "desc" ]],
			'columnDefs': [	 
				{
					'targets': 10,
					'searchable': false,
					'orderable': false,	
					'render': function (data){	
						var oc_no = data.split("|")[0];
						var btnPayment = "";
						var btnPDI = "";

						if(parseInt(data.split("|")[1])){
							btnPayment = '<button type="button" class="btn btn-success btn-sm" onclick="goToPayment(\'' + oc_no + '\');" style="font-size: 18px;" title="Payment"><i class="fas fa-solid fa-file-invoice-dollar nav-icon"></i></button> ';
						}

						if(parseInt(data.split("|")[2])){
							btnPDI = '<button type="button" class="btn btn-primary btn-sm" onclick="goToPDI(\'' + oc_no + '\');" style="font-size: 18px;" title="PDI Check List"><i class="fas fa-solid fa-list nav-icon"></i></button>';
						}
						return '<td>' + btnPayment + btnPDI + '</td>';	
					}
				},
                { 
                    'targets': [5], 
                    'className': "align" 
                } ,
                { 
                    'targets': [11], 
                    'className': "displayNone" 
                }
			],
			"ajax": APP_URL + "api/sales/sales/get_sales_list.php"
		});		
	}	

	$('#myTable').on('click', 'tbody td:nth-child(3)', function(e){
		var status = $(this).parent().find("td").eq(11).text();
		if(status=="Deposit Collect"){
			document.location = APP_URL + "sales/deposit_collect.php?act=edit&oc_no=" + $(this).text();
		}else if(status=="Payment"){
			document.location = APP_URL + "sales/payment.php?act=edit&oc_no=" + $(this).text();
		}else if(status=="Purchase Permit" || status=="RTA Appointment" || status=="Plate Number"){
			document.location = APP_URL + "sales/supply_chain.php?act=edit&oc_no=" + $(this).text();
		}else if(status=="Income Tax"){
			document.location = APP_URL + "sales/owner.php?act=edit&oc_no=" + $(this).text();
		}else if(status=="Fill the Fuel"){
			document.location = APP_URL + "sales/fill_fuel.php?act=edit&oc_no=" + $(this).text();
		}else if(status=="PDI Check List"){
			document.location = APP_URL + "sales/pdi_check_list.php?act=edit&oc_no=" + $(this).text();
		}else if(status=="Ready to Deliver"){
			document.location = APP_URL + "sales/ready_to_deliver.php?act=edit&oc_no=" + $(this).text();
		}else if(status=="Handover" || status=="Owner Book Handover"){
			document.location = APP_URL + "sales/sales.php?act=edit&oc_no=" + $(this).text();
		}
	});  

	function goToPayment(oc_no){
		document.location = APP_URL + "sales/payment.php?act=edit&oc_no=" + oc_no;
	}

	function goToPDI(oc_no){
		document.location = APP_URL + "sales/pdi_check_list.php?act=edit&oc_no=" + oc_no;
	}
</script>