<?php include '../header.php'; ?>
<?php
    $oc_no = "";
    if(isset($_GET['oc_no'])){
        if(!empty($_GET['oc_no'])){
            $oc_no = $_GET['oc_no'];
        }
    }
?>
<style>
    .card{
        margin-bottom: 10px !important;
    }
    .card-header{
        padding: 8px 2px 8px 15px;
    }
    .card-body{
        padding: 15px 20px 5px 20px;
    }
    .nav-tabs{
        display: inline-flex;
    }
    .form-group{
        margin-bottom: 5px !important;
    }
    .form-control{
        border: 1px solid #d4d6d8ba !important;
    }
    .form-control:disabled, .form-control[readonly]{
        background-color: #e6e8ea9e !important;
    }
    input, textarea{
        font-size: 14px !important;
    }
    select{
        padding-top: 1px !important;
    }

    .breadcrumb{
        background: #fff;
    }
    .breadcrumb.wizard {
        margin: 0px !important;
        padding: 0px; 
        list-style: none;
        overflow: hidden;
        margin-top: 20px;
        font-size: 14px;
        height: 50px;
    }
    .breadcrumb.wizard>li+li:before {
        padding: 0;
    }
    .breadcrumb.wizard li {
        float: left;
        background: #eee;
        height: 50px;
    } 
    .breadcrumb.wizard li.current a {
        color: #fff !important; 
        background: brown;
        background: hsl(203.9, 64.2%, 48.2%) !important;
    }
    .breadcrumb.wizard li.completed a {
        color: #fff; 
        background: brown;
        background: hsl(204, 65.6%, 76.1%);
    } 
    .breadcrumb.wizard li.current a:after {
        border-left: 30px solid hsl(203.9, 64.2%, 48.2%) !important;
    }
    .breadcrumb.wizard li.completed a:after {
        border-left: 30px solid hsl(204, 65.6%, 76.1%);
    }

    .breadcrumb.wizard li a {
        height: 50px;
        line-height: 28px;
        color: #000;
        text-decoration: none;
        padding: 10px 0 10px 45px;
        position: relative;
        display: block;
        float: left;
    }
    .breadcrumb.wizard li a:after {
        content: " ";
        display: block;
        width: 0;
        height: 0;
        border-top: 50px solid transparent;
        border-bottom: 50px solid transparent;
        border-left: 30px solid #eee;
        position: absolute;
        top: 50%;
        margin-top: -50px;
        left: 100%;
        z-index: 2;
    }
    .breadcrumb.wizard li a:before {
        content: " ";
        display: block;
        width: 0;
        height: 0;
        border-top: 50px solid transparent;
        border-bottom: 50px solid transparent;
        border-left: 30px solid white;
        position: absolute;
        top: 50%;
        margin-top: -50px;
        margin-left: 1px;
        left: 100%;
        z-index: 1;
    }
    .breadcrumb.wizard li:first-child a {
        padding-left: 15px;
    } 
    .custom-disabled{
        color: #9091916b !important;
        cursor: no-drop !important;
    }
    .branch{
        padding-top: 35px;
    }
    .box-shadow{
        box-shadow: rgba(0, 0, 0, 0.25) 0px 0.0625em 0.0625em, rgba(0, 0, 0, 0.25) 0px 0.125em 0.5em, rgba(255, 255, 255, 0.1) 0px 0px 0px 1px inset;
    }
    #progress{
        padding-right: 47px;
    }
    .dcl-filename{
        height: 35px;
        overflow: auto;
        font-size: 13px;
    }
    .input-group-addon{
        height: 36px !important;
    } 
    .checkbox-inline .toggle{
        margin-left: 0px !important;
        width: 110px !important;
    }
    .pn-toggle .toggle{
        width: 160px !important;
    }
    .toggle-on, .toggle-off{
        line-height: 19px !important;
    }
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
    <section class="content-header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                </div>
            </div>
        </div>
    </section>
    <section class="content"> 
    	<div class="container-fluid">
    		<div class="row">
                <div class="col-md-12" id="SummaryPanel">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title" id="txtProcessing"></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">OC No.:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtOCNo" disabled value="<?=$oc_no?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtSalesCenter" disabled>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card card-outline card-outline-tabs collapsed-card">
                        <div class="card-header p-0 border-bottom-0">
                            <ul class="nav nav-tabs" id="custom-tabs-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="custom-tabs-customer-tab" data-toggle="pill" href="#custom-tabs-customer" role="tab" aria-controls="custom-tabs-customer" aria-selected="true">Customer Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-vehicle-tab" data-toggle="pill" href="#custom-tabs-vehicle" role="tab" aria-controls="custom-tabs-vehicle" aria-selected="false">Vehicle Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-payment-tab" data-toggle="pill" href="#custom-tabs-payment" role="tab" aria-controls="custom-tabs-payment" aria-selected="false">Payment Info</a>
                                </li>
                            </ul>
                            <div class="card-tools" style="padding-top: 10px;">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-tabContent">
                                <div class="tab-pane fade active show" id="custom-tabs-customer" role="tabpanel" aria-labelledby="custom-tabs-customer-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerName" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerNRCNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerMobileNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerTownship" disabled>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-vehicle" role="tabpanel" aria-labelledby="custom-tabs-vehicle-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Vin No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtVinNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Engine No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtEngineNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Particular:</label>
                                                <div class="col-md-8">
                                                    <textarea class="form-control" id="txtParticular" rows="4" style="height: 100px;" disabled></textarea>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-payment" role="tabpanel" aria-labelledby="custom-tabs-payment-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPayment" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment (%):</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPaymentPercent" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Deposit Amount:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtDeposit" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Remaining Balance:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtRemainingBalance" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card card-outline">
                        <div class="card-header" style="padding: 0px;"> 
                            <ul class="breadcrumb wizard myStepper">
                                <li class="completed" id="DocumentCollect"><a href="javascript:void(0);">Document Collect</a></li>
                                <li id="PurchasePermit"><a href="javascript:void(0);">Purchase Permit</a></li>
                                <li id="RTAAppointment"><a href="javascript:void(0);">RTA Appointment</a></li>
                                <li id="PlateNumber"><a href="javascript:void(0);">Plate Number</a></li>
                            </ul>
                        </div>

                        <div class="card-body branch" data-id="DocumentCollect">
                            <div class="col-md-12" id="myDCLFile">
                                <form role="form" id="frmDCLEntry">
                                    <div class="card-body" style="background-color: #fff;">
                                        <p style="font-size:16px; text-align:center; margin:10px 0px;">
                                        Please upload documents only in 'pdf' format.
                                        </p>
                                        <h3 style="text-align: center; font-size:23px;">
                                        Document Collect
                                        </h3><br>
                                        <div class="row">
                                            <div class="col-md-10" id="mainDCLPanel"></div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="card-body branch" data-id="PurchasePermit" style="display:none;">
                            <div class="row ppMainInfo" style="margin-bottom: 50px;">
                                <div class="col-md-6" style="display:inline-block;">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Submission Date:</label>
                                        <div class="col-md-8">  
                                            <div class="input-group input-append date" id="datePickerPPSubmission" data-date="2022-09-01" data-date-format="yyyy-mm-dd">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell; height: 31px !important;">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input type="text" class="form-control float-right pp-info" id="txtDatePickerPPSubmission" value="1982-06-15" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6" style="width: 48%; display:inline-block; vertical-align: top;">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Received Date:</label>
                                        <div class="col-md-8">  
                                            <div class="input-group input-append date" id="datePickerPPReceived" data-date="2022-09-01" data-date-format="yyyy-mm-dd">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell; height: 31px !important;">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input type="text" class="form-control float-right pp-info" id="txtDatePickerPPReceived" value="1982-06-15" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                <div class="col-md-6" style="display:inline-block;">
                                    <div class="form-group row">
                                        <div class="col-md-4"></div>
                                        <div class="col-md-8">
                                            <button type="button" class="btn btn-info file-upload" id="btnPPFileUpload" onclick="goToDocumentCollect();">Purchase Permit File</button>
                                        </div>
                                    </div>
                                </div> 
                            </div>

                            <h5 class="ppOwnershipInfo"><span style="font-weight: bold;margin-left:10px;">Ownership Info</span></h5>
                            <legend class="ppOwnershipInfo"> </legend>
                            <div class="row ppOwnershipInfo" style="margin-bottom: 50px;">
                                <div class="col-md-6" style="display:inline-block;">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPRTADName">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
                                        <div class="col-md-8">
                                            <select class="form-control pp-info" id="cboPPRTADCode" style="padding-left: 5px; width: 17%; display: inline-block !important;">
                                                <option value=""></option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                                <option value="11">11</option>
                                                <option value="12">12</option>
                                                <option value="13">13</option>
                                                <option value="14">14</option>
                                            </select>
                                            <select class="form-control pp-info" id="cboPPRTADTownshipCode" style="display: inline-block !important;width: 31%;">
                                            </select>
                                            <select class="form-control pp-info" id="cboPPRTADNRCType" style="display: inline-block !important;width: 17%;padding-left: 5px;">
                                                <option value=""></option>
                                                <option value="(N)">(N)</option>
                                                <option value="(P)">(P)</option>
                                                <option value="(A)">(A)</option>
                                            </select>
                                            <input type="text" class="form-control pp-info" id="txtPPRTADNRCNo" onkeypress="return isNumber(event)" maxlength="6" style="text-align: right; padding-left: 0px; width: 31%; display: inline-block !important;">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPRTADMobileNo">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">E-Mail:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPRTADEmail">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Address:</label>
                                        <div class="col-md-8">
                                            <textarea class="form-control pp-info" id="txtPPRTADAddress" rows="2"></textarea>
                                        </div>
                                    </div>
                                </div> 
                                <div class="col-md-6" style="width: 48%; display:inline-block; vertical-align: top;">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPSalesCenter">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Bank:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPBank">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">A/C No.:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPBankAcc">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Foreign Currency Balance:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPForeignCurrencyBalance">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label notEssential" style="text-align: right;">Balance Date :</label>
                                        <div class="col-md-8">
                                            <div class="input-group input-append date" id="datePickerPP" data-date="2022-09-21" data-date-format="yyyy-mm-dd">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;  height: 31px !important;">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input type="text" class="form-control float-right pp-info" id="txtDatePickerPP" value="1982-06-15" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h5 class="ppVehicleInfo"><span style="font-weight: bold;margin-left:10px;">Vehicle Info</span></h5>
                            <legend class="ppVehicleInfo"> </legend>
                            <div class="row ppVehicleInfo" style="margin-bottom: 50px;">
                                <div class="col-md-6" style="display:inline-block;">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Vehicle Type:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPVehicleType">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Brand:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPBrand">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Model Year:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPModelYear">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Engine Power:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPEnginePower">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6" style="width: 48%; display:inline-block; vertical-align: top;">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Value:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPValue" style="text-align:right;">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Country Of Origin:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPCountryOfOrigin">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Commission %:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPCommission">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">According To:</label>
                                        <div class="col-md-8">
                                            <textarea class="form-control pp-info" id="txtPPAccordingTo" rows="1"></textarea>
                                        </div>
                                    </div>
                                </div>  
                            </div>

                            <h5 class="ppOtherInfo"><span style="font-weight: bold;margin-left:10px;">Other Info</span></h5>
                            <legend class="ppOtherInfo"> </legend>
                            <div class="row ppOtherInfo">
                                <div class="col-md-6" style="display:inline-block;">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control pp-info" id="txtPPOtherName">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
                                        <div class="col-md-8">
                                            <select class="form-control pp-info" id="cboPPOtherCode" style="padding-left: 5px; width: 17%; display: inline-block !important;">
                                                <option value=""></option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                                <option value="11">11</option>
                                                <option value="12">12</option>
                                                <option value="13">13</option>
                                                <option value="14">14</option>
                                            </select>
                                            <select class="form-control pp-info" id="cboPPOtherTownshipCode" style="display: inline-block !important;width: 31%;">
                                            </select>
                                            <select class="form-control pp-info" id="cboPPOtherNRCType" style="display: inline-block !important;width: 17%;padding-left: 5px;">
                                                <option value=""></option>
                                                <option value="(N)">(N)</option>
                                                <option value="(P)">(P)</option>
                                                <option value="(A)">(A)</option>
                                            </select>
                                            <input type="text" class="form-control pp-info" id="txtPPOtherNRCNo" onkeypress="return isNumber(event)" maxlength="6" style="text-align: right; padding-left: 0px; width: 31%; display: inline-block !important;">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6" style="width: 48%; display:inline-block; vertical-align: top;">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Address:</label>
                                        <div class="col-md-8">
                                            <textarea class="form-control pp-info" id="txtPPOtherAddress" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row" id="ppDone">
                                        <label class="col-md-12 col-form-label" style="text-align: right; padding-top: 6px;">
                                            Done
                                            <div class="icheck-success d-inline" style="padding-left: 3px;">
                                                <input type="checkbox" id="chkPPDone" style="padding-top: 6px;">
                                                <label for="chkPPDone" style="margin-top: 6px;"></label>
                                            </div>
                                            <button type="button" class="btn btn-success" id="btnPPSubmit" onclick="submitPP();">Submit</button>
                                        </label>
                                    </div>
                                </div>
                            </div>   
                        </div>

                        <div class="card-body branch" data-id="RTAAppointment" style="display:none;">
                            <div class="row">
                                <div class="col-md-6"> 
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Schedule Date:</label>
                                        <div class="col-md-8">
                                            <div class="input-group input-append date" id="datePickerAppt" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;height: 31px !important;">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input type="text" class="form-control float-right appt-info" id="txtDatePickerAppt" value="1982-06-15" readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Schedule Time:</label>
                                        <div class="col-md-8">
                                            <div class="input-group bootstrap-timepicker">
                                                <div class="input-group-addon input-group-text" style="border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: 31px !important;">
                                                    <i class="far fa-clock"></i>
                                                </div>
                                                <input type="text" class="form-control timepicker appt-info" id="txtTimePickerAppt" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">RTA Office Location:</label>
                                        <div class="col-md-8">
                                            <textarea class="form-control appt-info" id="txtApptRTAOfficeLocation" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row" id="apptDone">
                                        <label class="col-md-12 col-form-label" style="text-align: right; padding-top: 6px;">
                                            Done
                                            <div class="icheck-success d-inline" style="padding-left: 3px;">
                                                <input type="checkbox" id="chkApptDone" style="padding-top: 6px;">
                                                <label for="chkApptDone" style="margin-top: 6px;"></label>
                                            </div>
                                            <button type="button" class="btn btn-success" id="btnApptSubmit" onclick="addAppointmentDateTime();">Submit</button>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card-body branch" data-id="PlateNumber" style="display:none;">
                            <form id="frmPNEntry">
                                <div class="row">
                                    <div class="col-md-7"> 
                                        <div class="form-group row">
                                            <label class="col-md-3 col-form-label" style="text-align: right;">Plate No.:</label>
                                            <div class="col-md-9" style="text-align:left;">
                                                <select class="form-control pn-info" id="cboPNRegionalCode" style="width: 25%; font-size: 13px; display: inline-block !important; height: 35px;">
                                                    <option value="YGN">YGN</option>
                                                    <option value="MDY">MDY</option>
                                                    <option value="SHN">SHN</option>
                                                    <option value="SGG">SGG</option>
                                                    <option value="AYY">AYY</option>
                                                    <option value="BGO">BGO</option>
                                                    <option value="NPW">NPW</option>
                                                    <option value="TNI">TNI</option>
                                                    <option value="MON">MON</option>
                                                    <option value="RKE">RKE</option>
                                                    <option value="KCN">KCN</option>
                                                    <option value="KYH">KYH</option>
                                                    <option value="KYN">KYN</option>
                                                    <option value="MGY">MGY</option>
                                                    <option value="CHN">CHN</option> 
                                                </select>
                                                <input type="text" class="form-control pn-info" id="txtPNTownshipCode" onkeypress="return isNumber(event)" maxlength="2" style="width: 22%; display: inline-block !important; height: 35px; padding-top: 1px;" placeholder="Township Code">
                                                <input type="text" class="form-control pn-info" id="txtPNPrefixNo" maxlength="2" style="width: 22%; display: inline-block !important; height: 35px; padding-top: 1px;" placeholder="Prefix No.">
                                                <input type="text" class="form-control pn-info" id="txtPNSuffixNo" onkeypress="return isNumber(event)" maxlength="4" style="width: 27%; display: inline-block !important; text-align: right; height: 35px; padding-top: 1px;" placeholder="Suffix No.">
                                            </div>
                                        </div>
                                        <div class="form-group row" style="margin-bottom: 2px !important;">
                                            <label class="col-md-3 col-form-label" style="text-align: right; padding-top: 6px;"></label>
                                            <div class="col-md-9">
                                                <div class="checkbox" style="text-align: left;">
                                                    <label class="checkbox-inline pToggle pn-toggle">
                                                        <input type="checkbox" data-toggle="toggle" id="chkSpecialPlate" data-on="Special Plate No." data-off="Special Plate No." data-onstyle="success" class="pnToggle pn-info">
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group row">
                                            <label class="col-md-3 col-form-label" style="text-align: right;"></label>
                                            <div class="col-md-9">
                                                <input style="display:none" name="file-pn" id="input-pn-image-hidden" onchange="document.getElementById('pn-previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
                                                <img id="pn-previewing" name="pn-previewing" src="<?=$app_url;?>img/no_image.jpg" style="height:170px; width:auto;cursor:pointer;border: 2px solid #a2a2a2;" onclick="HandleBrowseClick(this)" title="Click to Change the Photo.">
                                            </div>
                                        </div>
                                        <div class="form-group row" id="pnDone">
                                            <label class="col-md-12 col-form-label" style="text-align: right; padding-top: 6px;">
                                                Done
                                                <div class="icheck-success d-inline" style="padding-left: 3px;">
                                                    <input type="checkbox" id="chkPNDone" style="padding-top: 6px;">
                                                    <label for="chkPNDone" style="margin-top: 6px;"></label>
                                                </div>
                                                <button type="button" class="btn btn-success" id="btnPNSubmit">Submit</button>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
    	</div>
    </section> 
</div>
<?php include '../footer.php'; ?>
<script>
    var oc_no = "<?= $oc_no ?>";
    var statusArr = ["Purchase Permit", "RTA Appointment", "Plate Number"];
    var arrDCList = ["ID", "BL", "Custom Statement", "Purchase Permit", "License", "RTA Fees Slip"];

    var d = new Date();
    var mm = (d.getMonth("MM")+1);
    var dd = d.getDate();
    var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$(function(){
        $("body").addClass("sidebar-collapse");  
        checkStatus();

        // Purchase Permit
        $('#datePickerPPSubmission').attr("data-date", customDate);
        $("#txtDatePickerPPSubmission").val(customDate);
        $('#datePickerPPSubmission').datepicker();

        $('#datePickerPPReceived').attr("data-date", customDate);
        $("#txtDatePickerPPReceived").val(customDate);
        $('#datePickerPPReceived').datepicker();

        $('#datePickerPP').attr("data-date", customDate);
        $("#txtDatePickerPP").val(customDate);
        $('#datePickerPP').datepicker();

        $('#ppSignaturePad').signaturePad({
            drawOnly : true,
            lineTop : 200,
            lineColour : '#fff'
        });
        // Purchase Permit

        // RTA Appointment
        $('#datePickerAppt').attr("data-date", customDate);
        $("#txtDatePickerAppt").val(customDate);
        $('#datePickerAppt').datepicker();

        $('#txtTimePickerAppt').timepicker({
            minuteStep: 5,
            showInputs: false
        });
         $('#txtTimePickerAppt').timepicker('setTime', '06:00 AM');
        // RTA Appointment
    });

    $(document).on('click', ".myStepper .clickable", function(){
        $(".myStepper li").removeClass("current");
        $(this).addClass("current");
        $(".branch").css("display", "none");
        $("[data-id='" + $(this).attr("id") + "']").css("display", "");
        if($(this).find("a").text()=="Purchase Permit") checkPurchasePermit();
    });

    function HandleBrowseClick(obj){
        var inputID = $(obj).parent().find("input[type='file']").attr("id");
        var file = document.getElementById(inputID);
        file.click();
    }

    // Check Status
    function checkStatus(){
        $(".myStepper li").removeClass("current");
        $(".myStepper li:not(:first-child)").removeClass("completed");
        $(".myStepper li").removeClass("clickable");
        $(".myStepper li").addClass("clickable");
        $(".myStepper a").removeClass("custom-disabled");
        $(".branch").css("display", "none");

        $.ajax({
            url: APP_URL + "api/sales/sales/check_status.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {  
            var status = data.status.replace(/\s+/g, "");
            var processing = data.processing.replace(/\s+/g, "");
            
            if(processing=="PurchasePermit" || processing=="RTAAppointment" || processing=="PlateNumber"){
                // Processing
                $("#" + processing).removeClass("completed");
                $("#" + processing).addClass("current");
                $("[data-id='" + processing + "']").css("display", "");
                // Processing

                // Disabled 
                var completedStart = true;
                var disabledStart = false;
                $.each(statusArr, function(i, v){
                    var val = v.replace(/\s+/g, "");
                    if(val == status){
                        $("#" + val).addClass("completed");
                        completedStart = false;
                    }else if(completedStart){
                        $("#" + val).addClass("completed");
                    }

                    if(disabledStart){
                        $("#" + val).removeClass("clickable");
                        $("#" + val + " a").addClass("custom-disabled");
                    }
                    if(val == processing){
                        disabledStart = true;
                    }
                });
                // Disabled
            }else{
                $(".myStepper li:first-child").addClass("current");
                $("[data-id='DocumentCollect']").css("display", "");
            }
            getSalesDetail();
            appendDCList();
            getOnePurchasePermit();
        });
    }
    // Check Status

    function getSalesDetail(){
        $.ajax({
            url: APP_URL + "api/sales/sales/get_sales_detail.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {    
            $("#txtProcessing").text(data.processing);
            $("#txtSalesCenter").val(data.sales_center);

            $("#txtCustomerName").val(data.c_name);
            $("#txtCustomerNRCNo").val(data.c_nrc_no);
            $("#txtCustomerMobileNo").val(data.c_mobile_no);
            $("#txtCustomerTownship").val(data.c_township);

            $("#txtVinNo").val(data.vin_no);
            $("#txtEngineNo").val(data.engine_no);
            $("#txtParticular").val(data.particular);

            $("#txtTotalPayment").val(data.total_payment);
            $("#txtTotalPaymentPercent").val(data.payment_percent);
            $("#txtDeposit").val(data.deposit);
            $("#txtRemainingBalance").val(data.remaining_balance);

            // Purchase Permit
            if(data.pp_done==1){
                $(".ppOwnershipInfo").css("display", "none");
                $(".ppVehicleInfo").css("display", "none");
                $(".ppOtherInfo").css("display", "none");
            }else{
                $(".ppOwnershipInfo").css("display", "");
                $(".ppVehicleInfo").css("display", "");
                $(".ppOtherInfo").css("display", "");
            }
            // Purchase Permit

            // RTA Appointment
            if(data.appt_done==1){
                $("#apptDone").css("display", "none");
                $(".appt-info").attr("disabled", true);
            }else{
                $("#chkApptDone").prop("checked", false);
            }

            if(data.appointment_date){
                $("#txtDatePickerAppt").val(data.appointment_date);
                $("#txtTimePickerAppt").val(data.appointment_time);
            }

            $("#txtApptRTAOfficeLocation").val(data.rta_office_location);
            // RTA Appointment

            // Plate Number
            if(data.pn_done==1){
                $("#pnDone").css("display", "none");
                $(".pn-info").attr("disabled", true);
                $("#input-pn-image-hidden").attr("disabled", true);
            }else{
                $("#chkPNDone").prop("checked", false);
                $("#input-pn-image-hidden").attr("disabled", false);
            }

            if(data.plate_no){
                if(data.plate_no.split(" ").length>1){
                    $("#cboPNRegionalCode").val(data.plate_no.split(" ")[0]);
                    $("#txtPNTownshipCode").val(data.plate_no.split(" ")[1]);
                    $("#txtPNPrefixNo").val(data.plate_no.split(" ")[2].split("-")[0]);
                    $("#txtPNSuffixNo").val(data.plate_no.split(" ")[2].split("-")[1]);
                }else{
                    $("#cboPNRegionalCode").val(data.plate_no.split(" ")[0]);
                    $("#txtPNPrefixNo").val(data.plate_no.split(" ")[1].split("-")[0]);
                    $("#txtPNSuffixNo").val(data.plate_no.split(" ")[1].split("-")[1]);
                }

                if(data.special_plate==1){
                    $("#chkSpecialPlate").parent().removeClass("off");
                }else{
                    $("#chkSpecialPlate").parent().addClass("off");
                }

                if(data.plate_no_img){
                    $('#pn-previewing').attr("src", APP_URL + "api/sales/sales/upload/" + oc_no + "/" + data.plate_no_img);
                }else{
                    $('#pn-previewing').attr("src", APP_URL + "img/no_image.jpg");
                }
            }
            // Plate Number
        });
    } 

    // Document Collect
    function appendDCList(){
        $("#mainDCLPanel").empty();
        $.each(arrDCList, function(i, v){
            var label = v + ": ";
            var filenameID = v.replace(/\s+/g, "");
            if(v=="Purchase Permit"){
                $("#mainDCLPanel").append('<div class="form-group row dc-group"><label class="col-md-3 col-form-label" style="text-align: right;">' + label + '</label><div class="col-md-9"><div class="input-group input-group"><div class="form-control dcl-filename" id="txtDCL' + filenameID + '" style="height: 35px; overflow: auto;"></div><span class="input-group-btn beforeUpload"><input type="file" accept="application/pdf" class="dclFile" id="fileDCL' + filenameID + '" name="fileDCL' + filenameID + '" hidden /><label class="btn btn-primary lblDCLButton dcl-btn" for="fileDCL' + filenameID + '" title="Upload" style="margin-bottom: 0px; cursor: pointer;"><i class="fa fa-upload"></i></label></span><input type="hidden"><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-danger dcl-btn" title="Remove"><i class="fa fa-trash"></i></button></span><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-success dcl-btn" title="Download"><i class="fa fa-download"></i></button></span><span class="input-group-btn"><button type="button" class="btn btn-info dcl-btn" title="Preview"><i class="fa fa-file-pdf"></i></button></span></div></div></div>');
            }else{
                $("#mainDCLPanel").append('<div class="form-group row dc-group"><label class="col-md-3 col-form-label" style="text-align: right;">' + label + '</label><div class="col-md-9"><div class="input-group input-group"><div class="form-control dcl-filename" id="txtDCL' + filenameID + '" style="height: 35px; overflow: auto;"></div><span class="input-group-btn beforeUpload"><input type="file" accept="application/pdf" class="dclFile" id="fileDCL' + filenameID + '" name="fileDCL' + filenameID + '" hidden /><label class="btn btn-primary lblDCLButton dcl-btn" for="fileDCL' + filenameID + '" title="Upload" style="margin-bottom: 0px; cursor: pointer;"><i class="fa fa-upload"></i></label></span><input type="hidden"><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-danger dcl-btn" title="Remove"><i class="fa fa-trash"></i></button></span><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-success dcl-btn" title="Download"><i class="fa fa-download"></i></button></span><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-info dcl-btn" title="Preview"><i class="fa fa-file-pdf"></i></button></span></div></div></div>');
            }
        });
        getOneDCL();
    }

    $(document).on('change', ".dclFile", function(){
        uploadDCLFile(this);
    });

    $(document).on('click', ".dcl-btn", function(){
        var btnName = $(this).attr("title");
        var fileURL = $(this).parent().parent().find("input[type='hidden']").val();
        var fileName = $(this).parent().parent().find(".dcl-filename").eq(0).text();

        if(btnName=="Remove"){
            deleteFile(this, fileName);
        }else if(btnName=="Download"){
            download_file(fileURL, fileName); //call function
        }else if(btnName=="Preview"){
            if(fileURL==""){
                if($(this).parent().parent().find(".dcl-filename").eq(0).attr("id")=="txtDCLPurchasePermit"){
                    window.open(APP_URL + "print/purchase_permit_print.php?oc_no=" + oc_no);
                }
            }else{
                window.open(fileURL);
            }
        }
    });

    function deleteFile(obj, fileName){
        var column_name = "";
        if($(obj).parent().parent().parent().parent().find("label").eq(0).text()!=""){
            column_name = "dc_" + $(obj).parent().parent().parent().parent().find("label").eq(0).text().replace(":", "").replace(".", "").trim().toLowerCase().replace(/\s+/g, "_");
        }

        $.ajax({
            url: APP_URL + "api/sales/pdf_upload/delete.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no, file_name: fileName, column_name: column_name })
        }).done(function(data) {
            if(data.message=="deleted"){
                $(obj).parent().parent().find(".dcl-filename").eq(0).text("");
                $(obj).parent().parent().find("input[type='hidden']").val("");

                $(obj).parent().parent().find(".beforeUpload").eq(0).css("display", "");
                $(obj).parent().parent().find(".afterUpload").eq(0).css("display", "none");
                $(obj).parent().parent().find(".afterUpload").eq(1).css("display", "none");
                $(obj).parent().parent().find(".afterUpload").eq(2).css("display", "none");
                checkPurchasePermit();
            }
        });
    }

    function download_file(fileURL, fileName) {
        // for non-IE
        if (!window.ActiveXObject) {
            var save = document.createElement('a');
            save.href = fileURL;
            save.target = '_blank';
            var filename = fileURL.substring(fileURL.lastIndexOf('/')+1);
            save.download = fileName || filename;
            if ( navigator.userAgent.toLowerCase().match(/(ipad|iphone|safari)/) && navigator.userAgent.search("Chrome") < 0) {
                document.location = save.href; 
                // window event not working here
            }else{
                var evt = new MouseEvent('click', {
                    'view': window,
                    'bubbles': true,
                    'cancelable': false
                });
                save.dispatchEvent(evt);
                (window.URL || window.webkitURL).revokeObjectURL(save.href);
            }   
        }

        // for IE < 11
        else if ( !! window.ActiveXObject && document.execCommand)     {
            var _window = window.open(fileURL, '_blank');
            _window.document.close();
            _window.document.execCommand('SaveAs', true, fileName || fileURL)
            _window.close();
        }
    }

    function uploadDCLFile(obj){
        var column_name = "";
        if($(obj).parent().parent().parent().parent().find("label").eq(0).text()!=""){
            column_name = "dc_" + $(obj).parent().parent().parent().parent().find("label").eq(0).text().replace(":", "").trim().toLowerCase().replace(/\s+/g, "_");
        }

        var orgName = $(obj).attr("name");
        var ofn = $(obj).parent().parent().find(".dcl-filename").eq(0).text();

        $(obj).attr("name", "file");
        var property = document.getElementById($(obj).attr("id")).files[0];
        var file_name = property.name;
        var file_extension = file_name.split(".").pop().toLowerCase();
        
        if(property.type!="application/pdf"){
            bootbox.alert("Invalid File");
        }else{
            var file_size = parseInt(property.size/1000000);//convert bytes to mb
            if(file_size>25){
                bootbox.alert("Exceed File Size.");
            }else{
                $(".dcl-btn").attr("disabled", true);
                $(".dclFile").attr("disabled", true);
                $(".dcl-btn").css("opacity", 0.4);
                $(obj).parent().find(".dcl-btn").eq(0).css("opacity", 1);

                var form_data = new FormData();
                form_data.append($(obj).attr("name"), property);

                $.ajax({
                    url: APP_URL + "api/sales/pdf_upload/upload.php?oc_no=" + oc_no + "&ofn=" + ofn + "&column_name=" + column_name,
                    type: "POST",
                    data: form_data,
                    contentType: false,
                    cache: false,
                    processData: false,
                    xhr: function() {
                        var xhr = $.ajaxSettings.xhr();
                        $(obj).parent().parent().parent().parent().append('<div class="col-md-3 tempProgress"></div><div class="col-md-9 tempProgress" id="progress"></div>');
                        xhr.upload.onprogress = function(e) {
                            var percent = Math.floor(e.loaded / e.total * 100);
                            $("#progress").html('<div class="progress progress-xs"><div class="progress-bar bg-primary progress-bar-striped" role="progressbar" aria-valuenow="' + percent + '" aria-valuemin="0" aria-valuemax="100" style="width: ' + percent + '%"><span class="sr-only">' + percent + '% Complete (success)</span></div></div>');
                        };
                        return xhr;
                    },
                    success:function(data){
                        $(obj).parent().parent().parent().parent().find(".tempProgress").remove();
                        $(obj).parent().parent().find(".dcl-filename").eq(0).text(data.file_name);
                        $(obj).attr("name", orgName);
                        $(obj).parent().parent().find("input[type='hidden']").val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.file_name);

                        $(".dcl-btn").attr("disabled", false);
                        $(".dclFile").attr("disabled", false);
                        $(".dcl-btn").css("opacity", 1);

                        $(obj).parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                        $(obj).parent().parent().find(".afterUpload").eq(0).css("display", "");
                        $(obj).parent().parent().find(".afterUpload").eq(1).css("display", "");
                        $(obj).parent().parent().find(".afterUpload").eq(2).css("display", "");

                        checkPurchasePermit();
                    }
                });
            }
        }
    }

    function getOneDCL(){
        $.ajax({
            url: APP_URL + "api/sales/pdf_upload/get_one_row.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {
            if(data.dc_id!=""){
                $("#txtDCLID").text(data.dc_id);
                $("#fileDCLID").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_id);

                $("#fileDCLID").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLID").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLID").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLID").parent().parent().find(".afterUpload").eq(2).css("display", "");
            }

            if(data.dc_bl!=""){
                $("#txtDCLBL").text(data.dc_bl);
                $("#fileDCLBL").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_bl);

                $("#fileDCLBL").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLBL").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLBL").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLBL").parent().parent().find(".afterUpload").eq(2).css("display", "");
            }

            if(data.dc_custom_statement!=""){
                $("#txtDCLCustomStatement").text(data.dc_custom_statement);
                $("#fileDCLCustomStatement").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_custom_statement);

                $("#fileDCLCustomStatement").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLCustomStatement").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLCustomStatement").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLCustomStatement").parent().parent().find(".afterUpload").eq(2).css("display", "");
            }

            if(data.dc_purchase_permit!=""){
                $("#txtDCLPurchasePermit").text(data.dc_purchase_permit);
                $("#fileDCLPurchasePermit").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_purchase_permit);

                $("#fileDCLPurchasePermit").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLPurchasePermit").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLPurchasePermit").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLPurchasePermit").parent().parent().find(".afterUpload").eq(2).css("display", "");

                // Purchase Permit
                if(data.pp_done==1){
                    $(".ppOwnershipInfo").css("display", "none");
                    $(".ppVehicleInfo").css("display", "none");
                    $(".ppOtherInfo").css("display", "none");
                }
                // Purchase Permit
            }else{
                // Purchase Permit
                $(".ppOwnershipInfo").css("display", "");
                $(".ppVehicleInfo").css("display", "");
                $(".ppOtherInfo").css("display", "");
                // Purchase Permit
            }

            if(data.dc_license!=""){
                $("#txtDCLLicense").text(data.dc_license);
                $("#fileDCLLicense").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_license);

                $("#fileDCLLicense").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLLicense").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLLicense").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLLicense").parent().parent().find(".afterUpload").eq(2).css("display", "");
            }

            if(data.dc_rta_fees_slip!=""){
                $("#txtDCLRTAFeesSlip").text(data.dc_rta_fees_slip);
                $("#fileDCLRTAFeesSlip").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_rta_fees_slip);

                $("#fileDCLRTAFeesSlip").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLRTAFeesSlip").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLRTAFeesSlip").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLRTAFeesSlip").parent().parent().find(".afterUpload").eq(2).css("display", "");
            } 
        });
    }
    // Document Collect

    // Purchase Permit
    function checkPurchasePermit(){
        $.ajax({
            url: APP_URL + "api/sales/pdf_upload/get_one_row.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {
            if(data.dc_purchase_permit!="" && data.pp_done==1){
                // Purchase Permit
                $(".ppOwnershipInfo").css("display", "none");
                $(".ppVehicleInfo").css("display", "none");
                $(".ppOtherInfo").css("display", "none");
                // Purchase Permit
            }else{
                // Purchase Permit
                $(".ppOwnershipInfo").css("display", "");
                $(".ppVehicleInfo").css("display", "");
                $(".ppOtherInfo").css("display", "");
                // Purchase Permit
            }
        });
    }

    function goToDocumentCollect(){
        $(".myStepper li").removeClass("current");
        $("#DocumentCollect").addClass("current");
        $(".branch").css("display", "none");
        $("[data-id='DocumentCollect']").css("display", "");

        $(".dcl-filename").removeClass('box-shadow');
        $('#txtDCLPurchasePermit').addClass('box-shadow'); 
        setTimeout(function() {
            $('#txtDCLPurchasePermit').removeClass('box-shadow');
        }, 1000)
        document.getElementById('txtDCLPurchasePermit').scrollIntoView();
    }

    $("#cboPPRTADCode").on("change", function(){
        getNRCCodeByOwnershipPP();
    });

    $("#cboPPOtherCode").on("change", function(){
        getNRCCodeByOtherPP();
    });

    function getNRCCodeByOwnershipPP(tc){
        var states_divisions_code = $("#cboPPRTADCode").val(); 
        $("#cboPPRTADTownshipCode").find("option").remove();
        $("#cboPPRTADTownshipCode").append("<option value = ''></option>"); 
        $.ajax({
            url: APP_URL + "api/nrc_code/get_nrc_by_sd_code.php",
            type: "POST",
            data: JSON.stringify({ states_divisions_code: states_divisions_code })
        }).done(function(data) {    
            $.each(data.records, function(i, v) {   
                if(v.townships_code==tc){
                    $("#cboPPRTADTownshipCode").append("<option value= '" + v.townships_code + "' selected>" + v.townships_code + "</option>"); 
                }else{
                    $("#cboPPRTADTownshipCode").append("<option value= '" + v.townships_code + "'>" + v.townships_code + "</option>"); 
                }
            });
        });
    } 

    function getNRCCodeByOtherPP(tcother){
        var states_divisions_code = $("#cboPPOtherCode").val();  
        $("#cboPPOtherTownshipCode").find("option").remove();
        $("#cboPPOtherTownshipCode").append("<option value = ''></option>");
        $.ajax({
            url: APP_URL + "api/nrc_code/get_nrc_by_sd_code.php",
            type: "POST",
            data: JSON.stringify({ states_divisions_code: states_divisions_code })
        }).done(function(data) {    
            $.each(data.records, function(i, v) {   
                if(v.townships_code==tcother){
                    $("#cboPPOtherTownshipCode").append("<option value= '" + v.townships_code + "' selected>" + v.townships_code + "</option>");
                }else{
                    $("#cboPPOtherTownshipCode").append("<option value= '" + v.townships_code + "'>" + v.townships_code + "</option>");
                }
            });
        });
    } 
 
    function getOneOldInfoPP(){
        $.ajax({
            url: APP_URL + "api/sales/sales/get_one_oc.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {    
            $("#txtPPRTADName").val(data.customer_name);
            if(data.nrc_no){
                if(data.nrc_no.includes("/") && data.nrc_no.includes("(") && data.nrc_no.includes(")")){
                    var nrc = data.nrc_no.split("/");
                    $("#cboPPRTADCode").val(nrc[0]);
                    var tc = nrc[1].split("(");
                    getNRCCodeByOwnershipPP(tc[0]);
                    var type = tc[1].split(")");
                    $("#cboPPRTADNRCType").val("(" + type[0] + ")");
                    $("#txtPPRTADNRCNo").val(type[1]);
                }
            }
            $("#txtPPRTADMobileNo").val(data.mobile_no);
            $("#txtPPRTADEmail").val(data.email);
            $("#txtPPRTADAddress").val(data.address);
            $("#txtPPSalesCenter").val(data.sales_center);
            $("#txtPPBank").val(data.bank);

            $("#txtPPBrand").val(data.brand);
            $("#txtPPVehicleType").val(data.model_name);
            $("#txtPPModelYear").val(data.model_year);
            $("#txtPPEnginePower").val(data.engine_no);
            $("#txtPPValue").val(data.vehicle_price); 
        });
    }

    function submitPP(){ 
        // Main Info
        var permit_submission_date = $("#txtDatePickerPPSubmission").val();
        var permit_received_date = $("#txtDatePickerPPReceived").val();
        // Main Info

        // Ownership Info 
        var name = $("#txtPPRTADName").val();

        var nrc_no = "";
        var nrc_no_scode = (($("#cboPPRTADCode").val())?($("#cboPPRTADCode").val()):"");
        var nrc_no_tcode = (($("#cboPPRTADTownshipCode").val())?($("#cboPPRTADTownshipCode").val()):"");
        var nrc_no_type = (($("#cboPPRTADNRCType").val())?($("#cboPPRTADNRCType").val()):"");
        var nrc_no_seq = $("#txtPPRTADNRCNo").val();
        if(nrc_no_scode!="" && nrc_no_tcode!="" && nrc_no_type!="" && nrc_no_seq!=""){
            nrc_no = nrc_no_scode + "/" + nrc_no_tcode + nrc_no_type + nrc_no_seq;
        }

        var mobile_no = $("#txtPPRTADMobileNo").val();
        var email = $("#txtPPRTADEmail").val();
        var address = $("#txtPPRTADAddress").val();
        var sales_center = $("#txtPPSalesCenter").val();
        var bank = $("#txtPPBank").val();
        var ac_no = $("#txtPPBankAcc").val();
        var foreign_currency_balance = $("#txtPPForeignCurrencyBalance").val();
        var balance_date = $("#txtDatePickerPP").val();
        // Ownership Info

        // Vehicle Info
        var vehicle_type = $("#txtPPVehicleType").val();
        var brand = $("#txtPPBrand").val();
        var model_year = $("#txtPPModelYear").val();
        var engine_power = $("#txtPPEnginePower").val();
        var value = $("#txtPPValue").val();
        var country_of_origin = $("#txtPPCountryOfOrigin").val();
        var commission = $("#txtPPCommission").val();
        var according_to = $("#txtPPAccordingTo").val();
        // Vehicle Info

        // Other Info
        var other_name = $("#txtPPOtherName").val();

        var other_nrc_no = "";
        var other_nrc_no_scode = (($("#cboPPOtherCode").val())?($("#cboPPOtherCode").val()):"");
        var other_nrc_no_tcode = (($("#cboPPOtherTownshipCode").val())?($("#cboPPOtherTownshipCode").val()):"");
        var other_nrc_no_type = (($("#cboPPOtherNRCType").val())?($("#cboPPOtherNRCType").val()):"");
        var other_nrc_no_seq = $("#txtPPOtherNRCNo").val();
        if(other_nrc_no_scode!="" && other_nrc_no_tcode!="" && other_nrc_no_type!="" && other_nrc_no_seq!=""){
            other_nrc_no = other_nrc_no_scode + "/" + other_nrc_no_tcode + other_nrc_no_type + other_nrc_no_seq;
        }

        var other_address = $("#txtPPOtherAddress").val();
        // Other Info

        var pp_done = ($("#chkPPDone").prop("checked"))?1:0;

        if(name==""){
            bootbox.alert("Please fill name."); 
        }else{
            $.ajax({
                url: APP_URL + "api/sales/purchase_permit/create.php",
                type: "POST",
                data: JSON.stringify({ oc_no: oc_no, permit_submission_date: permit_submission_date, permit_received_date: permit_received_date, name: name, nrc: nrc_no, mobile_no: mobile_no, email: email, address: address, sales_center: sales_center, bank: bank, ac_no: ac_no, foreign_currency_balance: foreign_currency_balance, balance_date: balance_date, vehicle_type: vehicle_type, brand: brand, model_year: model_year, engine_power: engine_power, value: value, country_of_origin: country_of_origin, commission: commission, according_to: according_to, other_name: other_name, other_nrc: other_nrc_no, other_address: other_address, pp_done: pp_done })
            }).done(function(data){ 
                if(data.message=="updated" || data.message=="created"){  
                    bootbox.confirm({
                        message: "<h4>Successfully signature upload. Do you want to print purchase permit?</h4>",
                        buttons: {
                            cancel: {
                                label: '<span class="glyphicon glyphicon-ok"></span> No',
                                className: 'btn-danger'
                            },
                            confirm: {
                                label: '<span class="glyphicon glyphicon-ok"></span> Yes',
                                className: 'btn-primary'
                            }
                        },
                        callback: function (result) {
                            if(result){
                                window.open(APP_URL + "print/purchase_permit_print.php?oc_no=" + oc_no);
                            } 
                        }
                    }); 
                    checkStatus();
                    if(pp_done){
                        document.location = APP_URL + "sales/sales_list.php";
                    }
                }else if(data.message=="session expire"){
                    bootbox.alert("Session Expire! Please refresh the browser and login again.");
                }else{
                    bootbox.alert("Error on server side.");
                }
            });
        }   
    }

    function getOnePurchasePermit(){
        $.ajax({
            url: APP_URL + "api/sales/purchase_permit/get_one_row.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {    
            if(data.permit_submission_date){
                $("#txtDatePickerPPSubmission").val(data.permit_submission_date);
            }
            if(data.permit_received_date){
                $("#txtDatePickerPPReceived").val(data.permit_received_date);
            }

            if(data.pp_done==1){
                $(".pp-info").attr("disabled", true);
                $("#ppDone").css("display", "none"); 
            }else{
                $(".pp-info").attr("disabled", false);
                $("#ppDone").css("display", ""); 
            }
            if(data.name){
                $("#txtPPRTADName").val(data.name);
                if(data.nrc){
                    if(data.nrc.includes("/") && data.nrc.includes("(") && data.nrc.includes(")")){
                        var nrc = data.nrc.split("/");
                        $("#cboPPRTADCode").val(nrc[0]);
                        var tc = nrc[1].split("(");
                        getNRCCodeByOwnershipPP(tc[0]);
                        var type = tc[1].split(")");
                        $("#cboPPRTADNRCType").val("(" + type[0] + ")");
                        $("#txtPPRTADNRCNo").val(type[1]);
                    }
                }
                $("#txtPPRTADMobileNo").val(data.mobile_no);
                $("#txtPPRTADEmail").val(data.email);
                $("#txtPPRTADAddress").val(data.address);
                $("#txtPPSalesCenter").val(data.showroom);
                $("#txtPPBank").val(data.bank);
                $("#txtPPBankAcc").val(data.ac_no);
                $("#txtPPForeignCurrencyBalance").val(data.foreign_currency_balance);
                $("#txtDatePickerPP").val(data.balance_date);
                $("#datePickerPP").datepicker("setDate", data.balance_date); 

                $("#txtPPBrand").val(data.brand);
                $("#txtPPVehicleType").val(data.vehicle_type);
                $("#txtPPModelYear").val(data.model_year);
                $("#txtPPEnginePower").val(data.engine_power);
                $("#txtPPValue").val(data.value); 
                $("#txtPPCountryOfOrigin").val(data.country_of_origin);
                $("#txtPPCommission").val(data.commission);
                $("#txtPPAccordingTo").val(data.according_to);

                $("#txtPPOtherName").val(data.other_name);
                if(data.other_nrc){
                    if(data.other_nrc.includes("/") && data.other_nrc.includes("(") && data.other_nrc.includes(")")){
                        var other_nrc = data.other_nrc.split("/");
                        $("#cboPPOtherCode").val(other_nrc[0]);
                        var other_tc = other_nrc[1].split("(");
                        getNRCCodeByOtherPP(other_tc[0]);
                        var other_type = other_tc[1].split(")");
                        $("#cboPPOtherNRCType").val("(" + other_type[0] + ")");
                        $("#txtPPOtherNRCNo").val(other_type[1]);
                    }
                }
                $("#txtPPOtherAddress").val(data.other_address);
            }else{
                getOneOldInfoPP();
            }
        });
    }
    // Purchase Permit

    // RTA Appointment
    function addAppointmentDateTime(){
        var appointment_date = $("#txtDatePickerAppt").val();
        var appointment_time = $("#txtTimePickerAppt").val();
        var rta_office_location = $("#txtApptRTAOfficeLocation").val();
        var appt_done = ($("#chkApptDone").prop("checked"))?1:0;

        $.ajax({
            url: APP_URL + "api/sales/sales/update_appointment_date_time.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no, appointment_date: appointment_date, appointment_time: appointment_time, rta_office_location: rta_office_location, appt_done: appt_done })
        }).done(function(data){ 
            if(data.message=="updated"){
                bootbox.alert("Successfully submitted."); 
                checkStatus();
            }else if(data.message=="session expire"){
                bootbox.alert("Session Expire! Please refresh the browser and login again.");
            }else{
                bootbox.alert("Error on server side.");
            }
        });
    }
    // RTA Appointment

    // Plate Number
    $("#btnPNSubmit").click(function(){
        $("#frmPNEntry").submit();
    });

    $("#frmPNEntry").on('submit',(function(e) {
        e.preventDefault();             
        var formData = new FormData(this);

        var region_code = $("#cboPNRegionalCode").val();
        var township_code = $("#txtPNTownshipCode").val();
        var prefix_no = $("#txtPNPrefixNo").val();
        var suffix_no = $("#txtPNSuffixNo").val();
        var plate_no = region_code + " " + township_code + " " + prefix_no + "-" + suffix_no;
        var special_plate = 0;
        var pn_done = ($("#chkPNDone").prop("checked"))?1:0;

        if($("#chkSpecialPlate").parent().hasClass("off")==false){
            special_plate = 1;
        }
        
        var objArr = [];
        objArr.push({ "oc_no": oc_no, "plate_no": plate_no, "special_plate": special_plate, "pn_done": pn_done });
        formData.append('objArr', JSON.stringify( objArr ));

        if(prefix_no=="" || suffix_no==""){
            bootbox.alert("Please fill Plate No.");
        }else{
            $("#btnPNSubmit").attr("disabled", true);
            $.ajax({
                url: APP_URL + "api/sales/sales/update_plate_no.php",
                type: "POST",
                processData: false,
                contentType: false,
                data: formData,
                success: function(data){    
                    $("#btnPNSubmit").attr("disabled", false);
                    if(data.message=="updated"){
                        bootbox.alert("Successfully submitted.");

                        checkStatus();
                        if(pn_done){
                            document.location = APP_URL + "sales/sales_list.php";
                        }
                    }else if(data.message=="session expire"){
                        bootbox.alert("Session Expire! Please refresh the browser and login again.");
                    }else{
                        bootbox.alert("Error on server side.");
                    }
                }
            });
        }
    }));
    // Plate Number 

    function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if ( (charCode > 31 && charCode < 48) || charCode > 57) {
            return false;
        }
        return true;
    } 
</script>