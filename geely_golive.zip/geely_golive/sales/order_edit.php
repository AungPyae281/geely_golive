<?php include '../header.php'; ?>
<?php
	$oc_no = "";
	if(isset($_GET['oc_no'])){
		if(!empty($_GET['oc_no'])){
			$oc_no = $_GET['oc_no'];
		}
	}
?> 

<style>
	label{
		padding-top: 3px !important;
		padding-left: 0px !important;
		padding-right: 0px !important;
	}
	.input-group-addon{
		height: 36px !important;
	}
	#toggleStatus .active{
    	background-color: #0062cc;
    	border-color: #0062cc;
    	color: #ffffff;
    }
    #toggleStatus .btn-group-toggle>label:hover{
    	background-color: #0062cce3;
    	border-color: #0062cce3;
    	color: #ffffff;
    }
    #toggleStatus .btn-group-toggle>label{
    	cursor: pointer;
    	min-width: 100px;
    	padding-top: 8px !important;
		padding-left: 8px !important;
		padding-right: 8px !important;
    }
    #toggleStatus .toggle{
		min-height: 31px !important;
	}
	.checkbox-inline {
		padding-top: 1px !important;
		margin-bottom: 0px !important;
	}
	.checkbox-inline .toggle{
		margin-left: 0px !important;
		width: 75px !important;
	}
	.toggle-on, .toggle-off{
		line-height: 25px !important;
	}
	.previewing{
		width: 100%;
		height: 135px;
		cursor: pointer; 
		object-fit: cover;
	}
	.displayNone{
		display: none;
	}
	.toggle{
		min-width: 100px !important;
	}
	.checkbox{
		float: right;
	}
	select{
		padding-top: 2px !important;
	}
</style> 
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Order - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title" style="font-weight: bold;" id="txtSalesCenter"><?=$_SESSION['sales_center'];?></h3>
							<input type="hidden" id="txtStaffID" value="">
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row" style="display:none;">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">O.C No.:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtOCNo" disabled value="-">
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Order Date:</label>
											<div class="col-md-8">  
												<div class="input-group input-append date" id="datePicker" data-date="2020-02-07" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell; height: 31px !important;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Sales Type:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboSalesType">
													<option value="Fix">Fix</option>
													<option value="Staff">Staff</option>
													<option value="Retail">Retail</option> 
													<option value="Government">Government</option>
													<option value="Fleet">Fleet</option> 
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="row" style="padding-top: 9px;">
									<div class="col-md-12">
										<div class="card card-outline card-outline-tabs">
											<div class="card-header p-0 border-bottom-0">
												<ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
													<li class="nav-item">
														<a class="nav-link active" id="custom-tabs-four-customer-tab" data-toggle="pill" href="#custom-tabs-four-customer" role="tab" aria-controls="custom-tabs-four-customer" aria-selected="true">Customer Info</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" id="custom-tabs-four-rtad-tab" data-toggle="pill" href="#custom-tabs-four-rtad" role="tab" aria-controls="custom-tabs-four-rtad" aria-selected="false">RTAD Register Info</a>
													</li>
												</ul>
											</div>
											<div class="card-body">
												<div class="tab-content" id="custom-tabs-four-tabContent">
													<div class="tab-pane fade active show" id="custom-tabs-four-customer" role="tabpanel" aria-labelledby="custom-tabs-four-customer-tab">
														<div class="row brokerInfoPanel">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Broker Registration No.: </label>
																	<div class="col-md-8">
																		<div class="input-group input-group">
																			<input id="txtBrokerID" value='' class="form-control" style="display: none;" >
																			<input type="text" class="form-control" id="txtBrokerRegistrationNo" disabled style="border-radius: 3px;">
																			<span class="input-group-btn">
																				<button type="button" class="btn btn-success" onclick="getBrokerModal()" id="btnBroker" style="padding: 0.28rem 0.75rem;">. . .</button>
																			</span>         
																		</div>
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Broker Name:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtBrokerName" disabled>
																	</div>
																</div>
															</div>
														</div>
														<hr class="brokerInfoPanel">
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerRegistrationNo" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
																	<div class="col-md-8">
																		<input type="hidden" class="form-control" id="txtCustomerID" disabled>
																		<input type="text" class="form-control" id="txtCustomerName" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Type:</label>
																	<div class="col-md-8">
																		<select class="form-control" id="cboCustomerType">	
																			<option value="Individual">Individual</option>
																			<option value="B2B">B2B</option>
																		</select>
																	</div>
																</div>
																<div class="form-group row companyInfo" style="display: none;">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Company Name:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCompanyName">
																	</div>
																</div>
																<div class="form-group row companyInfo" style="display: none;">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Company Register No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCompanyRegisterNo">
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">NRC No.<span style="color: red; font-size: 20px;">*</span>:</label>
																	<div class="col-md-8">
																		<select class="form-control" id="cboCode" style="padding-left: 5px; width: 17%; display: inline-block !important;">
																			<option value=""></option>
																			<option value="1">1</option>
																			<option value="2">2</option>
																			<option value="3">3</option>
																			<option value="4">4</option>
																			<option value="5">5</option>
																			<option value="6">6</option>
																			<option value="7">7</option>
																			<option value="8">8</option>
																			<option value="9">9</option>
																			<option value="10">10</option>
																			<option value="11">11</option>
																			<option value="12">12</option>
																			<option value="13">13</option>
																			<option value="14">14</option>
																		</select>
																		<select class="form-control" id="cboTownshipCode" style="display: inline-block !important; width: 31%;">
																		</select>
																		<select class="form-control" id="cboCustomerNRCType" style="display: inline-block !important;width: 17%; padding-left: 5px;">
																			<option value=""></option>
																			<option value="(N)">(N)</option>
																			<option value="(P)">(P)</option>
																			<option value="(A)">(A)</option>
																		</select>
																		<input type="text" class="form-control" id="txtCustomerNRCNo" onkeypress="return isNumber(event)" maxlength="6" style="text-align: right; padding-left: 0px; width: 31%; display: inline-block !important;">
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtMobileNo" disabled onkeypress="return isNumber(event)">
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Email:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtEmail" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerTownship" disabled>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div class="tab-pane fade" id="custom-tabs-four-rtad" role="tabpanel" aria-labelledby="custom-tabs-four-rtad-tab">
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Same as Buyer:</label>
																	<div class="col-md-8">
																		<div class="input-group mb-3" style="margin-bottom: 0px !important;">
																			<div class="checkbox">
																				<label class="checkbox-inline" style="padding-left: 20px;">
																				    <input type="checkbox" data-toggle="toggle" id="chkSameAsBuyer" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="default" class="ssToggle" checked>
																				</label>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtRTADName" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">NRC No.<span style="color: red;font-size: 20px;">*</span>:</label>
																	<div class="col-md-8">
																		<select class="form-control" id="cboRTADCode" style="padding-left: 5px; width: 17%; display: inline-block !important;" disabled>
																			<option value=""></option>
																			<option value="1">1</option>
																			<option value="2">2</option>
																			<option value="3">3</option>
																			<option value="4">4</option>
																			<option value="5">5</option>
																			<option value="6">6</option>
																			<option value="7">7</option>
																			<option value="8">8</option>
																			<option value="9">9</option>
																			<option value="10">10</option>
																			<option value="11">11</option>
																			<option value="12">12</option>
																			<option value="13">13</option>
																			<option value="14">14</option>
																		</select>
																		<select class="form-control" id="cboRTADTownshipCode" style="display: inline-block !important;width: 31%;" disabled>
																		</select>
																		<select class="form-control" id="cboRTADNRCType" style="display: inline-block !important;width: 17%;padding-left: 5px;" disabled>
																			<option value=""></option>
																			<option value="(N)">(N)</option>
																			<option value="(P)">(P)</option>
																			<option value="(A)">(A)</option>
																		</select>
																		<input type="text" class="form-control" id="txtRTADNRCNo" onkeypress="return isNumber(event)" maxlength="6" style="text-align: right; padding-left: 0px; width: 31%; display: inline-block !important;" disabled>
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtRTADMobileNo" disabled onkeypress="return isNumber(event)">
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
																	<div class="col-md-8">
																		<div class="input-group input-group">
																			<input id="txtRTADTownship" value='' class="form-control" disabled>
																			<span class="input-group-btn">
																				<button type="button" class="btn btn-primary" onclick="getAllTownship()" id="btnTownship" style="padding-bottom: 3px;">. . .</button>
																			</span>         
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								
								<!-- Vehicle Info -->
								<div class="row">
									<div class="col-md-12">
										<div class="card card-outline">
											<div class="card-header">
												<h3 class="card-title">Vehicle Info <span id="txtTotalRecord" style="font-weight: bold;"></span></h3>

												<div class="checkbox">
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkChangeToggle" data-on="Change" data-off="Change" data-onstyle="success">
													</label>
												</div>
											</div>
											<div class="card-body">
												<div class="row" style="padding-bottom: 12px;" id="toggleStatus">
													<div class="btn-group btn-group-toggle" data-toggle="buttons">
														<label class="btn btn-default active">
															<input type="radio" name="optStatus" class="vehicleDisabledEnabled" id="optInstock" value="Instock" autocomplete="off" checked disabled> Instock Sales
														</label>
														<label class="btn btn-default">
															<input type="radio" name="optStatus" class="vehicleDisabledEnabled" id="optPreorder" value="Preorder" autocomplete="off" disabled> Pre Order
														</label>
														<label class="btn btn-default">
															<input type="radio" name="optStatus" class="vehicleDisabledEnabled" id="optProduction" value="Production" autocomplete="off" disabled> Production Order
														</label> 
													</div>
												</div>
												<div class="row">
													<div class="col-md-6">
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Brand:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboBrand" disabled></select>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Model:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboModelName" disabled></select>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Model Year:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboModelYear" disabled></select>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Grade:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboGrade" disabled></select>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Exterior Color:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboExteriorColor" disabled></select>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Interior Color:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboInteriorColor" disabled></select>
															</div>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group row VENo">
															<label class="col-md-4 col-form-label" style="text-align: right;">Vin No.:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboVinNo" disabled></select>
																<!-- <input type="text" id="txtVinNo" class="form-control vehicleDisabledEnabled" disabled value="" style="float:right;"> -->
															</div>
														</div>
														<div class="form-group row VENo">
															<label class="col-md-4 col-form-label" style="text-align: right;">Engine No.:</label>
															<div class="col-md-8">
																<input type="text" id="txtEngineNo" class="form-control" disabled value="" style="float:right;">
															</div>
														</div>

														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;"></label>
															<div class="col-md-4">
																<img class="img-responsive previewing" id="InteriorImg" name="previewing" src="<?=$app_url;?>img/1.jpg">
															</div>
															<div class="col-md-4">
																<img class="img-responsive previewing" id="ExteriorImg" name="previewing" src="<?=$app_url;?>img/2.jpg">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!-- Vehicle Info -->

								<!-- Calculation -->
								<div class="row" style="padding-top: 12px;">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Promotion Code:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPromotionCode">
											</div>	
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Deposit:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtDeposit" value="1,000,000" style="text-align:right;" onkeypress="return isNumber(event)" onkeyup="btozero(this); AddComma(this);">
											</div>	
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment Type:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboPaymentType">
													<option value="Cash">Cash</option>
													<option value="HP">HP</option>
													<option value="InHouse">InHouse</option>
												</select>
											</div>
										</div>
										<div class="form-group row connectHP">
											<label class="col-md-4 col-form-label" style="text-align: right;">Bank:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboBank">
													<option value=""></option>
													<option value="AGD">AGD</option>
													<option value="AYA">AYA</option>
													<option value="CB">CB</option>
													<option value="MCB">MCB</option>
													<option value="MAB">MAB</option>
													<option value="YOMA">YOMA</option>
												</select>
											</div>
										</div>
										<div class="form-group row connectHP connectInHouse">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment (%):</label>
											<div class="col-md-8">
												<select class="form-control" id="cboPaymentPercent"></select>
											</div>
										</div>
										<div class="form-group row connectHP connectInHouse">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment Term (Month):</label>
											<div class="col-md-8">
												<select class="form-control" id="cboPaymentTerm"></select>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Vehicle Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtVehiclePrice" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Commercial Tax:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtCommercialTax" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Retail Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtRetailPrice" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Registration Tax & Fees:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtRTADTax" value="0" style="text-align:right;" disabled>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Total Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtTotalPrice" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Promotion Discount:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPromotionDiscount" value="0" style="text-align:right;" disabled>
											</div>	
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Selling Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtSellingPrice" value="0" disabled style="text-align:right;">
											</div>
										</div> 
										<div class="form-group row">
											<div class="col-md-6"></div>
											<div class="col-md-6" style="text-align: right;">
												<button type="button" class="btn btn-danger btnAction" id="btnReject" style="display:none;">Reject</button>
												<button type="button" class="btn btn-success btnAction" id="btnApprove" style="display:none;" onclick="validateAndUpdate(this);">Approve</button> 
											</div>
										</div> 
									</div>
								</div>
								<!-- Calculation -->
							</div>
						</form>
					</div>
				</div>
			</div>

			<center>
				<div class="modal fade" id="myModalBroker">
					<div class="modal-dialog" style="max-width: 100% !important;">
						<div class="modal-content" style="width: 50%;top: 29px;margin-left: 25%;">
							<div class="modal-header">
								<h4 class="modal-title">Broker <span id="total_records" style="font-weight:bold;"> </span></h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<table class="table table-head-fixed" id="myTableBroker" style="cursor:pointer;">
									<thead style="background-color: #ecedee;">                  
										<tr>
											<th style="width: 3%">#</th>
											<th>ID</th>
											<th>Registration No.</th>
											<th>Name</th>
											<th>Phone</th>
											<th>NRC No.</th>
										</tr>
									</thead>
									<tbody></tbody>
								</table>
							</div>
						</div>
					</div>
				</div> 
			</center>

			<center>
				<div id="myModalReject" class="modal fade modal-primary"> 
					<div class="modal-dialog" style="max-width: 100% !important;">
						<div class="modal-content" style="width: 515px; top: 45px;">
							<div class="modal-header" style="padding-top: 7px; padding-bottom: 7px;">
								<h3 class="modal-title" style="font-size: 17px; font-weight: bold;" id="">Reject Remark - Entry</h3>
								<button type="button" class="close" data-dismiss="modal">×</button>
							</div>
							<div class="modal-body">
								<div class="row">
									<div class="col-md-12 col-sm-12">
										<div class="form-group row">
											<label class="col-md-3 col-form-label" style="text-align: right;">Remark: </label>
											<div class="col-md-9">
												<textarea class="form-control" id="txtRejectRemark" rows="4"></textarea>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-8"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-block btn-danger btnAction" id="btnRejectM" onclick="validateAndUpdate(this);">Reject</button>
											</div>
										</div>
									</div>
								</div> 
							</div>
						</div>
					</div>
				</div>
			</center>

			<center>
				<div class="modal fade" id="myModalTownshipList">
					<div class="modal-dialog" style="max-width: 100% !important;">
						<div class="modal-content" style="width: 65%; top: 30px;">
							<div class="modal-header">
								<h4 class="modal-title">Township List <span id="total_records" style="font-weight:bold;"> </span></h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<table id="myTable1" class="table table-bordered table-hover">
									<thead style="background-color: #ecedee;">
										<tr>
											<th>State/Division</th>
											<th>City</th>
											<th>Township</th>
										</tr>
									</thead>
									<tbody style="cursor: pointer;"></tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</center>

		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>  
	var OCNO = '<?= $oc_no ?>';
	
	var APPROVAL_ORDER_NO = 0;
	var OLDBRAND = "";
	var OLDMODEL = "";
	var OLDMODELYEAR = "";
	var OLDGRADE = "";
	var OLDEXTERIORCOLOR = "";
	var OLDINTERIORCOLOR = "";
	var OLDVINNO = "";
	var OLDENGINENO = "";
	var OLDVEHICLEPRICE = "";
	var OLDRTADTAX = "";
	var VEHICLE_STATUS = "";

	var modelNames = [];
	var modelYears = [];
	var grades = [];
	var exteriorColors = [];	
	var interiorColors = [];	
	var prices = [];	

	var btnStatus = "Submit Approval";
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");
		$('#datePicker').datepicker();

		getPaymentTerm();
		getPaymentPercent(); 

		if($("#cboPaymentType").val()=="HP"){
			$(".connectHP").css("display", "");
		}else if($("#cboPaymentType").val()=="InHouse"){
			$(".connectHP").css("display", "none");
			$(".connectInHouse").css("display", "");
		}else{
			$(".connectHP").css("display", "none");
		}

		getOneOrder();
	});

	$("#chkChangeToggle").change(function(){
		if(!$(this).parent().hasClass("off")){
			$(".vehicleDisabledEnabled").attr("disabled", false);
			$("input[name='optStatus']:checked").parent().removeClass("active");
			$("#optInstock").prop("checked", true);
			$("#optInstock").parent().addClass("active");

			getAllVinNoByBMYGEI();
			$("#txtEngineNo").val("");
			getAllBMYGEI();
		}else{
			$(".vehicleDisabledEnabled").attr("disabled", true);

			$("input[name='optStatus']:checked").parent().removeClass("active");
			$("#opt" + VEHICLE_STATUS).prop("checked", true);
			$("#opt" + VEHICLE_STATUS).parent().addClass("active");

			$("#cboBrand").append("<option value='" + OLDBRAND + "' data-id='" + OLDBRAND.charAt(0).toUpperCase() + "' selected>" + OLDBRAND + "</option>");
			$("#cboModelName").append("<option value='" + OLDMODEL + "' selected>" + OLDMODEL + "</option>");
			$("#cboModelYear").append("<option value='" + OLDMODELYEAR + "' selected>" + OLDMODELYEAR + "</option>");
			$("#cboGrade").append("<option value='" + OLDGRADE + "' selected>" + OLDGRADE + "</option>");
			$("#cboExteriorColor").append("<option value='" + OLDEXTERIORCOLOR + "' selected>" + OLDEXTERIORCOLOR + "</option>");
			$("#cboInteriorColor").append("<option value='" + OLDINTERIORCOLOR + "' selected>" + OLDINTERIORCOLOR + "</option>");

			$("#cboVinNo").append("<option value='" + OLDVINNO + "' data-engine-no='" + OLDENGINENO + "' selected>" + OLDVINNO + "</option>");
			$("#txtEngineNo").val(OLDENGINENO);		
			
			$("#txtVehiclePrice").val(OLDVEHICLEPRICE);
			$("#txtRTADTax").val(OLDRTADTAX);
			calculate();
		}
	});

	$('#cboCustomerType').change(function(){
	    var type = $(this).find('option:selected').val();
	   if(type=="B2B"){
	   		$(".companyInfo").css("display", "");
	   }else{
	   		$(".companyInfo").css("display", "none");
	   }
	});

	$("#cboCode").change(function(){	
		getNRCCodeByCustomer();
		changeBuyer();
	});

	$("#cboTownshipCode").change(function(){
		changeBuyer();
	});

	$("#cboCustomerNRCType").change(function(){
		changeBuyer();
	});

	$("#cboRTADCode").change(function(){	
		getNRCCodeByRTAD();
	});

	$("#chkSameAsBuyer").change(function() {
		changeBuyer();
	});

	$("#txtCustomerNRCNo").on('input', function(){
		changeBuyer();
	});

	$("#cboBrand").change(function(){
		changeModelName();
	});

	$("#cboModelName").change(function(){
		changeModelYear();
	});

	$("#cboModelYear").change(function(){
		changeGrade();
	});

	$("#cboGrade").change(function(){
		changeExteriorColor();
	});

	$("#cboExteriorColor").change(function(){
		changeInteriorColor();
	});

	$("#cboInteriorColor").change(function(){
		changePrice();
	});

	$("#cboVinNo").change(function(){
		$("#txtEngineNo").val($("#cboVinNo option:selected").attr("data-engine-no")); 
	});

	$("#btnReject").click(function(){
		$("#myModalReject").modal('show');
	}); 

	$("input[name='optStatus']").change(function(){
		var status = $("input[name='optStatus']:checked").val();
		$(".VENo").css("display", "none");
		if(status!="Production") $(".VENo").css("display", "");
		$("#cboVinNo").val("");
		$("#txtEngineNo").val("");
		getAllBMYGEI();
		changeCarStatus();
	});

	$('#cboPaymentType').on('change',function(){
	    var payment_type = $(this).find('option:selected').val();
		if(payment_type=="HP"){
			$(".connectHP").css("display", "");
		}else if($("#cboPaymentType").val()=="InHouse"){
			$(".connectHP").css("display", "none");
			$(".connectInHouse").css("display", "");
			$("#cboBank").val("");
		}else{
			$(".connectHP").css("display", "none");			
			$("#cboBank").val("");
			$("#cboPaymentPercent").val("");
			$("#cboPaymentTerm").val("");
		}
	});

	// $("#txtPromotionCode").on("blur", function(){
	// 	getPromotion();
	// }); 

	$("#txtPromotionCode").on( "keyup", function() {
	  getPromotion();
	} );



	function getNRCCodeByCustomer(tc){
        var states_divisions_code = $("#cboCode").val(); 
     	$("#cboTownshipCode").find("option").remove();
		$("#cboTownshipCode").append("<option value = ''></option>");
		$.ajax({
			url: APP_URL + "api/nrc_code/get_nrc_by_sd_code.php",
			type: "POST",
			data: JSON.stringify({ states_divisions_code: states_divisions_code })
		}).done(function(data) {	
			$.each(data.records, function(i, v) {	
				if(v.townships_code==tc){
					$("#cboTownshipCode").append("<option value= '" + v.townships_code + "' selected>" + v.townships_code + "</option>"); 
				}else{
					$("#cboTownshipCode").append("<option value= '" + v.townships_code + "'>" + v.townships_code + "</option>");
				}
			});
		});
    }

    function getNRCCodeByRTAD(tc){
        var states_divisions_code = $("#cboRTADCode").val(); 
     	$("#cboRTADTownshipCode").find("option").remove();
		$("#cboRTADTownshipCode").append("<option value = ''></option>");
		$.ajax({
			url: APP_URL + "api/nrc_code/get_nrc_by_sd_code.php",
			type: "POST",
			data: JSON.stringify({ states_divisions_code: states_divisions_code })
		}).done(function(data) {	
			$.each(data.records, function(i, v) {	
				if(v.townships_code==tc){
					$("#cboRTADTownshipCode").append("<option value= '" + v.townships_code + "' selected>" + v.townships_code + "</option>");
				}else{
					$("#cboRTADTownshipCode").append("<option value= '" + v.townships_code + "'>" + v.townships_code + "</option>");
				}
			});
		});
    }

    function getPaymentTerm(pt){
		$("#cboPaymentTerm").find("option").remove();
		$("#cboPaymentTerm").append("<option value= '' data-id = ''></option>");
		$.ajax({
			url: APP_URL + "api/payment_config/payment_term/get_all_rows.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) { 
				if(v.payment_term==pt){
					$("#cboPaymentTerm").append("<option value='" + v.payment_term + "' data-id='" + v.id + "' selected>" + v.payment_term + "</option>");
				}else{
					$("#cboPaymentTerm").append("<option value='" + v.payment_term + "' data-id='" + v.id + "'>" + v.payment_term + "</option>");
				}
			});			
		});
	}

	function getPaymentPercent(pp){
		$("#cboPaymentPercent").find("option").remove();
		$("#cboPaymentPercent").append("<option value= '' data-id = ''></option>");
		$.ajax({
			url: APP_URL + "api/payment_config/payment_percent/get_all_rows.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				if(v.payment_percent==pp){
					$("#cboPaymentPercent").append("<option value='" + v.payment_percent + "' data-id='" + v.id + "' selected>" + v.payment_percent + "</option>");
				}else{
					$("#cboPaymentPercent").append("<option value='" + v.payment_percent + "' data-id='" + v.id + "'>" + v.payment_percent + "</option>");
				}
			});			
		});
	}

	function getPromotion(){
		var code = $("#txtPromotionCode").val();
		var date = $("#txtDatePicker").val();
		if(code!=""){
			$.ajax({
				url: APP_URL + "api/payment_config/promotion/get_one_promotion.php",
				type: "POST",
				data: JSON.stringify({ code: code, date: date })
			}).done(function(data) {
				$("#txtPromotionDiscount").val(data.discount);
				calculate();
			});
		}else{
			$("#txtPromotionDiscount").val(0);
			calculate();
		}
	}

	function getBrokerModal(){
		$("#myModalBroker").modal('show');
	}

	function getAllBroker(){
		table = $('#myTableBroker').DataTable({ 
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"order": [[ 0, "asc" ]],
			'columnDefs': [	
				{
					'targets': [1, 2],
					'searchable': false
				},
                { 
                    'targets': [1], 
                    'className': "displayNone" 
                }
			],
			"ajax": APP_URL + "api/sales/broker/get_all_rows.php"
		});		
	}

	$('#myTableBroker').on('click', 'tbody tr', function(e){ 
		$("#txtBrokerID").val($(this).find("td").eq(1).text());
		$("#txtBrokerRegistrationNo").val($(this).find("td").eq(2).text());
		$("#txtBrokerName").val($(this).find("td").eq(3).text());
		$("#myModalBroker").modal('hide');
	});

	function getAllTownship(){
		$("#myModalTownshipList").modal('show');
		fillTownship();
	}

	function fillTownship(){
		table = $('#myTable1').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"ajax": APP_URL + "api/township/get_all_rows.php"
		});	
	}

	$('#myTable1').on('click', 'tbody td', function(e){
		$("#myTable1 tbody tr").css("color","");
		$("#myTable1 tbody tr").css("background-color","");
		$(this).parent().css("background-color", "#e3ecf5");
		$(this).parent().css("color", "rgb(34, 126, 140)");

		$("#txtRTADTownship").val($(this).parent().find("td").eq(2).text());
		$("#myModalTownshipList").modal('hide');
	});

	function changeBuyer(){
		if($("#chkSameAsBuyer").parent().hasClass("off")){
			$("#txtRTADName").attr("disabled", false);
			$("#cboRTADCode").attr("disabled", false);
			$("#cboRTADTownshipCode").attr("disabled", false);
			$("#cboRTADNRCType").attr("disabled", false);
			$("#txtRTADNRCNo").attr("disabled", false);
			$("#txtRTADMobileNo").attr("disabled", false);
			$("#btnTownship").attr("disabled", false);

			$("#txtRTADName").val("");
			$("#cboRTADCode").val("");
			$("#cboRTADTownshipCode").val("");
			$("#cboRTADNRCType").val("");
			$("#txtRTADNRCNo").val("");
			$("#txtRTADMobileNo").val(""); 
			$("#cboRTADTownshipCode").find("option").remove();
		}else{
			$("#txtRTADName").attr("disabled", true);
			$("#cboRTADCode").attr("disabled", true);
			$("#cboRTADTownshipCode").attr("disabled", true);
			$("#cboRTADNRCType").attr("disabled", true);
			$("#txtRTADNRCNo").attr("disabled", true);
			$("#txtRTADMobileNo").attr("disabled", true);
			$("#btnTownship").attr("disabled", true);

			$("#txtRTADName").val($("#txtCustomerName").val());
			$("#txtRTADMobileNo").val($("#txtMobileNo").val());
			$("#txtRTADTownship").val($("#txtCustomerTownship").val());

			$("#cboRTADCode").val($("#cboCode").val());
			$("#cboRTADTownshipCode").append("<option value= '" + (($("#cboTownshipCode").val()==null)?"":$("#cboTownshipCode").val()) + "' selected>" + (($("#cboTownshipCode").val()==null)?"":$("#cboTownshipCode").val()) + "</option>");
			$("#cboRTADNRCType").val($("#cboCustomerNRCType").val());
			$("#txtRTADNRCNo").val($("#txtCustomerNRCNo").val());
		}
	} 

    function getAllBMYGEI(){
    	modelNames = [];
    	modelYears = [];
		grades = [];
		exteriorColors = [];
		interiorColors = [];
		prices = [];
		var vehicle_status = $("input[name='optStatus']:checked").val();

		$("#cboBrand").find("option").remove();
		$("#cboBrand").append("<option value='' data-id=''></option>");
		$.ajax({
			type: "POST",
			url: APP_URL + "api/supply_chain/car_list/get_all_bmygei.php",
			data: JSON.stringify({ vehicle_status: vehicle_status })
		}).done(function(data) {
			$.each(data.brands, function(i, v) {
				$("#cboBrand").append("<option value='" + v.brand + "' data-id='" + v.brand.charAt(0).toUpperCase() + "'>" + v.brand + "</option>");
			});
			modelNames = data.modelNames;
			modelYears = data.modelYears;
			grades = data.grades;
			exteriorColors = data.exteriorColors;
			interiorColors = data.interiorColors;
			prices = data.prices;
			changeModelName();
		});
    }

    function changeModelName(){
		$("#cboModelName").find("option").remove();
		var brand = $("#cboBrand").val();
		console.log(brand);
		$.each(modelNames.filter(word => word.brand==brand), function(i, v) {
			$("#cboModelName").append("<option value='" + v.model_name + "'>" + v.model_name + "</option>");
		});
		changeModelYear();
	}

    function changeModelYear(){
		$("#cboModelYear").find("option").remove();
		var brand = $("#cboBrand").val();
		var model_name = $("#cboModelName").val();
		$.each(modelYears.filter(word => word.brand==brand && word.model_name==model_name), function(i, v) {
			$("#cboModelYear").append("<option value='" + v.model_year + "'>" + v.model_year + "</option>");
		});
		changeGrade();
	}

	function changeGrade(){
		$("#cboGrade").find("option").remove();
		var brand = $("#cboBrand").val();
		var model_name = $("#cboModelName").val();
		var model_year = $("#cboModelYear").val();
		$.each(grades.filter(word => word.brand==brand && word.model_name==model_name && word.model_year==model_year), function(i, v) {
			$("#cboGrade").append("<option value='" + v.grade + "'>" + v.grade + "</option>");
		});
		changeExteriorColor();
	}

	function changeExteriorColor(){
		$("#cboExteriorColor").find("option").remove();
		var brand = $("#cboBrand").val();
		var model_name = $("#cboModelName").val();
		var model_year = $("#cboModelYear").val();
		var grade = $("#cboGrade").val();
		$.each(exteriorColors.filter(word => word.brand==brand && word.model_name==model_name && word.model_year==model_year && word.grade==grade), function(i, v) {
			$("#cboExteriorColor").append("<option value='" + v.exterior_color + "'>" + v.exterior_color + "</option>");
		});
		changeInteriorColor();
	}

	function changeInteriorColor(){
		$("#cboInteriorColor").find("option").remove();
		var brand = $("#cboBrand").val();
		var model_name = $("#cboModelName").val();
		var model_year = $("#cboModelYear").val();
		var grade = $("#cboGrade").val();
		var exterior_color = $("#cboExteriorColor").val();
		$.each(interiorColors.filter(word => word.brand==brand && word.model_name==model_name && word.model_year==model_year && word.grade==grade && word.exterior_color==exterior_color), function(i, v) {
			$("#cboInteriorColor").append("<option value='" + v.interior_color + "'>" + v.interior_color + "</option>");
		});
		changePrice();
	}

	function changePrice(){
		$("#txtVehiclePrice").val(0);
		$("#txtCommercialTax").val(0);
		$("#txtRetailPrice").val(0);
		$("#txtRTADTax").val(0);
		$("#txtTotalPrice").val(0);
		$("#txtSellingPrice").val(0);

		var brand = $("#cboBrand").val();
		var model_name = $("#cboModelName").val();
		var model_year = $("#cboModelYear").val();
		var grade = $("#cboGrade").val();
		var exterior_color = $("#cboExteriorColor").val();
		var interior_color = $("#cboInteriorColor").val();

		var price_detail = prices.filter(word => word.brand==brand && word.model_name==model_name && word.model_year==model_year && word.grade==grade && word.exterior_color==exterior_color && word.interior_color==interior_color)[0];
		if(price_detail!=undefined){
			$("#txtVehiclePrice").val(price_detail.vehicle_price);
			$("#txtRTADTax").val(price_detail.rtad_tax);
			calculate();
		}
		changeCarStatus();
	} 

	function changeCarStatus(){
		var status = $("input[name='optStatus']:checked").val();
		if(status=="Production"){
			$("#cboVinNo").val("");
			$("#txtEngineNo").val("");
		}

		if(status!="Production" && $("#cboBrand").val()) getAllVinNoByBMYGEI();
	}

    function getAllVinNoByBMYGEI(){
    	var status = $("input[name='optStatus']:checked").val();
		var brand = $("#cboBrand").val();
		var model = $("#cboModelName").val();
		var model_year = $("#cboModelYear").val();
		var grade = $("#cboGrade").val();
		var exterior_color = ($("#cboExteriorColor").val())?$("#cboExteriorColor").val():"";
		var interior_color = ($("#cboInteriorColor").val())?$("#cboInteriorColor").val():"";

     	$("#cboVinNo").find("option").remove();
		$("#cboVinNo").append("<option value='' data-engine-no=''></option>");

		if(status!="Production"){
			$.ajax({
				url: APP_URL + "api/supply_chain/car_stock/get_all_vin_no_by_bmygei.php",
				type: "POST",
				data: JSON.stringify({ status: status, brand: brand, model: model, model_year: model_year, grade: grade, exterior_color: exterior_color, interior_color: interior_color })
			}).done(function(data) {
				if(data.interior_photo){
					$("#InteriorImg").attr("src", APP_URL + "upload/server/php/files/interior/" + data.car_list_id + "/" +  data.interior_photo);
				}else{
					$("#InteriorImg").attr("src", APP_URL + "img/1.jpg");
				}
				if(data.exterior_photo){
					$("#ExteriorImg").attr("src", APP_URL + "upload/server/php/files/exterior/" + data.car_list_id + "/" +  data.exterior_photo);
				}else{
					$("#ExteriorImg").attr("src", APP_URL + "img/2.jpg");
				}

				$.each(data.car_list, function(i, v) {	
					$("#cboVinNo").append("<option value= '" + v.vin_no + "' data-engine-no='" + v.engine_no + "'>" + v.vin_no + "</option>");
				});
				$("#txtEngineNo").val("");  
			});
		}
    } 

	function calculate(){
		var vehicle_price = parseInt($("#txtVehiclePrice").val().replace(/,/g, ''));
		var commercial_tax = Math.round(vehicle_price * 0.05);
		var promotion_discount = parseInt($("#txtPromotionDiscount").val().replace(/,/g, ''));
		var rtad_tax = parseInt($("#txtRTADTax").val().replace(/,/g, ''));

		var retail_price = vehicle_price + commercial_tax;
		var total_price = vehicle_price + commercial_tax + rtad_tax;
		var selling_price = total_price - promotion_discount;

		$("#txtVehiclePrice").val(vehicle_price.toLocaleString());
		$("#txtCommercialTax").val(commercial_tax.toLocaleString());
		$("#txtRetailPrice").val(retail_price.toLocaleString());
		$("#txtTotalPrice").val(total_price.toLocaleString());
		$("#txtSellingPrice").val(selling_price.toLocaleString());
	} 

	function getOneOrder(){
		$.ajax({
			url: APP_URL + "api/sales/order/get_one_order.php",
			type: "POST",
			data: JSON.stringify({ oc_no: OCNO })
		}).done(function(data) {	
			APPROVAL_ORDER_NO = data.order_no;

			OLDBRAND = data.brand;
			OLDMODEL = data.model;
			OLDMODELYEAR = data.model_year;
			OLDGRADE = data.grade;
			OLDEXTERIORCOLOR = data.exterior_color;
			OLDINTERIORCOLOR = data.interior_color;
			OLDVINNO = data.vin_no;
			OLDENGINENO = data.engine_no;
			OLDVEHICLEPRICE = data.vehicle_price;
			OLDRTADTAX = data.rtad_tax;
			VEHICLE_STATUS = data.vehicle_status;

			$("#txtSalesCenter").text(data.sales_center);
			$("#txtOCNo").val(data.oc_no);
			$("#txtDatePicker").val(data.date);
			$("#datePicker").datepicker("setDate", data.date);
			$("#cboSalesType").val(data.sales_type);

            $("#txtStaffID").val(data.staff_id);

            // Broker Info
            if(parseInt(data.broker_id)>0){
            	$(".brokerInfoPanel").css("display", "");
				getAllBroker(); 
            }else{
            	$(".brokerInfoPanel").css("display", "none");
            }
			$("#txtBrokerID").val(data.broker_id);
			$("#txtBrokerRegistrationNo").val(data.b_registration_no);
			$("#txtBrokerName").val(data.broker_name);
			// Broker Info

			// Customer Info
			$("#txtCustomerRegistrationNo").val(data.c_registration_no);
			$("#txtCustomerID").val(data.customer_id);
			$("#txtCustomerName").val(data.customer_name);
			$("#txtMobileNo").val(data.c_mobile_no);
			$("#txtEmail").val(data.c_email);
			$("#txtCustomerTownship").val(data.c_township);

			if(data.c_nrc_no){
				if(data.c_nrc_no.includes("/") && data.c_nrc_no.includes("(") && data.c_nrc_no.includes(")")){
	                var nrc = data.c_nrc_no.split("/");
	                $("#cboCode").val(nrc[0]);
	                var tc = nrc[1].split("(");
	                getNRCCodeByCustomer(tc[0]);
	                var type = tc[1].split(")");
	                $("#cboCustomerNRCType").val("(" + type[0] + ")");
	                $("#txtCustomerNRCNo").val(type[1]);
				}
            }

			if(data.customer_type=="B2B"){
				$("#cboCustomerType").val(data.customer_type);
	   			$(".companyInfo").css("display", "");
	   			$("#txtCompanyName").val(data.company_name);
	   			$("#txtCompanyRegisterNo").val(data.company_register_no)
			}else{
	   		    $(".companyInfo").css("display", "none");
			}
			// Customer Info

			// RTAD Register Info
			if(data.same_as_buyer=="1"){
				$("#chkSameAsBuyer").parent().removeClass("off");
				$("#txtRTADName").attr("disabled", true);
				$("#cboRTADCode").attr("disabled", true);
				$("#cboRTADTownshipCode").attr("disabled", true);
				$("#cboRTADNRCType").attr("disabled", true);
				$("#txtRTADNRCNo").attr("disabled", true);
				$("#txtRTADMobileNo").attr("disabled", true);
				$("#btnTownship").attr("disabled", true);
			}else{
				$("#chkSameAsBuyer").parent().addClass("off");
				$("#txtRTADName").attr("disabled", false);
				$("#cboRTADCode").attr("disabled", false);
				$("#cboRTADTownshipCode").attr("disabled", false);
				$("#cboRTADNRCType").attr("disabled", false);
				$("#txtRTADNRCNo").attr("disabled", false);
				$("#txtRTADMobileNo").attr("disabled", false);
				$("#btnTownship").attr("disabled", false);		
			}

			$("#txtRTADName").val(data.rtad_name);
			$("#txtRTADMobileNo").val(data.rtad_mobile_no);
			$("#txtRTADTownship").val(data.rtad_township);

			if(data.rtad_nrc_no){
				if(data.rtad_nrc_no.includes("/") && data.rtad_nrc_no.includes("(") && data.rtad_nrc_no.includes(")")){
	                var rtad_nrc = data.rtad_nrc_no.split("/");
	                $("#cboRTADCode").val(rtad_nrc[0]);
	                var rtad_tc = rtad_nrc[1].split("(");
	                getNRCCodeByRTAD(rtad_tc[0]);
	                var rtad_type = rtad_tc[1].split(")");
	                $("#cboRTADNRCType").val("(" + rtad_type[0] + ")");
	                $("#txtRTADNRCNo").val(rtad_type[1]);
	            }
            }
			
            // RTAD Register Info

            // Vehicle Info
			$("input[name='optStatus']:checked").parent().removeClass("active");
			$("#opt" + data.vehicle_status).prop("checked", true);
			$("#opt" + data.vehicle_status).parent().addClass("active");
			$(".VENo").css("display", "none");
			if(data.vehicle_status!="Production") $(".VENo").css("display", "");

			$("#cboBrand").append("<option value= '" + data.brand + "' data-id='" + data.brand.charAt(0).toUpperCase() + "' selected>" + data.brand + "</option>");
			$("#cboModelName").append("<option value= '" + data.model + "' selected>" + data.model + "</option>");
			$("#cboModelYear").append("<option value= '" + data.model_year + "' selected>" + data.model_year + "</option>");
			$("#cboGrade").append("<option value= '" + data.grade + "' selected>" + data.grade + "</option>");
			$("#cboExteriorColor").append("<option value= '" + data.exterior_color + "' selected>" + data.exterior_color + "</option>");
			$("#cboInteriorColor").append("<option value= '" + data.interior_color + "' selected>" + data.interior_color + "</option>");

			$("#cboVinNo").append("<option value= '" + data.vin_no + "' data-engine-no='" + data.engine_no + "' selected>" + data.vin_no + "</option>");
			$("#txtEngineNo").val(data.engine_no);

			if(data.interior_photo){
				$("#InteriorImg").attr("src", APP_URL + "upload/server/php/files/interior/" + data.car_list_id + "/" +  data.interior_photo);
			}
			if(data.exterior_photo){
				$("#ExteriorImg").attr("src", APP_URL + "upload/server/php/files/exterior/" + data.car_list_id + "/" +  data.exterior_photo);
			}
			// Vehicle Info

			$("#cboPaymentType").val(data.payment_type);
			if(data.payment_type=="HP"){
				$(".connectHP").css("display", "");
				$("#cboBank").val(data.bank);
				getPaymentTerm(data.payment_term);
				getPaymentPercent(data.payment_percent);
			}else if(data.payment_type=="InHouse"){
				$(".connectHP").css("display", "none");
				$(".connectInHouse").css("display", "");
				getPaymentTerm(data.payment_term);
				getPaymentPercent(data.payment_percent);
			}

			$("#txtPromotionCode").val(data.promotion_code);
			$("#txtPromotionDiscount").val(data.promotion_discount);
			$("#txtVehiclePrice").val(data.vehicle_price);
			$("#txtRTADTax").val(data.rtad_tax);
			calculate();

			$("#txtDeposit").val(data.deposit);		

			if(data.permission_edit==0){
				setDisabled();
			}

			if(data.btn_approve==0){
				$(".btnAction").css("display", "none");
				$(".btnAction").attr("disabled", true);
			}else{
				$(".btnAction").css("display", "");
				$(".btnAction").attr("disabled", false);
			}	

			//wppp
			if(data.order_no==1){
				$("#btnReject").css("display", "none");
			}else{
				$(".btnReject").css("display", "");
			}
			//wppp
		});
	}

	function setDisabled(){
		$("input").attr("disabled", true);
		$("select").attr("disabled", true);
		$("button").attr("disabled", true);
		$(".close").attr("disabled", false); 
	} 

	function validateAndUpdate(obj){ 
		var btnStatus = $(obj).text();

		var nrc_no = "";
		var nrc_no_scode = (($("#cboCode").val())?($("#cboCode").val()):"");
		var nrc_no_tcode = (($("#cboTownshipCode").val())?($("#cboTownshipCode").val()):"");
		var nrc_no_type = (($("#cboCustomerNRCType").val())?($("#cboCustomerNRCType").val()):"");
		var nrc_no_seq = $("#txtCustomerNRCNo").val();
		if(nrc_no_scode!="" && nrc_no_tcode!="" && nrc_no_type!="" && nrc_no_seq!=""){
			nrc_no = nrc_no_scode + "/" + nrc_no_tcode + nrc_no_type + nrc_no_seq;
		}

		var customer_type = $("#cboCustomerType").val();
		var company_name = (customer_type=="B2B")?$("#txtCompanyName").val():"";
		var company_register_no = (customer_type=="B2B")?$("#txtCompanyRegisterNo").val():"";

		var same_as_buyer = ($("#chkSameAsBuyer").parent().hasClass("off"))?0:1;
		var rtad_name = $("#txtRTADName").val();

		var rtad_nrc_no = "";
		var rtad_nrc_no_scode = (($("#cboRTADCode").val())?($("#cboRTADCode").val()):"");
		var rtad_nrc_no_tcode = (($("#cboRTADTownshipCode").val())?($("#cboRTADTownshipCode").val()):"");
		var rtad_nrc_no_type = (($("#cboRTADNRCType").val())?($("#cboRTADNRCType").val()):"");
		var rtad_nrc_no_seq = $("#txtRTADNRCNo").val();
		if(rtad_nrc_no_scode!="" && rtad_nrc_no_tcode!="" && rtad_nrc_no_type!="" && rtad_nrc_no_seq!=""){
			rtad_nrc_no = rtad_nrc_no_scode + "/" + rtad_nrc_no_tcode + rtad_nrc_no_type + rtad_nrc_no_seq;
		}

		var rtad_mobile_no = $("#txtRTADMobileNo").val();
		var rtad_township = $("#txtRTADTownship").val();

		var change = ($("#chkChangeToggle").parent().hasClass("off"))?0:1;
		var vehicle_status = $("input[name='optStatus']:checked").val();
		var brand = $("#cboBrand").val();
		var model = $("#cboModelName").val();
		var vin_no = $("#cboVinNo").val();
		var engine_no = $("#txtEngineNo").val();
		var grade = $("#cboGrade").val();
		var model_year = $("#cboModelYear").val();
		var exterior_color = $("#cboExteriorColor").val();
		var interior_color = $("#cboInteriorColor").val();

		var date = $("#txtDatePicker").val(); 
		var broker_id = $("#txtBrokerID").val();
		var broker_name = $("#txtBrokerName").val();

		var staff_id = $("#txtStaffID").val();

		var sales_center = $("#txtSalesCenter").text();
		var sales_type = $("#cboSalesType").val();

		var vehicle_price = parseInt($("#txtVehiclePrice").val().replace(/,/g, ''));
		var commercial_tax = parseInt($("#txtCommercialTax").val().replace(/,/g, ''));
		var rtad_tax = parseInt($("#txtRTADTax").val().replace(/,/g, ''));
		var promotion_discount = parseInt($("#txtPromotionDiscount").val().replace(/,/g, ''));
		var promotion_code = (promotion_discount==0)?"":$("#txtPromotionCode").val();
		var selling_price = parseInt($("#txtSellingPrice").val().replace(/,/g, ''));

		var payment_type = $("#cboPaymentType").val();
		var bank = $("#cboBank").val();
		var payment_percent = (payment_type!="Cash")?$("#cboPaymentPercent").val():"";	
		var payment_term = (payment_type!="Cash")?$("#cboPaymentTerm").val():"";
		var deposit = parseInt($("#txtDeposit").val().replace(/,/g, '')); 

		var reject_remark = $("#txtRejectRemark").val();

		

		if(nrc_no==""){
			bootbox.alert("Please choose nrc no.");
			$("#btnOrder").prop("disabled", false);
			return false;
		}

		if(rtad_nrc_no==""){
			bootbox.alert("Please choose rtad nrc no.");
			$("#btnOrder").prop("disabled", false);
			return false;
		}

		if(rtad_name==""){
			bootbox.alert("Please fill RTAD Name.");
			$(obj).prop("disabled", false);
			return false;
		}

		if(vehicle_price==0){
			bootbox.alert("Please fill vehicle price.");
			$(obj).prop("disabled", false);
			return false;
		}

		if(sales_center==""){
			bootbox.alert("Please choose sales center.");
			$(obj).prop("disabled", false);
			return false;
		}

		if(payment_type=="HP" && bank==""){
			bootbox.alert("Please choose bank.");
			$(obj).prop("disabled", false);
			return false;
		}

		if(payment_type!="Cash" && payment_percent==""){
			bootbox.alert("Please choose payment percent.");
			$(obj).prop("disabled", false);
			return false;
		}

		if(payment_type!="Cash" && payment_term==""){
			bootbox.alert("Please choose payment term.");
			$(obj).prop("disabled", false);
			return false;
		}

		if(vehicle_status!="Production" && vin_no==""){
			bootbox.alert("Please choose car.");
			$(obj).prop("disabled", false);
			return false;
		}

		$.ajax({
			url: APP_URL + "api/sales/order/update.php",
			type: "POST",
			data: JSON.stringify({ oc_no: OCNO, date: date, customer_id: $("#txtCustomerID").val(), broker_id: broker_id, broker_name: broker_name, change: change, vehicle_status: vehicle_status, brand: brand, model: model, vin_no: vin_no, engine_no: engine_no, grade: grade, model_year: model_year, exterior_color: exterior_color, interior_color: interior_color, sales_center: sales_center, sales_type: sales_type, vehicle_price: vehicle_price, commercial_tax: commercial_tax, rtad_tax: rtad_tax, promotion_code: promotion_code, promotion_discount: promotion_discount, selling_price: selling_price, payment_type: payment_type, bank: bank, payment_percent: payment_percent, payment_term: payment_term, same_as_buyer: same_as_buyer, rtad_name: rtad_name, rtad_nrc_no: rtad_nrc_no, rtad_mobile_no: rtad_mobile_no, rtad_township: rtad_township, nrc_no: nrc_no, customer_type: customer_type, company_name: company_name, company_register_no: company_register_no, deposit: deposit, staff_id: staff_id, btn_status: btnStatus, reject_remark: reject_remark, order_no: APPROVAL_ORDER_NO })
		}).done(function(data) {
			if(data.message=="updated"){
				document.location = APP_URL + "sales/order_processing_list.php";
			}else if(data.message=="session expire"){
				bootbox.alert("Session Expire! Please refresh the browser and login again.");
			}else{
				bootbox.alert("Error on server side.");
			}
		});
	} 

	function btozero(obj){
		if($(obj).val() == "" || $(obj).val() == "0")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	} 

	function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
        $(obj).val(parseInt(amount).toLocaleString());
    }
</script>
