<?php include '../header.php'; ?>
<?php
    $oc_no = "";
    if(isset($_GET['oc_no'])){
        if(!empty($_GET['oc_no'])){
            $oc_no = $_GET['oc_no'];
        }
    }
?>
<style>
    .card{
        margin-bottom: 10px !important;
    }
    .card-header{
        padding: 8px 2px 8px 15px;
    }
    .card-body{
        padding: 15px 20px 5px 20px;
    }
    .nav-tabs{
        display: inline-flex;
    }
    .form-group{
        margin-bottom: 5px !important;
    }
    .form-control{
        border: 1px solid #d4d6d8ba !important;
    }
    .form-control:disabled, .form-control[readonly]{
        background-color: #e6e8ea9e !important;
    }
    input, textarea{
        font-size: 14px !important;
    }

    .checkbox-inline .toggle{
        margin-left: 0px !important;
        width: 110px !important;
    }
    .toggle-on, .toggle-off{
        line-height: 19px !important;
    }
    .breadcrumb{
        background: #fff;
    }
    .breadcrumb.wizard {
        margin: 0px !important;
        padding: 0px; 
        list-style: none;
        overflow: hidden;
        margin-top: 20px;
        font-size: 14px;
        height: 50px;
    }
    .breadcrumb.wizard>li+li:before {
        padding: 0;
    }
    .breadcrumb.wizard li {
        float: left;
        background: #eee;
        height: 50px;
    } 
    .breadcrumb.wizard li.current a {
        color: #fff !important; 
        background: brown;
        background: hsl(203.9, 64.2%, 48.2%) !important;
    }
    .breadcrumb.wizard li.completed a {
        color: #fff; 
        background: brown;
        background: hsl(204, 65.6%, 76.1%);
    } 
    .breadcrumb.wizard li.current a:after {
        border-left: 30px solid hsl(203.9, 64.2%, 48.2%) !important;
    }
    .breadcrumb.wizard li.completed a:after {
        border-left: 30px solid hsl(204, 65.6%, 76.1%);
    } 
    .breadcrumb.wizard li a {
        height: 50px;
        line-height: 28px;
        color: #000;
        text-decoration: none;
        padding: 10px 0 10px 45px;
        position: relative;
        display: block;
        float: left;
    }
    .breadcrumb.wizard li a:after {
        content: " ";
        display: block;
        width: 0;
        height: 0;
        border-top: 50px solid transparent;
        border-bottom: 50px solid transparent;
        border-left: 30px solid #eee;
        position: absolute;
        top: 50%;
        margin-top: -50px;
        left: 100%;
        z-index: 2;
    }
    .breadcrumb.wizard li a:before {
        content: " ";
        display: block;
        width: 0;
        height: 0;
        border-top: 50px solid transparent;
        border-bottom: 50px solid transparent;
        border-left: 30px solid white;
        position: absolute;
        top: 50%;
        margin-top: -50px;
        margin-left: 1px;
        left: 100%;
        z-index: 1;
    }
    .breadcrumb.wizard li:first-child a {
        padding-left: 15px;
    } 
    .custom-disabled{
        color: #9091916b !important;
        cursor: no-drop !important;
    }
    .branch{
        padding-top: 35px;
    }
    .box-shadow{
        box-shadow: rgba(0, 0, 0, 0.25) 0px 0.0625em 0.0625em, rgba(0, 0, 0, 0.25) 0px 0.125em 0.5em, rgba(255, 255, 255, 0.1) 0px 0px 0px 1px inset;
    }
    #progress{
        padding-right: 47px;
    }
    .dcl-filename{
        height: 35px;
        overflow: auto;
        font-size: 13px;
    }
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
    <section class="content-header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                </div>
            </div>
        </div>
    </section>
    <section class="content"> 
    	<div class="container-fluid">
    		<div class="row">
                <div class="col-md-12" id="SummaryPanel">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title" id="txtProcessing"></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">OC No.:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtOCNo" disabled value="<?=$oc_no?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtSalesCenter" disabled>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card card-outline card-outline-tabs collapsed-card">
                        <div class="card-header p-0 border-bottom-0">
                            <ul class="nav nav-tabs" id="custom-tabs-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="custom-tabs-customer-tab" data-toggle="pill" href="#custom-tabs-customer" role="tab" aria-controls="custom-tabs-customer" aria-selected="true">Customer Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-vehicle-tab" data-toggle="pill" href="#custom-tabs-vehicle" role="tab" aria-controls="custom-tabs-vehicle" aria-selected="false">Vehicle Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-payment-tab" data-toggle="pill" href="#custom-tabs-payment" role="tab" aria-controls="custom-tabs-payment" aria-selected="false">Payment Info</a>
                                </li>
                            </ul>
                            <div class="card-tools" style="padding-top: 10px;">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-tabContent">
                                <div class="tab-pane fade active show" id="custom-tabs-customer" role="tabpanel" aria-labelledby="custom-tabs-customer-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerName" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerNRCNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerMobileNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerTownship" disabled>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-vehicle" role="tabpanel" aria-labelledby="custom-tabs-vehicle-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Vin No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtVinNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Engine No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtEngineNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Particular:</label>
                                                <div class="col-md-8">
                                                    <textarea class="form-control" id="txtParticular" rows="4" style="height: 100px;" disabled></textarea>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-payment" role="tabpanel" aria-labelledby="custom-tabs-payment-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPayment" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment (%):</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPaymentPercent" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Deposit Amount:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtDeposit" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Remaining Balance:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtRemainingBalance" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card card-outline">
                        <div class="card-header" style="padding: 0px;"> 
                            <ul class="breadcrumb wizard myStepper">
                                <li class="completed" id="DocumentCollect"><a href="javascript:void(0);">Document Collect</a></li>
                                <li id="IncomeTax"><a href="javascript:void(0);">Income Tax</a></li>
                            </ul>
                        </div>

                        <div class="card-body branch" data-id="DocumentCollect">
                            <div class="col-md-12" id="myDCLFile">
                                <form role="form" id="frmDCLEntry">
                                    <div class="card-body" style="background-color: #fff;">
                                        <p style="font-size:16px; text-align:center; margin:10px 0px;">
                                        Please upload documents only in 'pdf' format.
                                        </p>
                                        <h3 style="text-align: center; font-size:23px;">
                                        Document Collect
                                        </h3><br>
                                        <div class="row">
                                            <div class="col-md-10" id="mainDCLPanel"></div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="card-body branch" data-id="IncomeTax" style="display:none;">
                            <div class="row">
                                <div class="col-md-6"> 
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Income Tax (3%): </label>
                                        <div class="col-md-8"> 
                                            <input type="text" class="form-control float-right it-info" id="txtIncomeTax" onkeypress="return isNumber(event);" onkeyup="btozero(this); AddComma(this);" value="0" style="text-align: right;">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right; padding-top: 6px;">
                                            Done
                                            <div class="icheck-success d-inline" style="padding-left: 10px;">
                                                <input type="checkbox" id="chkIncomeTaxDone" class="it-info">
                                                <label for="chkIncomeTaxDone"></label>
                                            </div>
                                        </label>
                                        <div class="col-md-8">
                                            <div class="checkbox" style="text-align: left;">
                                                <label class="checkbox-inline pToggle">
                                                    <input type="checkbox" data-toggle="toggle" id="chkIncomeTaxClaim" data-on="Claim" data-off="Claim" data-onstyle="success" class="ssToggle" disabled class="it-info">
                                                </label>
                                                <label class="checkbox-inline pToggle" style="padding-left: 20px;">
                                                    <input type="checkbox" data-toggle="toggle" id="chkIncomeTaxPayment" data-on="Payment" data-off="Payment" data-onstyle="success" class="ssToggle" disabled class="it-info">
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6"> 
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Submission Date:</label>
                                        <div class="col-md-8">  
                                            <div class="input-group input-append date" id="datePickerITSubmission" data-date="2022-09-01" data-date-format="yyyy-mm-dd">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell; height: 31px !important;">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input type="text" class="form-control float-right it-info" id="txtDatePickerITSubmission" value="1982-06-15" readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Received Date:</label>
                                        <div class="col-md-8">  
                                            <div class="input-group input-append date" id="datePickerITReceived" data-date="2022-09-01" data-date-format="yyyy-mm-dd">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell; height: 31px !important;">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input type="text" class="form-control float-right it-info" id="txtDatePickerITReceived" value="1982-06-15" readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-4"></div>
                                        <div class="col-md-8" style="text-align:right;"> 
                                            <button type="button" class="btn btn-info file-upload" id="btnITFileUpload" onclick="goToDocumentCollect();">Income Tax File</button>
                                            <button type="button" class="btn btn-success" onclick="addIncomeTax()" id="btnITSubmit">Submit</button>
                                        </div> 
                                    </div> 
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>

            </div>
    	</div>
    </section> 
</div>
<?php include '../footer.php'; ?>
<script>
    var oc_no = "<?= $oc_no ?>";
    var statusArr = ["Income Tax"];
    var arrDCList = ["NRC", "Census", "Income Tax"];

    var d = new Date();
    var mm = (d.getMonth("MM")+1);
    var dd = d.getDate();
    var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$(function(){
        $("body").addClass("sidebar-collapse");  
        checkStatus();

        // Income Tax
        $('#datePickerITSubmission').attr("data-date", customDate);
        $("#txtDatePickerITSubmission").val(customDate);
        $('#datePickerITSubmission').datepicker();

        $('#datePickerITReceived').attr("data-date", customDate);
        $("#txtDatePickerITReceived").val(customDate);
        $('#datePickerITReceived').datepicker();
        // Income Tax
    });

    $(document).on('click', ".myStepper .clickable", function(){
        $(".myStepper li").removeClass("current");
        $(this).addClass("current");
        $(".branch").css("display", "none");
        $("[data-id='" + $(this).attr("id") + "']").css("display", "");
        if($(this).find("a").text()=="Purchase Permit") checkPurchasePermit();
    });

    // Check Status
    function checkStatus(){
        $(".myStepper li").removeClass("current");
        $(".myStepper li:not(:first-child)").removeClass("completed");
        $(".myStepper li").removeClass("clickable");
        $(".myStepper li").addClass("clickable");
        $(".myStepper a").removeClass("custom-disabled");
        $(".branch").css("display", "none");

        $.ajax({
            url: APP_URL + "api/sales/sales/check_status.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {  
            var status = data.status.replace(/\s+/g, "");
            var processing = data.processing.replace(/\s+/g, "");

            if(processing=="IncomeTax"){
                // Processing
                $("#" + processing).removeClass("completed");
                $("#" + processing).addClass("current");
                $("[data-id='" + processing + "']").css("display", "");
                // Processing

                // Disabled 
                var completedStart = true;
                var disabledStart = false;
                $.each(statusArr, function(i, v){
                    var val = v.replace(/\s+/g, "");
                    if(val == status){
                        $("#" + val).addClass("completed");
                        completedStart = false;
                    }else if(completedStart){
                        $("#" + val).addClass("completed");
                    }

                    if(disabledStart){
                        $("#" + val).removeClass("clickable");
                        $("#" + val + " a").addClass("custom-disabled");
                    }
                    if(val == processing){
                        disabledStart = true;
                    }
                });
                // Disabled
            }else{
                $(".myStepper li:first-child").addClass("current");
                $("[data-id='DocumentCollect']").css("display", "");
            }
            getSalesDetail();
            appendDCList();
        });
    }
    // Check Status

    function getSalesDetail(){
        $.ajax({
            url: APP_URL + "api/sales/sales/get_sales_detail.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {    
            $("#txtProcessing").text(data.processing);
            $("#txtSalesCenter").val(data.sales_center);

            $("#txtCustomerName").val(data.c_name);
            $("#txtCustomerNRCNo").val(data.c_nrc_no);
            $("#txtCustomerMobileNo").val(data.c_mobile_no);
            $("#txtCustomerTownship").val(data.c_township);

            $("#txtVinNo").val(data.vin_no);
            $("#txtEngineNo").val(data.engine_no);
            $("#txtParticular").val(data.particular);

            $("#txtTotalPayment").val(data.total_payment);
            $("#txtTotalPaymentPercent").val(data.payment_percent);
            $("#txtDeposit").val(data.deposit);
            $("#txtRemainingBalance").val(data.remaining_balance);

            // Income Tax
            $("#txtIncomeTax").val(data.income_tax_amount);
            if(data.it_submission_date){
                $("#txtDatePickerITSubmission").val(data.it_submission_date);
            }
            if(data.it_received_date){
                $("#txtDatePickerITReceived").val(data.it_received_date);
            }

            if(data.it_done==1){
                $("#chkIncomeTaxDone").prop("checked", true);
                $("#chkIncomeTaxClaim").attr("disabled", true);
                $("#chkIncomeTaxPayment").attr("disabled", true);
                $("#btnITSubmit").css("display", "none");
                $(".it-info").attr("disabled", true);
            }else{
                $("#chkIncomeTaxDone").prop("checked", false);
            }

            if(data.income_tax){
                $("#chkIncomeTaxClaim").parent().addClass("off");
                $("#chkIncomeTaxPayment").parent().addClass("off");
                $("#chkIncomeTax" + data.income_tax).parent().removeClass("off");
            }
            // Income Tax 
        });
    } 

    // Document Collect
    function appendDCList(){
        $("#mainDCLPanel").empty();
        $.each(arrDCList, function(i, v){
            var label = v + ": ";
            var filenameID = v.replace(/\s+/g, "");
            $("#mainDCLPanel").append('<div class="form-group row dc-group"><label class="col-md-3 col-form-label" style="text-align: right;">' + label + '</label><div class="col-md-9"><div class="input-group input-group"><div class="form-control dcl-filename" id="txtDCL' + filenameID + '" style="height: 35px; overflow: auto;"></div><span class="input-group-btn beforeUpload"><input type="file" accept="application/pdf" class="dclFile" id="fileDCL' + filenameID + '" name="fileDCL' + filenameID + '" hidden /><label class="btn btn-primary lblDCLButton dcl-btn" for="fileDCL' + filenameID + '" title="Upload" style="margin-bottom: 0px; cursor: pointer;"><i class="fa fa-upload"></i></label></span><input type="hidden"><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-danger dcl-btn" title="Remove"><i class="fa fa-trash"></i></button></span><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-success dcl-btn" title="Download"><i class="fa fa-download"></i></button></span><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-info dcl-btn" title="Preview"><i class="fa fa-file-pdf"></i></button></span></div></div></div>');
        });
        getOneDCL();
    }

    $(document).on('change', ".dclFile", function(){
        uploadDCLFile(this);
    });

    $(document).on('click', ".dcl-btn", function(){
        var btnName = $(this).attr("title");
        var fileURL = $(this).parent().parent().find("input[type='hidden']").val();
        var fileName = $(this).parent().parent().find(".dcl-filename").eq(0).text();

        if(btnName=="Remove"){
            deleteFile(this, fileName);
        }else if(btnName=="Download"){
            download_file(fileURL, fileName); //call function
        }else if(btnName=="Preview"){
            window.open(fileURL);
        }
    });

    function deleteFile(obj, fileName){
        var column_name = "";
        if($(obj).parent().parent().parent().parent().find("label").eq(0).text()!=""){
            column_name = "dc_" + $(obj).parent().parent().parent().parent().find("label").eq(0).text().replace(":", "").replace(".", "").trim().toLowerCase().replace(/\s+/g, "_");
        }

        $.ajax({
            url: APP_URL + "api/sales/pdf_upload/delete.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no, file_name: fileName, column_name: column_name })
        }).done(function(data) {
            if(data.message=="deleted"){
                $(obj).parent().parent().find(".dcl-filename").eq(0).text("");
                $(obj).parent().parent().find("input[type='hidden']").val("");

                $(obj).parent().parent().find(".beforeUpload").eq(0).css("display", "");
                $(obj).parent().parent().find(".afterUpload").eq(0).css("display", "none");
                $(obj).parent().parent().find(".afterUpload").eq(1).css("display", "none");
                $(obj).parent().parent().find(".afterUpload").eq(2).css("display", "none");
            }
        });
    }

    function download_file(fileURL, fileName) {
        // for non-IE
        if (!window.ActiveXObject) {
            var save = document.createElement('a');
            save.href = fileURL;
            save.target = '_blank';
            var filename = fileURL.substring(fileURL.lastIndexOf('/')+1);
            save.download = fileName || filename;
            if ( navigator.userAgent.toLowerCase().match(/(ipad|iphone|safari)/) && navigator.userAgent.search("Chrome") < 0) {
                document.location = save.href; 
                // window event not working here
            }else{
                var evt = new MouseEvent('click', {
                    'view': window,
                    'bubbles': true,
                    'cancelable': false
                });
                save.dispatchEvent(evt);
                (window.URL || window.webkitURL).revokeObjectURL(save.href);
            }   
        }

        // for IE < 11
        else if ( !! window.ActiveXObject && document.execCommand)     {
            var _window = window.open(fileURL, '_blank');
            _window.document.close();
            _window.document.execCommand('SaveAs', true, fileName || fileURL)
            _window.close();
        }
    }

    function uploadDCLFile(obj){
        var column_name = "";
        if($(obj).parent().parent().parent().parent().find("label").eq(0).text()!=""){
            column_name = "dc_" + $(obj).parent().parent().parent().parent().find("label").eq(0).text().replace(":", "").trim().toLowerCase().replace(/\s+/g, "_");
        }

        var orgName = $(obj).attr("name");
        var ofn = $(obj).parent().parent().find(".dcl-filename").eq(0).text();

        $(obj).attr("name", "file");
        var property = document.getElementById($(obj).attr("id")).files[0];
        var file_name = property.name;
        var file_extension = file_name.split(".").pop().toLowerCase();
        
        if(property.type!="application/pdf"){
            bootbox.alert("Invalid File");
        }else{
            var file_size = parseInt(property.size/1000000);//convert bytes to mb
            if(file_size>25){
                bootbox.alert("Exceed File Size.");
            }else{
                $(".dcl-btn").attr("disabled", true);
                $(".dclFile").attr("disabled", true);
                $(".dcl-btn").css("opacity", 0.4);
                $(obj).parent().find(".dcl-btn").eq(0).css("opacity", 1);

                var form_data = new FormData();
                form_data.append($(obj).attr("name"), property);

                $.ajax({
                    url: APP_URL + "api/sales/pdf_upload/upload.php?oc_no=" + oc_no + "&ofn=" + ofn + "&column_name=" + column_name,
                    type: "POST",
                    data: form_data,
                    contentType: false,
                    cache: false,
                    processData: false,
                    xhr: function() {
                        var xhr = $.ajaxSettings.xhr();
                        $(obj).parent().parent().parent().parent().append('<div class="col-md-3 tempProgress"></div><div class="col-md-9 tempProgress" id="progress"></div>');
                        xhr.upload.onprogress = function(e) {
                            var percent = Math.floor(e.loaded / e.total * 100);
                            $("#progress").html('<div class="progress progress-xs"><div class="progress-bar bg-primary progress-bar-striped" role="progressbar" aria-valuenow="' + percent + '" aria-valuemin="0" aria-valuemax="100" style="width: ' + percent + '%"><span class="sr-only">' + percent + '% Complete (success)</span></div></div>');
                        };
                        return xhr;
                    },
                    success:function(data){
                        $(obj).parent().parent().parent().parent().find(".tempProgress").remove();
                        $(obj).parent().parent().find(".dcl-filename").eq(0).text(data.file_name);
                        $(obj).attr("name", orgName);
                        $(obj).parent().parent().find("input[type='hidden']").val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.file_name);

                        $(".dcl-btn").attr("disabled", false);
                        $(".dclFile").attr("disabled", false);
                        $(".dcl-btn").css("opacity", 1);

                        $(obj).parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                        $(obj).parent().parent().find(".afterUpload").eq(0).css("display", "");
                        $(obj).parent().parent().find(".afterUpload").eq(1).css("display", "");
                        $(obj).parent().parent().find(".afterUpload").eq(2).css("display", "");
                    }
                });
            }
        }
    }

    function getOneDCL(){
        $.ajax({
            url: APP_URL + "api/sales/pdf_upload/get_one_row.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {
            if(data.dc_nrc!=""){
                $("#txtDCLNRC").text(data.dc_nrc);
                $("#fileDCLNRC").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_nrc);

                $("#fileDCLNRC").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLNRC").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLNRC").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLNRC").parent().parent().find(".afterUpload").eq(2).css("display", "");
            }

            if(data.dc_census!=""){
                $("#txtDCLCensus").text(data.dc_census);
                $("#fileDCLCensus").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_census);

                $("#fileDCLCensus").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLCensus").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLCensus").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLCensus").parent().parent().find(".afterUpload").eq(2).css("display", "");
            }

            if(data.dc_income_tax!=""){
                $("#txtDCLIncomeTax").text(data.dc_income_tax);
                $("#fileDCLIncomeTax").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_income_tax);

                $("#fileDCLIncomeTax").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLIncomeTax").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLIncomeTax").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLIncomeTax").parent().parent().find(".afterUpload").eq(2).css("display", "");
            }
        });
    }
    // Document Collect

    // Income Tax
    $("#chkIncomeTaxDone").change(function(){
        if($(this).prop("checked")){
            $(".ssToggle").prop("disabled", false);
        }else{
            $(".ssToggle").parent().removeClass('btn-success');
            $(".ssToggle").parent().addClass('btn-default');
            $(".ssToggle").parent().addClass('off');
            $(".ssToggle").prop("disabled", true);
        }
    });

    $(".ssToggle").change(function(){
        $(".ssToggle").parent().removeClass('btn-success');
        $(".ssToggle").parent().addClass('btn-default');
        $(".ssToggle").parent().addClass('off');

        $(this).parent().removeClass('btn-default');
        $(this).parent().addClass('btn-success');
        $(this).parent().removeClass("off");
    });

    function goToDocumentCollect(){
        $(".myStepper li").removeClass("current");
        $("#DocumentCollect").addClass("current");
        $(".branch").css("display", "none");
        $("[data-id='DocumentCollect']").css("display", "");

        $(".dcl-filename").removeClass('box-shadow');
        $('#txtDCLIncomeTax').addClass('box-shadow'); 
        setTimeout(function() {
            $('#txtDCLIncomeTax').removeClass('box-shadow');
        }, 1000)
        document.getElementById('txtDCLIncomeTax').scrollIntoView();
    }

    function addIncomeTax(){
        var it_submission_date = $("#txtDatePickerITSubmission").val();
        var it_received_date = $("#txtDatePickerITReceived").val();
        var tfIncomeTax = $("#chkIncomeTaxDone").prop("checked");
        var income_tax = "";
        if($("#chkIncomeTaxClaim").parent().hasClass("off")==false){
            income_tax = "Claim";
        }else if($("#chkIncomeTaxPayment").parent().hasClass("off")==false){
            income_tax = "Payment";
        }
        var income_tax_amount = parseInt($("#txtIncomeTax").val().replace(/,/g, ''));

        if(tfIncomeTax){
            if(income_tax==""){
                bootbox.alert("Please choose Claim or Payment.");
            }else{
                $("#btnITSubmit").attr("disabled", true);
                $.ajax({
                    url: APP_URL + "api/sales/sales/update_income_tax.php",
                    type: "POST",
                    data: JSON.stringify({ oc_no: oc_no, income_tax: income_tax, income_tax_amount: income_tax_amount, it_submission_date: it_submission_date, it_received_date: it_received_date })
                }).done(function(data){ 
                    $("#btnITSubmit").attr("disabled", false);
                    if(data.message=="updated"){
                        bootbox.alert("Successfully submitted.");
                        $("#btnITSubmit").css("display", "none");

                        checkStatus();
                        document.location = APP_URL + "sales/sales_list.php";
                    }else if(data.message=="session expire"){
                        bootbox.alert("Session Expire! Please refresh the browser and login again.");
                    }else{
                        bootbox.alert("Error on server side.");
                    }
                });
            }
        }else{
            bootbox.alert("Please choose Claim or Payment.");
        }
    }
    // Income Tax

    function btozero(obj){
        if($(obj).val() == "")$(obj).val(0);
    }

    function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if ( (charCode > 31 && charCode < 48) || charCode > 57) {
            return false;
        }
        return true;
    }

    function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
        $(obj).val(parseInt(amount).toLocaleString());
    }
</script>