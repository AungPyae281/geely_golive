<?php include 'config/_globle.php'; ?>
<?php include 'api/AUTh/check_user_session.php'; ?>
<?php include 'api/AUTh/check_authorize_route.php'; ?>
 
<!DOCTYPE html> 
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" type="image/x-icon" href="<?=$app_url;?>img/logo_sm.png" />
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Geely</title>

	<link rel="stylesheet" href="<?=$app_url;?>plugins/bootstrap/bootstrap-toggle.min.css"> 
	<link rel="stylesheet" href="<?=$app_url;?>plugins/fontawesome-free/css/all.min.css"> 
	<link rel="stylesheet" href="<?=$app_url;?>plugins/datepicker/bootstrap-datepicker.min.css">  	 
	<link rel="stylesheet" href="<?=$app_url;?>plugins/timepicker/bootstrap-timepicker.min.css">
	<link rel="stylesheet" href="<?=$app_url;?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">	
	<link rel="stylesheet" href="<?=$app_url;?>plugins/datatables/jquery.dataTables.min.css">
	<link rel="stylesheet" href="<?=$app_url;?>plugins/toastr/toastr.min.css">
	<link rel="stylesheet" href="<?=$app_url;?>plugins/signaturepad/jquery.signaturepad.css">

	<link rel="stylesheet" href="<?=$app_url;?>dist/css/adminlte.css">	
	<link rel="stylesheet" href="<?=$app_url;?>dist/css/style.css"> 	

  	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200;300&display=swap" rel="stylesheet">  
	<link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@200&display=swap" rel="stylesheet">  
	<link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap" rel="stylesheet">  
	<link href="https://fonts.googleapis.com/css2?family=Questrial&family=Ubuntu:wght@300&display=swap" rel="stylesheet">  
	<link href="https://fonts.googleapis.com/css2?family=Saira+Semi+Condensed:wght@300&display=swap" rel="stylesheet">
 
	<style>
		@keyframes rotate360 {
			to {
				transform: rotate(360deg);
			}
		}
		.rotate360 {
			animation: 2s rotate360 infinite linear;
		}	
		.layout-navbar-fixed .wrapper .sidebar-dark-primary .brand-link:not([class*="navbar"]){
			background-color: #fff;
		}	
		.dropdown-custom-item{
			padding: 0.5rem 1rem;
			cursor: pointer;
		}
		.dropdown-custom-item:hover{
			background-color: #eee;
		}
	</style>	
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
	<div class="wrapper"> 
		<nav class="main-header navbar navbar-expand navbar-white navbar-light"> 
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" style="padding-left: 0px;">
						<div style="width: 100%; height: 100%;"> 
							<p style="margin-bottom: 0px;color: #fff; font-size: 16px;"></p>
						</div>
					</a>
				</li>
			</ul> 
			<ul class="navbar-nav ml-auto">	 
				<li class="nav-item">
					<a class="nav-link" href="<?=$app_url;?>index.<?=$_SESSION['dashboard'];?>.php">
						<i class="nav-icon fa fa-home fa-fw" style="font-size: 17px;"></i>
					</a>
				</li>
				<li class="nav-item dropdown" id="generalNotificationPanel" style="display: none;">
					<a class="nav-link" data-toggle="dropdown" href="#">
						<i class="nav-icon far fa-bell" style="font-size: 17px;"></i>
						<span class="badge badge-warning navbar-badge" style="top: 3px !important; right: 5px !important;" id="lblTotalNotiCount">0</span>
					</a>
					<div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" id="generalNotificationDropdown">
						<!-- 15 Notifications -->
						<span class="dropdown-item dropdown-header" id="lblTotalNotiCountWithText"></span>
					</div>
				</li>
				<li class="nav-item" style="display: none;" id="Notification" onclick="getModalNotification();">
					<a class="nav-link" title="Notification" style="cursor: pointer;">
						<i class="nav-icon far fa-bell" style="font-size: 17px;"></i>
						<span class="badge badge-warning navbar-badge" style="top: 3px !important; right: 5px !important;" id="txtNotification">0</span>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" style="padding-right: 11px;"> 
						<img src="<?=$app_url;?>img/dummy_user.png" class="img-circle elevation-2" alt="User Image" style="height: 100%;">
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" style="padding-left: 0px; padding-top: 0px;">
						<div style="width: 100%; height: 100%;"> 
							<p style="margin-bottom: 0px;color: #fff;"><?=$_SESSION['staff_name'];?></p>
							<p style="margin-bottom: 0px;color: #fff;"><?=$_SESSION['userrole'];?></p>
						</div>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?=$app_url;?>logout.php" title="Logout">
						<i class="fas fa-sign-out-alt" style="font-size: 17px;"></i>
					</a>
				</li>
			</ul>
		</nav>
		<script>
			var APP_URL = '<?=$app_url;?>';
		</script>
<?php include 'sidemenu/' . $_SESSION['dashboard'] . '.php'; ?>