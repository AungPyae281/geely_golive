<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	 
	include_once '../config/database.php';
	include_once '../objects/sales_center.php';
	 
	$database = new Database();
	$db = $database->getConnection();
	
	$sales_center = new SalesCenter($db);
	$data = json_decode(file_get_contents("php://input"));

	$stmt = $sales_center->getAllRows();
	$num = $stmt->rowCount();
	
	$arr = array();
	$arr["records"] = array();

	if($num>0){	
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,	
				"name" => $name
			);	
			array_push($arr["records"], $detail);
		}	
	}
	echo json_encode($arr);
?>