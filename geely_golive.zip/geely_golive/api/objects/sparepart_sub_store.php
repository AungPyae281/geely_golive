<?php
class SparepartSubStore{
	private $conn;
	private $table_name = "sparepart_sub_store";

    public $id;
    public $sparepart_store_id;	
	public $sub_store;
	public $shelves_no;
	public $row;
	public $column;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `sparepart_store_id` = :sparepart_store_id AND `sub_store` = :sub_store LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":sparepart_store_id", $this->sparepart_store_id);
		$stmt->bindParam(":sub_store", $this->sub_store);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `sparepart_store_id`=:sparepart_store_id, `sub_store`=:sub_store, `shelves_no`=:shelves_no, `row`=:row, `column`=:column";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":sparepart_store_id", $this->sparepart_store_id);
		$stmt->bindParam(":sub_store", $this->sub_store);
		$stmt->bindParam(":shelves_no", $this->shelves_no);
		$stmt->bindParam(":row", $this->row);
		$stmt->bindParam(":column", $this->column);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$query = "SELECT sss.*, ss.name FROM " . $this->table_name . " AS sss LEFT JOIN sparepart_store AS ss on sss.sparepart_store_id=ss.id ORDER BY ss.name, sss.sub_store";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function getSubStoreByStore(){ 
		$condition = "";	

		if($this->sparepart_store_id){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `sparepart_store_id` =:sparepart_store_id ";
		}
		
		if($condition!=""){
			$condition = " WHERE " . $condition;
		} 

		$query = "SELECT sparepart_sub_store.*, name FROM " . $this->table_name . " LEFT JOIN sparepart_store ON sparepart_sub_store.sparepart_store_id=sparepart_store.id " . $condition . " ORDER BY name, sub_store";
		$stmt = $this->conn->prepare($query);
		if($this->sparepart_store_id) $stmt->bindParam(":sparepart_store_id", $this->sparepart_store_id);
		$stmt->execute();
		return $stmt;
	}
}
?>
