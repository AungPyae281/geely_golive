<?php
class GLType{ 
	private $conn;
	private $table_name = "gl_type";
 
	public $id;
	public $type;

	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY `type`";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}
}
?>