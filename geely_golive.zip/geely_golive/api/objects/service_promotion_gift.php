<?php
class ServicePromotionGift{ 
	private $conn;
	private $table_name = "service_promotion_gift"; 

	public $id;
	public $service_promotion_id;
	public $service_gift_id;
	public $quantity;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_promotion_id=:service_promotion_id, service_gift_id=:service_gift_id, quantity=:quantity";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_promotion_id", $this->service_promotion_id);
		$stmt->bindParam(":service_gift_id", $this->service_gift_id);
		$stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE service_promotion_id=:service_promotion_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_promotion_id", $this->service_promotion_id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getServicePromotionGift(){
		$query = " SELECT spg.*, sg.name FROM " . $this->table_name  . " AS spg LEFT JOIN service_gift AS sg ON spg.service_gift_id=sg.id WHERE spg.service_promotion_id=:service_promotion_id ORDER BY spg.id ";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_promotion_id", $this->service_promotion_id);
		$stmt->execute();
		return $stmt;
	} 
}
?>