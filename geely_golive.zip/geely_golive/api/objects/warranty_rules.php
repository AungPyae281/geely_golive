<?php
class WarrantyRules{
    private $conn;
    private $table_name = "warranty_rules";
 
	public $id;
	public $warranty;
	public $valid_duration;
	public $valid_kilometer;
 
    public function __construct($db){
        $this->conn = $db;
    }

	function getWarrantyRules(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY warranty";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}
}
?>