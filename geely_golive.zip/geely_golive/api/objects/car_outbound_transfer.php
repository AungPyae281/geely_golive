<?php
class CarOutboundTransfer{
	// database connection and table name
	private $conn;
	private $table_name = "car_outbound_transfer";

	// object properties 
	public $id;
	public $car_stock_id;
	public $from_to;
	public $transfer_date;
	public $estimated_arrival_date;
	public $transporter_name;
	public $transporter_phone;
	public $location;
	public $entry_by;
	public $entry_date_time; 

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET car_stock_id=:car_stock_id, `from_to`=:from_to, transfer_date=:transfer_date, estimated_arrival_date=:estimated_arrival_date, transporter_name=:transporter_name, transporter_phone=:transporter_phone, `location`=:location, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":car_stock_id", $this->car_stock_id);
		$stmt->bindParam(":from_to", $this->from_to); 
		$stmt->bindParam(":transfer_date", $this->transfer_date);
		$stmt->bindParam(":estimated_arrival_date", $this->estimated_arrival_date);
		$stmt->bindParam(":transporter_name", $this->transporter_name);
		$stmt->bindParam(":transporter_phone", $this->transporter_phone);
		$stmt->bindParam(":location", $this->location);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			// $this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	// function checkTName($car_stock_id){
	// 	$query = "SELECT transporter_name FROM " . $this->table_name . " WHERE car_stock_id=:car_stock_id order BY entry_date_time DESC LIMIT 1";
	// 	$stmt = $this->conn->prepare($query);

	// 	$stmt->bindParam(":car_stock_id", $this->car_stock_id);
	// 	$stmt->execute();
	// 	if($stmt->rowCount()>0){
	// 		$row = $stmt->fetch(PDO::FETCH_ASSOC);
	// 		extract($row);
	// 		return $transporter_name;
	// 	}
    // }

    // function checkTPhone($car_stock_id){
	// 	$query = "SELECT transporter_phone FROM " . $this->table_name . " WHERE car_stock_id=:car_stock_id order BY entry_date_time DESC LIMIT 1";
	// 	$stmt = $this->conn->prepare($query);

	// 	$stmt->bindParam(":car_stock_id", $this->car_stock_id);
	// 	$stmt->execute();
	// 	if($stmt->rowCount()>0){
	// 		$row = $stmt->fetch(PDO::FETCH_ASSOC);
	// 		extract($row);
	// 		return $transporter_phone;
	// 	}
    // }
}
?>