<?php
class SparepartReceivingDetail{ 
	private $conn;
	private $table_name = "sparepart_receiving_detail"; 

	public $id;
	public $sparepart_receiving_id; 
	public $sparepart_pre_order_id; 
	public $sparepart_code;
	public $sparepart_name; 
	public $quantity;

	public $entry_date;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET sparepart_receiving_id=:sparepart_receiving_id, sparepart_pre_order_id=:sparepart_pre_order_id, sparepart_code=:sparepart_code, sparepart_name=:sparepart_name, quantity=:quantity";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":sparepart_receiving_id", $this->sparepart_receiving_id); 
		$stmt->bindParam(":sparepart_pre_order_id", $this->sparepart_pre_order_id); 
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name); 
		$stmt->bindParam(":quantity", $this->quantity); 

		if($stmt->execute()){
			return true;
		}
		return false;		
	} 
}
?>