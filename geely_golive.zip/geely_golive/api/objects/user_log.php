<?php
class UserLog{
    private $conn;
    private $table_name = "user_log";
 
	public $username;
	public $ip_address;
	public $date_time;
 
    public function __construct($db){
        $this->conn = $db;
    }
	
	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET username=:username, ip_address=:ip_address, date_time=:date_time";
		$stmt = $this->conn->prepare($query);	
	 
		$stmt->bindParam(":username", $this->username);
		$stmt->bindParam(":ip_address", $this->ip_address);
		$stmt->bindParam(":date_time", $this->date_time);
	 
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}
}
?>