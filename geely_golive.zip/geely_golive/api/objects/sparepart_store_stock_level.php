<?php
class SparepartStoreStockLevel{
	private $conn;
	private $table_name = "sparepart_store_stock_level";

    public $id;
    public $sparepart_store_id;	
	public $sparepart_code;
	public $sparepart_name;
	public $minimum;
	public $maximum;
	public $entry_by;
	public $entry_date_time;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `sparepart_store_id` = :sparepart_store_id AND `sparepart_code` = :sparepart_code LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );

		$stmt->bindParam(":sparepart_store_id", $this->sparepart_store_id);
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);

		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `sparepart_store_id`=:sparepart_store_id, `sparepart_code`=:sparepart_code, `sparepart_name`=:sparepart_name, `minimum`=:minimum, `maximum`=:maximum, `entry_by`=:entry_by, `entry_date_time`=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":sparepart_store_id", $this->sparepart_store_id);
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name);
		$stmt->bindParam(":minimum", $this->minimum);
		$stmt->bindParam(":maximum", $this->maximum);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$condition = "";
		if($this->sparepart_store_id){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " sparepart_store_id =:sparepart_store_id ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT sssl.*, ss.name AS store_name FROM " . $this->table_name . " AS sssl LEFT JOIN sparepart_store AS ss on sssl.sparepart_store_id=ss.id " . $condition . " ORDER BY ss.`name`, sssl.sparepart_name";
		$stmt = $this->conn->prepare($query);
		if($this->sparepart_store_id) $stmt->bindParam(":sparepart_store_id", $this->sparepart_store_id);
		$stmt->execute();
		return $stmt;
	}
}
?>
