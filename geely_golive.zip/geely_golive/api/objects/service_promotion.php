<?php
class ServicePromotion{ 
	private $conn;
	private $table_name = "service_promotion"; 

	public $id;
	public $promotion_name;
	public $start_date;
	public $end_date;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE promotion_name = :promotion_name LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->promotion_name=htmlspecialchars(strip_tags($this->promotion_name));
		$stmt->bindParam(":promotion_name", $this->promotion_name);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET promotion_name=:promotion_name, `start_date`=:start_date, `end_date`=:end_date, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":promotion_name", $this->promotion_name);
		$stmt->bindParam(":start_date", $this->start_date);
		$stmt->bindParam(":end_date", $this->end_date);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET `start_date`=:start_date, `end_date`=:end_date WHERE id=:id";
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":id", $this->id); 
		$stmt->bindParam(":start_date", $this->start_date);
		$stmt->bindParam(":end_date", $this->end_date); 

		if($stmt->execute()){
			return true;
		}
		return false;
	} 

	function getOneRow(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE id=:id LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":id", $this->id);

		if($stmt->execute()){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->promotion_name = $row['promotion_name'];
			$this->start_date = $row['start_date'];
			$this->end_date = $row['end_date'];
		}else{
			$this->promotion_name = "";
			$this->start_date = "";
			$this->end_date = "";
		}
	}

	function autocomplete(){
		$condition = "";
		
		if($this->promotion_name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (promotion_name LIKE  :promotion_name '%' or promotion_name LIKE '%' :promotion_name '%' or promotion_name Like '%' :promotion_name )";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY promotion_name";
		$stmt = $this->conn->prepare($query);
		if($this->promotion_name) $stmt->bindParam(":promotion_name", $this->promotion_name);
		$stmt->execute();
		return $stmt;
	}

	function search(){
		$condition = "";		
		
		if($this->start_date){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " start_date =:start_date ";
		}

		if($this->end_date){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " end_date =:end_date ";
		}

		if($this->promotion_name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (promotion_name LIKE  :promotion_name '%' or promotion_name LIKE '%' :promotion_name '%' or promotion_name Like '%' :promotion_name) ";
		}
		
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY start_date, end_date, promotion_name";

		$stmt = $this->conn->prepare($query);
		
		$this->start_date=htmlspecialchars(strip_tags($this->start_date));
		$this->end_date=htmlspecialchars(strip_tags($this->end_date));
		$this->promotion_name=htmlspecialchars(strip_tags($this->promotion_name));	

		if($this->start_date) $stmt->bindParam(":start_date", $this->start_date);
		if($this->end_date) $stmt->bindParam(":end_date", $this->end_date);
		if($this->promotion_name) $stmt->bindParam(":promotion_name", $this->promotion_name);
		
		$stmt->execute();
		return $stmt;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY promotion_name";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}
}
?>