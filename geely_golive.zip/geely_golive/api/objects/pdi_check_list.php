<?php
class PDICheckList{
    // database connection and table name
	private $conn;
	private $table_name = "pdi_check_list";

	// object properties 
	public $id;
	public $oc_no;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function getOneRow(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE oc_no=:oc_no";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		return $stmt;
	}

	function exist(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE oc_no=:oc_no LIMIT 0, 1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET oc_no=:oc_no, entry_by=:entry_by, entry_date_time=:entry_date_time ";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;
	} 

	function update(){
		$query = "UPDATE " . $this->table_name . " SET `" . $this->column_name . "`=:value WHERE oc_no=:oc_no";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":value", $this->value);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}	
}
?>