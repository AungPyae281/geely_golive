<?php
class SparepartStockOut{
	private $conn;
	private $table_name = "sparepart_stock_out";
 
	public $id;
	public $date;
	public $service_id;
	public $store_name; 
	public $sparepart_code;
	public $sparepart_name;
	public $quantity;
	public $damage;
	public $lost;
	public $stock_out_by;
	public $remark;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `date`=:date, service_id=:service_id, store_name=:store_name, sparepart_code=:sparepart_code, sparepart_name=:sparepart_name, quantity=:quantity, damage=:damage, lost=:lost, stock_out_by=:stock_out_by, remark=:remark, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->bindParam(":store_name", $this->store_name); 
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name);
		$stmt->bindParam(":quantity", $this->quantity);
		$stmt->bindParam(":damage", $this->damage);
		$stmt->bindParam(":lost", $this->lost);
		$stmt->bindParam(":stock_out_by", $this->stock_out_by);
		$stmt->bindParam(":remark", $this->remark);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE `date`=:date AND store_name=:store_name";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":store_name", $this->store_name);
		$stmt->execute();
		return $stmt;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id=:id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":id", $this->id);		
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	} 
}
?>