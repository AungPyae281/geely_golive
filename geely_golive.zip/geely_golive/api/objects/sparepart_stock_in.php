<?php
class SparepartStockIn{ 
	private $conn;
	private $table_name = "sparepart_stock_in";

	// object properties

	public $id;
	public $date;
	public $order_id;
	public $store_name; 
	public $sparepart_code;
	public $sparepart_name;
	public $quantity;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET date=:date, order_id=:order_id, `store_name`=:store_name, sparepart_code=:sparepart_code, sparepart_name=:sparepart_name, quantity=:quantity, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":order_id", $this->order_id);
		$stmt->bindParam(":store_name", $this->store_name); 
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name);
		$stmt->bindParam(":quantity", $this->quantity);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}
}
?>