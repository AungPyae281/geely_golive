<?php
class StaffServiceCenter{
    private $conn;
    private $table_name = "staff_service_center";
 
	public $id;	
	public $staff_id;
	public $service_center_id;
	public $service_center;
	public $store_name;
	public $entry_by;
	public $entry_date_time; 
 
    public function __construct($db){
        $this->conn = $db;
    }	

    function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE staff_id=:staff_id"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":staff_id", $this->staff_id); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;		
	}
 
 	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET staff_id=:staff_id, service_center_id=:service_center_id, service_center=:service_center, store_name=:store_name, entry_by=:entry_by, entry_date_time=:entry_date_time"; 
		$stmt = $this->conn->prepare($query); 

		$stmt->bindParam(":staff_id", $this->staff_id); 
		$stmt->bindParam(":service_center_id", $this->service_center_id);
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->bindParam(":store_name", $this->store_name);
		$stmt->bindParam(":entry_by", $this->entry_by); 
		$stmt->bindParam(":entry_date_time", $this->entry_date_time); 

		if($stmt->execute()){ 
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$condition = "";	 

		if($this->service_center_id){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " staff_service_center.service_center_id = :service_center_id ";
		}
		 
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT staff_service_center.*, staff.name FROM " . $this->table_name . " LEFT JOIN staff ON staff_service_center.staff_id=staff.id " . $condition . " ORDER BY staff.name, staff_service_center.service_center ";
		$stmt = $this->conn->prepare($query); 		 
		if($this->service_center_id) $stmt->bindParam(":service_center_id", $this->service_center_id);
		$stmt->execute();
		return $stmt;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id=:id"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":id", $this->id); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}
}
?>