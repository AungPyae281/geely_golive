<?php
class Route{
	// database connection and table name
	private $conn;
	private $table_name = "route";

	// object properties 
	public $id;
	public $dashboard;
	public $module;
	public $route;
	public $process;
	public $title;
	public $create;
	public $read;
	public $update;
	public $delete;
	public $export;
	public $print;
	
	public $rolename;

	public function __construct($db){
		$this->conn = $db;
	}

	function getRouteByUserRole(){
		$query = "SELECT CONCAT(ur.`create`, ur.`read`, ur.`update`, ur.`delete`, ur.`export`, ur.print) AS permit, CONCAT(ar.`create`, ar.`read`, ar.`update`, ar.`delete`, ar.`export`, ar.print) AS access FROM user_role as ur inner join route AS ar ON ur.dashboard = ar.dashboard AND ur.process = ar.process WHERE ur.role_name = :role_name AND ar.route = :route AND ur.dashboard = :dashboard ";
		
		$stmt = $this->conn->prepare($query);	
		if($this->rolename) $stmt->bindParam(":role_name", $this->rolename);
		if($this->route) $stmt->bindParam(":route", $this->route);
		if($this->dashboard) $stmt->bindParam(":dashboard", $this->dashboard);
		
		$stmt->execute();
		return $stmt;
	} 

	function getRouteByKEYUser(){
		$query = "SELECT CONCAT(ar.`create`, ar.`read`, ar.`update`, ar.`delete`, ar.`export`, ar.print) AS permit, CONCAT(ar.`create`, ar.`read`, ar.`update`, ar.`delete`, ar.`export`, ar.print) AS access FROM " . $this->table_name . " AS ar WHERE dashboard=:dashboard";
		
		$stmt = $this->conn->prepare($query);	
		$stmt->bindParam(":dashboard", $this->dashboard);
		
		$stmt->execute();
		return $stmt;
	} 

	function getAllDashboard(){
		$query = "SELECT dashboard FROM " . $this->table_name . " WHERE dashboard!='' GROUP BY dashboard ORDER BY dashboard";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function getAllProcessWithAccess(){
		$query = "SELECT `module`, `process`, MAX(`create`) AS `create`, MAX(`read`) AS `read`, MAX(`update`) AS `update`, MAX(`delete`) AS `delete`, MAX(`export`) AS `export`, MAX(`print`) AS `print` FROM " . $this->table_name . " WHERE dashboard=:dashboard GROUP BY `module`, `process`";
		
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":dashboard", $this->dashboard);
		$stmt->execute();
		return $stmt;
	}
}
?>