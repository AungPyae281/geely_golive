<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_customer.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $service_customer = new ServiceCustomer($db);
    $data = json_decode(file_get_contents("php://input"));

    if($_SESSION['user']!=""){

        $service_customer->registration_no = $service_customer->generateCode("S" . date("ymd"));
        $service_customer->name = $data->name;
        $service_customer->nrc_no = $data->nrc_no;
        $service_customer->phone_no = $data->phone_no;
        $service_customer->alternative_phone_no = $data->alternative_phone_no;
        $service_customer->email = $data->email;
        $service_customer->township = $data->township;
        $service_customer->address = $data->address;
        $service_customer->source = $data->source;
        $service_customer->entry_by = $_SESSION['user'];
        $service_customer->entry_date_time = date("Y-m-d H:i");

        if($service_customer->isExist()){
            $msg_arr = array(
                "message" => "duplicate"
            );  
        }else{
            if($service_customer->create()){
                $msg_arr = array(
                    "message" => "created"
                );  
            }else{
                $msg_arr = array(
                    "message" => "error"
                );
            }
        }
    }else{
        $msg_arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($msg_arr);
?>