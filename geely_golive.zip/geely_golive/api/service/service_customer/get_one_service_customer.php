<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_customer.php';
    include_once '../../objects/service_car.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $service_customer = new ServiceCustomer($db);
    $service_car = new ServiceCar($db);
    $data = json_decode(file_get_contents("php://input"));

    $service_customer->id = $data->id;
    $service_car->service_customer_id = $data->id;

    $service_customer->getServiceCustomer();

    $service_customer_cars = array();

    $stmt = $service_car->getServiceCarByCustomer();
    $num = $stmt->rowCount();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
    		$detail = array(
                "id" => $id,
                "service_customer_id" => $service_customer_id,
                "plate_no" => $plate_no,
                "brand" => $brand,
                "model" => $model,
                "model_year" => $model_year,
                "exterior_color" => $exterior_color
            );
            array_push($service_customer_cars, $detail);
        }
    }

    $arr = array(    
        "id" => $service_customer->id,
        "registration_no" => $service_customer->registration_no,
        "name" => $service_customer->name,
        "nrc_no" => $service_customer->nrc_no,
        "phone_no" => $service_customer->phone_no,
        "alternative_phone_no" => $service_customer->alternative_phone_no,
        "email" => $service_customer->email,
        "township" => $service_customer->township,
        "address" => $service_customer->address,
        "service_customer_cars" => $service_customer_cars
    );

    echo json_encode($arr);

?>