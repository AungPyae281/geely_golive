<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_item.php';
	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$service_item = new ServiceItem($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['staff_id']!=""){

		$service_item->name = $data->name;
		$service_item->waiting_time = $data->waiting_time;
		$service_item->price = $data->price;

		if($data->id){
			$service_item->id = $data->id;
			if($service_item->update()){
				$arr = array(
					"message" => "updated"
				);
			}else{
				$arr = array(
					"message" => "errorU"
				);
			}
		}else{
			if($service_item->isExist()){
				$arr = array(
					"message" => "duplicate"
				);
			}else{
				$service_item->code = $service_item->generateCode();
				if($service_item->create()){
					$arr = array(
						"message" => "created"
					);
				}else{
					$arr = array(
						"message" => "errorC"
					);
				}
			}
			
		}
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>