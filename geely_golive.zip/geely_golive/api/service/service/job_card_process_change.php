<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service.php';
	include_once '../../objects/service_detail_service_item.php';

    date_default_timezone_set('Asia/Rangoon');
    session_start();

	$database = new Database();
	$db = $database->getConnection();

	$service = new Service($db);
	$service_detail_service_item = new ServiceDetailServiceItem($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		if($data->status!=""){
			$service->id = $data->id;
			$service->status = $data->status;
			$service->updateStatus();
		}
		$service_detail_service_item->id = $data->detail_id;
		$service_detail_service_item->technician_id = $data->technician_id;
		$service_detail_service_item->bay_no = $data->bay_no;
		$service_detail_service_item->start_time = (($data->start_time!="")?date("H:i", strtotime($data->start_time)):"");
		$service_detail_service_item->end_time = (($data->end_time!="")?date("H:i", strtotime($data->end_time)):"");

		if($service_detail_service_item->updateJCProcessChange()){
			$msg_arr = array(
				"message" => "updated"
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>