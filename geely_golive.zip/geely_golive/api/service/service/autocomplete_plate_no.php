<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service.php';

    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $service = new Service($db);
    $data = json_decode(file_get_contents("php://input"));

    $arr = array();
    
    if($_SESSION['service_center']!=""){

        $service->service_center = $_SESSION['service_center'];
        $service->plate_no = $data->plate_no;

        $stmt = $service->autocompletePlateNo();
        $num = $stmt->rowCount();
        $arr = array();

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $detail = array(
                    "plate_no" => $plate_no
                );
                array_push($arr, $detail);
            }
        }
    }
    echo json_encode($arr);
?>