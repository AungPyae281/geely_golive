<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_detail_sparepart.php';
    
    date_default_timezone_set('Asia/Rangoon');
     
    $database = new Database();
    $db = $database->getConnection();

    $service_detail_sparepart = new ServiceDetailSparepart($db);
    $data = json_decode(file_get_contents("php://input"));

    $service_detail_sparepart->service_id = $data->id;

    $stmt = $service_detail_sparepart->getSparepartDetailForIN();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $detail = array(
                "id" => $id,
                "code" => $code,
                "name" => $name,
                "request_quantity" => $qty,
                "receive_quantity" => $receive_qty,
                "warranty" => (int)$warranty
            );
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>