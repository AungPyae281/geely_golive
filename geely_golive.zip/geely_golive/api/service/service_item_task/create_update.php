<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_item_task.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$service_item_task = new ServiceItemTask($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){
		
		$service_item_task->service_item_id = $data->service_item_id;
		$service_item_task->description = $data->description;
		$service_item_task->tips = $data->tips;
		$service_item_task->requirements = $data->requirements;
		$service_item_task->entry_by = $_SESSION['user'];
		$service_item_task->entry_date_time = date("Y-m-d H:i:s");

		if($data->id){
			$service_item_task->id = $data->id;
			if($service_item_task->update()){
				$msg_arr = array(
					"message" => "updated"
				);
			}else{
				$msg_arr = array(
					"message" => "errorU"
				);
			}
		}else{
			if($service_item_task->isExist()){
				$msg_arr = array(
					"message" => "duplicate"
				);
			}else{
				if($service_item_task->create()){
					$msg_arr = array(
						"message" => "created"
					);
				}else{
					$msg_arr = array(
						"message" => "error"
					);
				}
			}
		} 
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}

	echo json_encode($msg_arr);
?>