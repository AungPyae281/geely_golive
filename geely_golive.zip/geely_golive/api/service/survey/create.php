<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/survey.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$survey = new Survey($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$survey->ser_one = $data->ser_one;
		$survey->ser_two = $data->ser_two;
		$survey->ser_three = $data->ser_three;
		$survey->ser_four = $data->ser_four;
		$survey->ser_five = $data->ser_five;
		$survey->contact_name = $data->contact_name;
		$survey->contact_phone = $data->contact_phone;
		$survey->entry_by = $_SESSION['user'];
		$survey->entry_date_time = date("Y-m-d H:i:s");

		if($survey->create()){
		  	$msg_arr = array(
				"message" => "created",
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>	