<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php'; 
	include_once '../../objects/service_detail_sparepart.php';
	include_once '../../objects/sparepart_stock_balance.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	  
	$service_detail_sparepart = new ServiceDetailSparepart($db);
	$sparepart_stock_balance = new SparepartStockBalance($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['store_name']!=""){

		$store_name = $_SESSION['store_name'];

		$service_detail_sparepart->service_id = $data->service_id;
		$service_detail_sparepart->code = $data->code;
		$service_detail_sparepart->name = $data->name;
		$service_detail_sparepart->qty = $data->qty; 
		$service_detail_sparepart->warranty = $data->warranty;

		$sparepart_stock_balance->store_name = $store_name;
		$sparepart_stock_balance->sparepart_code = $data->code;
		$sparepart_stock_balance->sign = "+";
		$sparepart_stock_balance->quantity = $data->qty;

		if($store_name!=""){
			if($sparepart_stock_balance->checkSparepartForService()){

				if($service_detail_sparepart->checkSparepart()){
					if(!$service_detail_sparepart->update()){
						$msg_arr = array(
							"message" => "error"
						);
					}
				}else{
					if(!$service_detail_sparepart->create()){
						$msg_arr = array(
							"message" => "error"
						);
					}
				}
				if(!$sparepart_stock_balance->updateFromServiceIssueNote()){
					$msg_arr = array(
						"message" => "errorStockBalance"
					);
					echo json_encode($msg_arr);
					die();
				}
				$msg_arr = array(
					"message" => "created"
				);
			}else{
				$msg_arr = array(
					"message" => "not enough"
				);
			}
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>