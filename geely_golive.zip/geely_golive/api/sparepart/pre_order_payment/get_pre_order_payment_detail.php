<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_pre_order.php';
    include_once '../../objects/sparepart_pre_order_payment.php';
    include_once '../../../config/_globle.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $sparepart_pre_order = new SparepartPreOrder($db);
    $sparepart_pre_order_payment = new SparepartPreOrderPayment($db);
    $data = json_decode(file_get_contents("php://input"));

    $sparepart_pre_order->id = $data->id;

    $sparepart_pre_order->getOnePreOrderPayment();

    // Pre Order Payment
    $sparepart_pre_order_payment->sparepart_pre_order_id = $data->id;

    $payment_detail = array();

    $stmt = $sparepart_pre_order_payment->getPreOrderPaymentDetail();
    $num = $stmt->rowCount();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "id" => $id,
                "date" => $date,
                "gl_code" => $gl_code,
                "gl_code_bank_or_cash" => $gl_code_bank_or_cash,
                "paid_by" => $paid_by,
                "upload_receipt" => (($upload_receipt)?($app_url . "api/sparepart/pre_order_payment/upload/" . $upload_receipt):""),
                "description" => $description,
                "amount" => number_format($amount)
            );
            array_push($payment_detail, $detail);
        }
    }
    // Pre Order Payment

    $arr = array(
        "id" => $sparepart_pre_order->id,
        "pre_order_id" => $sparepart_pre_order->wl_id,
        "date" => $sparepart_pre_order->pre_order_date,
        "service_center" => $sparepart_pre_order->service_center,
        "customer_name" => $sparepart_pre_order->customer_name,
        "customer_phone" => $sparepart_pre_order->customer_phone,
        "plate_no" => $sparepart_pre_order->plate_no,
        "total_items" => (int)$sparepart_pre_order->total_items,
        "total_quantity" => (int)$sparepart_pre_order->total_quantity,
        "total_amount" => number_format((int)$sparepart_pre_order->total_amount),
        "total_payment" => number_format((int)$sparepart_pre_order->payment),
        "balance" => number_format((int)$sparepart_pre_order->balance),
        "payment_detail" => $payment_detail
    );
    echo json_encode($arr);
?>