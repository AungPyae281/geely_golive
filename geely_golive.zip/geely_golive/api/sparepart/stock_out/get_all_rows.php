<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_stock_out.php';

    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $sparepart_stock_out = new SparepartStockOut($db);
    $data = json_decode(file_get_contents("php://input"));

    $arr = array();
    $arr["records"] = array();

    if($_SESSION['store_name']!=""){

        $sparepart_stock_out->date = $data->date;   
        $sparepart_stock_out->store_name = $_SESSION['store_name'];  

        $stmt = $sparepart_stock_out->getAllRows();
        $num = $stmt->rowCount();

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $detail = array(
                    "id" => (int)$id,
                    "date" => $date,
                    "store_name" => $store_name,
                    "sparepart_code" => $sparepart_code,
                    "sparepart_name" => $sparepart_name,
                    "stock_out_by" => $stock_out_by,
                    "damage" => (int)$damage,
                    "lost" => (int)$lost,
                    "quantity" => number_format((int)$quantity),
                    "remark" => $remark
                );  
                array_push($arr["records"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>