<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $sparepart = new Sparepart($db);   

    $sparepart->service_center = $_GET["sc"];

    $stmt = $sparepart->getAllSparepartsByServiceCenter();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["data"] = array(); 

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                $group_name,
                $sub_group_name,
                $code,
                $name,
                $category,
                $origin,
                $unit,
                number_format($sales_price),
                number_format($dealer_price),
                number_format($avail_qty),
                $id
            );
            array_push($arr["data"], $detail);
        }
    }
    echo json_encode($arr);
?>