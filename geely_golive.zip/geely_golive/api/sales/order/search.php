<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/order.php'; 

    $database = new Database();
    $db = $database->getConnection();

    $order = new Order($db);
    $data = json_decode(file_get_contents("php://input")); 

    $order->df = $data->df;
    $order->dt = $data->dt;
    $order->oc_no = $data->oc_no;
    $order->customer_name = $data->customer_name;
    $order->customer_phone = $data->customer_phone;
    $order->broker_name = $data->broker_name;
    $order->sales_center = $data->sales_center;
    $order->staff_name = $data->staff_name;

    $stmt = $order->search();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                "date" => $date,
                "oc_no" => $oc_no,
                "sales_center" => $sales_center,
                "customer_name" => $customer_name,
                "customer_phone" => $customer_phone,
                "broker_name" => $broker_name,
                "vin_no" => $vin_no,
                "sales_type" => $sales_type,
                "vehicle_status" => $vehicle_status
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>