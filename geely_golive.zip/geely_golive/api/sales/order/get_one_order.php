<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/order.php'; 
    include_once '../../objects/car_list.php';
    include_once '../../objects/approval.php';
    session_start();
     
    $database = new Database();
    $db = $database->getConnection();

    $order = new Order($db); 
    $car_list = new CarList($db);
    $approval = new Approval($db);
    $data = json_decode(file_get_contents("php://input"));

    $order->oc_no = $data->oc_no;
    $order->getOneRow(); 

    //Exterior, Interior Image
    $car_list->brand = $order->brand;
    $car_list->model = $order->model;
    $car_list->model_year = $order->model_year;
    $car_list->grade = $order->grade;
    $car_list->exterior_color = $order->exterior_color;
    $car_list->interior_color = $order->interior_color;

    $car_list_id = $car_list->getCarListID();

    $interior_photo = "";
    $exterior_photo = "";

    $dir = "../../../upload/server/php/files/interior/" . $car_list_id . "/";

    if(file_exists($dir)){
        $dh  = opendir($dir);
        while (false !== ($filename = readdir($dh))) {
            $filesIn[] = $filename;
        }
        rsort($filesIn);
        foreach($filesIn as $fileIn) {
            if ($fileIn != "." && $fileIn != ".." && $fileIn != "design" && $fileIn != "thumbnail") {
                $filewithoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $fileIn);
                $interior_photo = $fileIn;
                break;
            }
        }
    }

    $dir = "../../../upload/server/php/files/exterior/" . $car_list_id . "/";

    if(file_exists($dir)){
        $dh  = opendir($dir);
        while (false !== ($filename = readdir($dh))) {
            $filesEx[] = $filename;
        }
        rsort($filesEx);
        foreach($filesEx as $fileEx) {
            if ($fileEx != "." && $fileEx != ".." && $fileEx != "design" && $fileEx != "thumbnail") {
                $filewithoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $fileEx);
                $exterior_photo = $fileEx;
                break;
            }
        }
    }
    //Exterior, Interior Image

    $approval->se_id = $order->staff_id;
    $approval->approval_staff_id = $_SESSION['staff_id'];
    $approval->process = "Confirm Order";
    $approval->main_id = $data->oc_no;

    $btnApprove = 0; 

    $approval->getOneApprovalForOrder();

    if(($approval->approve==0 && $approval->condition=="AND") || ($approval->approve==0 && $approval->condition=="OR" && $approval->apv_count==0)){
        $btnApprove = 1;
    }

    $arr = array(
        "id" => $order->id,
        "sales_center" => $order->sales_center,
        "oc_no" => $order->oc_no,
        "date" =>  $order->date, 
        "sales_type" => $order->sales_type,
        "staff_id" => $order->staff_id,

        "broker_id" => $order->broker_id,
        "b_registration_no" => $order->b_registration_no,
        "broker_name" => $order->broker_name,

        "c_registration_no" => $order->c_registration_no,
        "customer_id" => $order->customer_id,
        "customer_name" => $order->customer_name,
        "c_nrc_no" => $order->c_nrc_no,
        "c_mobile_no" => $order->c_mobile_no,
        "c_email" => $order->c_email,
        "c_township" => $order->c_township,
        "customer_type" => $order->customer_type,
        "company_name" => $order->company_name,
        "company_register_no" => $order->company_register_no,
        
        "same_as_buyer" => $order->same_as_buyer,
        "rtad_name" => $order->rtad_name,
        "rtad_nrc_no" => $order->rtad_nrc_no,
        "rtad_mobile_no" => $order->rtad_mobile_no,
        "rtad_township" => $order->rtad_township,

        "vehicle_status" => $order->vehicle_status,
        "car_list_id" => $car_list_id,   
        "brand" => $order->brand,   
        "model" => $order->model,
        "model_year" => $order->model_year,    
        "grade" => $order->grade,   
        "exterior_color" => $order->exterior_color,
        "interior_color" => $order->interior_color,
        "vin_no" => $order->vin_no,
        "engine_no" => $order->engine_no,
        "interior_photo" => $interior_photo,
        "exterior_photo" => $exterior_photo,

        "payment_type" => $order->payment_type,
        "bank" => $order->bank,    
        "payment_percent" => $order->payment_percent,
        "payment_term" => $order->payment_term,

        "promotion_code" => $order->promotion_code,
        "promotion_discount" => number_format($order->promotion_discount), 
        "vehicle_price" => number_format($order->vehicle_price),
        "rtad_tax" => number_format($order->rtad_tax),
        "deposit" => number_format($order->deposit),

        "btn_approve" => $btnApprove, 
        "permission_edit" => (int)$approval->permission_edit,
        "order_no" => (int)$approval->order_no
    );
    echo json_encode($arr);
?>