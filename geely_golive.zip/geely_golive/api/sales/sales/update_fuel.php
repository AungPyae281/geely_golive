<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/sales.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$sales = new Sales($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['staff_id']!=""){
		$sales->oc_no = $data->oc_no;
		$sales->fuel_amount = $data->fuel_amount;

		if($sales->updateFuel()){

			if($data->ff_done==1){

				$sales->status = "Fill the Fuel";
				$sales->processing = "PDI Check List";

				$sales->column_name = "ff_done";
				if($sales->updateDone()){
					if(!$sales->updateStatus()){
					    $arr = array(
					        "message" => "Status Update Error"
					    );
					    echo json_encode($arr);
					    die();
					}
				}

			}

			$arr = array(
				"message" => "updated"
			);
		}else{
		    $arr = array(
				"message" => "error"
			);
		}
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>