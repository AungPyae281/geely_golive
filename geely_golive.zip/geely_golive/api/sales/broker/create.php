<?php
	// required headers
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/broker.php';	
	include_once '../../objects/broker_bank_account.php';	

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$broker = new Broker($db);
	$broker_bank_account = new BrokerBankAccount($db);
	$data = json_decode(file_get_contents("php://input"));

	$broker->registration_no = $broker->getGenerateRegistrationNo("G.B-");
	$broker->name = $data->name;
	$broker->gender = $data->gender;
	$broker->dob = $data->dob;
	$broker->nrc_no = $data->nrc_no;
	$broker->phone = $data->phone;
	$broker->email = $data->email;
	$broker->register_date = $data->register_date; 
	$broker->company = $data->company;
	$broker->address = $data->address;

	$broker->entry_by = $_SESSION['user'];
	$broker->entry_date_time = date("Y-m-d H:i:s");

	if($broker->checkBroker()){
		$arr = array(
			"message" => "duplicate"
		);
	}else{
		if($broker->create()){ 
			foreach ($data->bankInfo as $bankInfo) {
				$broker_bank_account->broker_id = $broker->id;
				$broker_bank_account->name = $bankInfo->name;
				$broker_bank_account->account_no = $bankInfo->account_no;

				$broker_bank_account->create();
			}

			$arr = array(
				"id" => $broker->id,
				"message" => "created"
			);
		}else{
			$arr = array(
				"message" => "error"
			);
		}
	}
	echo json_encode($arr);
?>