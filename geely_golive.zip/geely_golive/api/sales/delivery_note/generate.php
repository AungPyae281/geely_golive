<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/delivery_note.php'; 

	date_default_timezone_set('Asia/Rangoon'); 
	session_start(); 

	$database = new Database();
	$db = $database->getConnection();
	 
	$delivery_note = new DeliveryNote($db);
	$data = json_decode(file_get_contents("php://input"));	

	if($_SESSION['staff_id']!=""){
		
		$delivery_note->oc_no = $data->oc_no;
		$delivery_note->date = $data->date;
		$delivery_note->delivery_to = $data->delivery_to;
		$delivery_note->phone_no = $data->phone_no;
		$delivery_note->address = $data->address;
		$delivery_note->model = $data->model;
		$delivery_note->grade = $data->grade;
		$delivery_note->engine = $data->engine;
		$delivery_note->colour_ext_int = $data->colour_ext_int;
		$delivery_note->vin_no = $data->vin_no;
		$delivery_note->registration_no = $data->registration_no;
		$delivery_note->invoice_no = $data->invoice_no;
		$delivery_note->sales_person = $data->sales_person;
		$delivery_note->generate_by = $_SESSION['user'];
		$delivery_note->generate_date_time = date("Y-m-d H:i:s");

		if($delivery_note->exist()){
			if(!$delivery_note->update()){
				$arr = array(
					"message" => "updateError",
					"oc_no" => $data->oc_no
				);
			}
		}else{
			if(!$delivery_note->create()){
				$arr = array(
					"message" => "createError",
					"oc_no" => $data->oc_no
				);
			}
		}
		$arr = array(
			"message" => "created",
			"oc_no" => $data->oc_no
		);
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>	