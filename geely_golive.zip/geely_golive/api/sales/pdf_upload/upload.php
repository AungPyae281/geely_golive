<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php';   
    
    date_default_timezone_set('Asia/Rangoon'); 

    $database = new Database();
    $db = $database->getConnection();
     
    $sales = new Sales($db);  
    $data = json_decode(file_get_contents("php://input"));

    $file_name = "";
    if(!empty($_FILES['file'])){
    	if (!is_dir('./upload/' . $_GET["oc_no"])) {
            mkdir('./upload/' . $_GET["oc_no"], 0777, true);
        }
        if($_GET['ofn']!=""){
            if(file_exists("./upload/" . $_GET["oc_no"] . "/" . $_GET["ofn"])){
                unlink("./upload/" . $_GET["oc_no"] . "/" . $_GET["ofn"]);
            }
        }

        $newname = date("Ymd") . '-' . $_GET["oc_no"] . '-' . preg_replace('/\s+/', '', ucwords($_FILES['file']['name']));
        $targetPath = './upload/' . $_GET["oc_no"] . "/" . $newname;
        move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);

        $file_name = $newname;
    }

    $sales->oc_no = $_GET["oc_no"];
    $sales->column_name = $_GET["column_name"];

    if($_GET["column_name"]=="dc_others"){
    	$sales->file_name = "|" . $file_name . "|";
    }else{
    	$sales->file_name = $file_name;
    }

    if($sales->updateDC()){
        $arr = array(
            "message" => "updated",
            "file_name" => $file_name
        );
    }else{
        $arr = array(
            "message" => "error"
        );
    }
    echo json_encode($arr);
?>