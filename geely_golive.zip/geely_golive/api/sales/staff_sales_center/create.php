<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/staff_sales_center.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$staff_sales_center = new StaffSalesCenter($db);
	$data = json_decode(file_get_contents("php://input"));

	$staff_sales_center->staff_id = $data->staff_id;
	$staff_sales_center->sales_center_id = $data->sales_center_id;
	$staff_sales_center->sales_center = $data->sales_center;
	$staff_sales_center->entry_by = $_SESSION['user'];
	$staff_sales_center->entry_date_time = date("Y-m-d H:i:s");

	if($staff_sales_center->isExist()){
		$arr = array(
			"message" => "duplicate"
		);
	}else{
		if($staff_sales_center->create()){
			$arr = array(
				"message" => "created"
			);
		}else{
			$arr = array(
				"message" => "error"
			);
		}
	}
	echo json_encode($arr);
?>