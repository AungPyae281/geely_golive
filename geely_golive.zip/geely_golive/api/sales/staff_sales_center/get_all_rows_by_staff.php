<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	 
	include_once '../../config/database.php';
	include_once '../../objects/staff_sales_center.php';
	
	session_start();
	$database = new Database();
	$db = $database->getConnection();
	
	$staff_sales_center = new StaffSalesCenter($db);
	$data = json_decode(file_get_contents("php://input"));

	$staff_sales_center->staff_id = $_SESSION["staff_id"];

	$stmt = $staff_sales_center->getAllRowsByStaff();
	$num = $stmt->rowCount();
	
	$arr = array();
	$arr["records"] = array();

	if($num>0){	
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"sales_center" => $sales_center
			);	
			array_push($arr["records"], $detail);
		}	
	}
	echo json_encode($arr);
?>