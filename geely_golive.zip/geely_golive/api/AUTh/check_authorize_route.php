<?php 
	if($_SESSION['user']){
		$url = str_replace("/geely_golive/", "", $_SERVER["REQUEST_URI"]);
		
		$urlArr1 = explode("&", $url);
		$newURL = $urlArr1[0];
		if(count($urlArr1)>1){
			$urlArr2 = explode("=", $urlArr1[1]);
			$newURL .= ((count($urlArr2)>1)?"&" . $urlArr2[0] . "=":"");
		}
		$url = $newURL;	

		if($url != "index." . $_SESSION['dashboard'] . ".php" && $url != ""){
			include_once '../api/config/database.php';
			include_once '../api/objects/route.php';
		}else{
			include_once 'api/config/database.php';
			include_once 'api/objects/route.php';
		}
		// instantiate database
		$database = new Database();
		$db = $database->getConnection();
		
		// initialize object
		$route = new Route($db);
		$route->dashboard = $_SESSION['dashboard'];
		$route->rolename = $_SESSION['userrole'];
		$route->route = $url; 
		
		if($route->route!="index." . $route->dashboard . ".php" && $route->route != ""){
			$stmt = ($_SESSION["userrole"]=="KEY")?$route->getRouteByKEYUser():$route->getRouteByUserRole();
			$num = $stmt->rowCount();
			if($num>0){
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
					extract($row);
					$chars = str_split($access);
					for ($i = 0; $i < strlen($access); $i++) {
						if($access[$i]=="1"){
							if($permit[$i]!="1"){
								header('Location: '. $app_url .'index.' . $route->dashboard . '.php');
							}
						}
					}			
				}
			}else{
				header('Location: '. $app_url .'index.' . $route->dashboard . '.php');
			}
		}
	}else{
		header('Location: ' . $app_url . 'login.html');
	}
?>