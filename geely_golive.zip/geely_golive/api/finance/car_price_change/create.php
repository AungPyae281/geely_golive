<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/car_price_change.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$car_price_change = new CarPriceChange($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['staff_id']!=""){
		$car_price_change->date_from = $data->date_from;
		$car_price_change->date_to = $data->date_to;
		$car_price_change->vehicle_price = $data->vehicle_price;

		$car_price_change->entry_by = $_SESSION['user'];
		$car_price_change->entry_date_time = date("Y-m-d");

		foreach ($data->car_list as $car) {
			$car_price_change->car_list_id = $car->id;
			$car_price_change->old_vehicle_price = $car->old_vehicle_price;

			if(!$car_price_change->create()){
				$arr = array(
					"message" => "error"
				);
				echo json_encode($arr);
				die();
			}
		}

		$arr = array(
			"message" => "created"
		);
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>