<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/bank_account_transfer.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $bank_account_transfer = new BankAccountTransfer($db);
    $data = json_decode($_POST['objArr']);

    $targetPath = "";
    $newname = "";

    if(!empty($_FILES['file']))
    {
        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        if($ext==""){
            $targetPath = "./upload/no_image.jpg";
        }else{
            $newname = date("Y-m-d H-i-s") .  "." . $ext;
            $targetPath = './upload/' . $newname;
            copy($_FILES['file']['tmp_name'], $targetPath);
        }  
    }
    $bank_account_transfer->upload_receipt = $newname;  

    $bank_account_transfer->gl_code_from = $data[0]->gl_code_from;
    $bank_account_transfer->account_from = $data[0]->account_from;
    $bank_account_transfer->gl_code_to = $data[0]->gl_code_to;
    $bank_account_transfer->account_to = $data[0]->account_to;
    $bank_account_transfer->date = $data[0]->date;
    $bank_account_transfer->amount_from = $data[0]->amount_from;
    $bank_account_transfer->amount_to = $data[0]->amount_to;
    $bank_account_transfer->exchange_rate = $data[0]->exchange_rate; 

    $bank_account_transfer->entry_by = $_SESSION['user'];
    $bank_account_transfer->entry_date_time = date("Y-m-d H:i:s");

    if($bank_account_transfer->create()){
        $msg_arr = array(
            "message" => "created"
        );
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }
    echo json_encode($msg_arr);
?>