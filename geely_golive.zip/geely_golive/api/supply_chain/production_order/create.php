<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/production_order.php';

	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$production_order = new ProductionOrder($db);
	$data = json_decode(file_get_contents("php://input"));

	foreach ($data->po_lists as $polist) {
		$production_order->car_list_id = $polist->car_list_id;
		$production_order->order_date = $polist->order_date;
		$production_order->order_no = $polist->order_no;
		$production_order->quantity = $polist->quantity;
		$production_order->entry_by = $_SESSION['user'];
		$production_order->entry_date_time = date("Y-m-d H:i:s");
		
		if(!$production_order->create()){
			$arr = array(
				"message" => "error"
			);
			echo json_encode($arr);
			die();
		}
	}

	$arr = array(
		"message" => "created"
	);
	echo json_encode($arr);
?>