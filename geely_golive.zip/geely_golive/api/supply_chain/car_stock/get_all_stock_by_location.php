<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/car_stock.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $car_stock = new CarStock($db); 

    $car_stock->location = urldecode($_GET['location']);

    $stmt = $car_stock->getAllStockByLocation();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["data"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                $brand . ', ' . $model . ', ' . $model_year . ', ' . $grade . ', ' . $interior_color . ', ' . $exterior_color,
                $vin_no,
                $engine_no,
                (int)$id
            );
            array_push($arr["data"], $detail);
        }
    }
    echo json_encode($arr);
?>