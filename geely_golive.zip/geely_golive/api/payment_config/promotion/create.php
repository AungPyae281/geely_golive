<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/promotion.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $promotion = new Promotion($db);

    $data = json_decode($_POST['objArr']);

    $targetPath = "";
    $img = $_FILES['file'];
    if(!empty($_FILES['file']))
    {
        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        if($ext==""){
            $targetPath = "";
        }else{
            $newname = date("Y-m-d H-i-s") .  "." . $ext;
            $targetPath = './upload/' . $newname;
            move_uploaded_file($_FILES['file']['tmp_name'],$targetPath);
        }   
    }
    $promotion->signature_picture = $targetPath; 

    $promotion->code = $data[0]->code;
    $promotion->name = $data[0]->name;
    $promotion->discount = $data[0]->discount;
    $promotion->date_from = $data[0]->df;
    $promotion->date_to = $data[0]->dt;
    $promotion->terms_n_conditions = $data[0]->terms_n_conditions;
    $promotion->entry_by = $_SESSION['user'];
    $promotion->entry_date_time = date("Y-m-d H:i");

    if($promotion->checkPromotion()){
        $arr = array( 
            "message" => "duplicate"
        );
    }else{
        if($promotion->create()){
            $arr = array( 
                "message" => "created"
            );
        }else{
            $arr = array( 
                "message" => "error"
            );
        }
    }
    echo json_encode($arr);
?>