<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	 
	include_once '../config/database.php';
	include_once '../objects/user_role.php';
	 
	$database = new Database();
	$db = $database->getConnection();
	 
	$user_role = new UserRole($db);

	$stmt = $user_role->getRoles();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){ 
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$role = array(
				"dashboard" => $dashboard,
				"role_name" => $role_name,
				"is_delete" => ($username!="")?false:true
			); 
			array_push($arr["records"], $role);
		} 
	}
	echo json_encode($arr);
?>