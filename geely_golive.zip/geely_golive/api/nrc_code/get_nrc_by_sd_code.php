<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");

	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	  
	include_once '../config/database.php';
	include_once '../objects/nrc_code.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	
	$nrc_code = new NRCCode($db);
	$data = json_decode(file_get_contents("php://input"));

	$nrc_code->states_divisions_code = $data->states_divisions_code;

	$stmt = $nrc_code->getNRCBySDCode();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){ 
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"states_divisions_code" => $states_divisions_code,
				"townships_code" => $townships_code
			); 
			array_push($arr["records"], $detail);
		} 
	}
	echo json_encode($arr);
?>